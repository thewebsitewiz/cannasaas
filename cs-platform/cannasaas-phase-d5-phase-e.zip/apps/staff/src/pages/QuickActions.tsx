/**
 * @file QuickActions.tsx
 * @app apps/staff
 *
 * Quick actions hub page for budtenders — fast access to the most common
 * staff workflows without navigating to a full page.
 *
 * Action tiles (QuickActionBtn components):
 *   🪪 Verify Customer Age    → opens inline ID check panel
 *   📊 Check Purchase Limits  → opens inline customer search + limit display
 *   🔍 Product Lookup         → opens inline product search panel
 *   ↩️ Process Return         → opens inline order # lookup + return flow
 *
 * Each action opens an expanded panel below the tile grid.
 * Only one panel is open at a time.
 *
 * Sub-panel implementations:
 *   VERIFY AGE:
 *     Search customer → show DOB / verification status → "Mark Verified" button
 *     POST /age-verification/verify
 *
 *   PURCHASE LIMITS:
 *     Search customer → show remaining limits per category (inline, no navigation)
 *     GET /compliance/purchase-limit?customerId=:id
 *
 *   PRODUCT LOOKUP:
 *     Name/SKU search (same as Inventory page but compact)
 *     GET /products?search=:q&limit=10
 *
 *   PROCESS RETURN:
 *     Order # lookup → show items → select items to return → POST /orders/:id/refund
 *
 * Accessibility (WCAG 2.1 AA):
 *   - Panel open/close: aria-expanded on trigger tile (4.1.2)
 *   - Panel region: aria-label (1.3.1)
 *   - Inline form inputs: labelled (1.3.5)
 *   - Success/error feedback: role="status" aria-live (4.1.3)
 *   - document.title updated (2.4.2)
 */

import { useState, useEffect, useId } from 'react';
import { useCustomerSearch, useCustomerPurchaseLimit, useProducts, useOrder, useVerifyCustomer } from '@cannasaas/api-client';
import { useDebounce } from '@cannasaas/utils';
import { QuickActionBtn } from '../components/ui/QuickActionBtn';
import { StatusPill }     from '../components/ui/StatusPill';

type ActivePanel = 'age' | 'limits' | 'product' | 'return' | null;

/** Reusable mini customer search input + results */
function MiniCustomerSearch({ onSelect, label }: { onSelect: (id: string, name: string) => void; label: string }) {
  const [q, setQ] = useState('');
  const debQ      = useDebounce(q, 300);
  const inputId   = useId();
  const { data: results = [], isLoading } = useCustomerSearch({ q: debQ, limit: 8 } as any, { enabled: debQ.length >= 2 });

  return (
    <div>
      <label htmlFor={inputId} className="block text-xs font-semibold text-stone-700 mb-1.5">{label}</label>
      <input id={inputId} type="search" value={q} onChange={(e) => setQ(e.target.value)}
        placeholder="Name, phone, or email…"
        className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary,154_40%_30%)/0.3)]" />
      {debQ.length >= 2 && (
        <ul className="mt-1 bg-white border border-stone-200 rounded-xl shadow-lg overflow-hidden divide-y divide-stone-50 max-h-44 overflow-y-auto"
          role="listbox" aria-label="Customer results">
          {isLoading && <li className="px-3 py-2.5 text-xs text-stone-400">Searching…</li>}
          {!isLoading && (results as any[]).length === 0 && <li className="px-3 py-2.5 text-xs text-stone-400">No results</li>}
          {(results as any[]).map((r) => (
            <li key={r.id} role="option" aria-selected={false}>
              <button type="button" onClick={() => { onSelect(r.id, `${r.firstName} ${r.lastName}`); setQ(''); }}
                className="w-full text-left px-3 py-2.5 hover:bg-stone-50 focus-visible:outline-none focus-visible:bg-stone-50 text-sm">
                <p className="font-semibold text-stone-900">{r.firstName} {r.lastName}</p>
                <p className="text-xs text-stone-400">{r.email}</p>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function QuickActionsPage() {
  const [panel, setPanel] = useState<ActivePanel>(null);

  // Per-panel state
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [selectedCustomerName, setSelectedCustomerName] = useState('');
  const [productQ, setProductQ] = useState('');
  const [returnOrderNum, setReturnOrderNum] = useState('');
  const [statusMsg, setStatusMsg] = useState('');

  const debProductQ    = useDebounce(productQ, 250);
  const returnOrderId  = useId();
  const productSearchId = useId();

  useEffect(() => { document.title = 'Quick Actions | CannaSaas Staff'; }, []);

  const { data: limits }   = useCustomerPurchaseLimit(selectedCustomerId ?? '', { enabled: !!selectedCustomerId && (panel === 'limits' || panel === 'age') });
  const { data: prodData } = useProducts({ search: debProductQ, limit: 10 } as any, { enabled: debProductQ.length >= 2 && panel === 'product' });
  const { data: returnOrder } = useOrder(returnOrderNum, { enabled: returnOrderNum.length >= 8 && panel === 'return' });
  const { mutate: verifyCustomer, isPending: isVerifying } = useVerifyCustomer(selectedCustomerId ?? '');

  const openPanel = (p: ActivePanel) => { setPanel((prev) => prev === p ? null : p); setSelectedCustomerId(null); setStatusMsg(''); };

  const flash = (msg: string) => { setStatusMsg(msg); setTimeout(() => setStatusMsg(''), 4000); };

  const handleVerify = () => {
    verifyCustomer({ action: 'approve' }, {
      onSuccess: () => flash('✅ Customer verified'),
      onError:   () => flash('❌ Verification failed'),
    });
  };

  const ACTIONS: { id: ActivePanel; icon: string; label: string; variant: 'default' | 'danger' | 'success' }[] = [
    { id: 'age',     icon: '🪪', label: 'Verify Age',       variant: 'default' },
    { id: 'limits',  icon: '📊', label: 'Purchase Limits',  variant: 'default' },
    { id: 'product', icon: '🔍', label: 'Product Lookup',   variant: 'default' },
    { id: 'return',  icon: '↩️', label: 'Process Return',   variant: 'danger'  },
  ];

  const card = 'bg-white rounded-2xl border border-stone-200 shadow-sm p-5';

  return (
    <div className="space-y-5 max-w-xl">
      <h1 className="text-lg font-extrabold text-stone-900">Quick Actions</h1>

      {/* Action tile grid */}
      <div className="grid grid-cols-2 gap-3">
        {ACTIONS.map((action) => (
          <QuickActionBtn
            key={action.id}
            icon={action.icon}
            label={action.label}
            variant={action.variant}
            onClick={() => openPanel(action.id)}
          />
        ))}
      </div>

      {/* Status message */}
      {statusMsg && (
        <p role="status" aria-live="polite" className="text-sm font-semibold text-center py-2">{statusMsg}</p>
      )}

      {/* ── AGE VERIFICATION panel ────────────────────────────────── */}
      {panel === 'age' && (
        <section aria-label="Age verification panel" className={card + ' space-y-4'}>
          <h2 className="text-sm font-bold text-stone-900">🪪 Verify Customer Age</h2>
          <MiniCustomerSearch label="Find customer" onSelect={(id, name) => { setSelectedCustomerId(id); setSelectedCustomerName(name); }} />
          {selectedCustomerId && (
            <div className="space-y-3">
              <p className="text-sm font-semibold text-stone-800">{selectedCustomerName}</p>
              <button type="button" onClick={handleVerify} disabled={isVerifying}
                aria-busy={isVerifying}
                className="w-full py-3 bg-[hsl(var(--primary,154_40%_30%))] text-white text-sm font-bold rounded-xl hover:brightness-110 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))] transition-all">
                {isVerifying ? 'Verifying…' : '✅ Mark ID as Verified'}
              </button>
            </div>
          )}
        </section>
      )}

      {/* ── PURCHASE LIMITS panel ─────────────────────────────────── */}
      {panel === 'limits' && (
        <section aria-label="Purchase limits check panel" className={card + ' space-y-4'}>
          <h2 className="text-sm font-bold text-stone-900">📊 Check Purchase Limits</h2>
          <MiniCustomerSearch label="Find customer" onSelect={(id, name) => { setSelectedCustomerId(id); setSelectedCustomerName(name); }} />
          {selectedCustomerId && limits && (
            <div>
              <p className="text-xs font-semibold text-stone-700 mb-2">{selectedCustomerName} — Today's Remaining</p>
              <dl className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Flower',      value: limits.remaining?.flowerOz != null ? `${limits.remaining.flowerOz} oz` : 'N/A' },
                  { label: 'Concentrate', value: limits.remaining?.concentrateG != null ? `${limits.remaining.concentrateG}g` : 'N/A' },
                ].map((item) => (
                  <div key={item.label} className="bg-stone-50 rounded-xl p-3 text-center">
                    <dt className="text-[10px] font-medium text-stone-400">{item.label}</dt>
                    <dd className="text-sm font-extrabold text-stone-900 mt-0.5">{item.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}
        </section>
      )}

      {/* ── PRODUCT LOOKUP panel ──────────────────────────────────── */}
      {panel === 'product' && (
        <section aria-label="Product lookup panel" className={card + ' space-y-4'}>
          <h2 className="text-sm font-bold text-stone-900">🔍 Product Lookup</h2>
          <div>
            <label htmlFor={productSearchId} className="block text-xs font-semibold text-stone-700 mb-1.5">Name or SKU</label>
            <input id={productSearchId} type="search" value={productQ} onChange={(e) => setProductQ(e.target.value)}
              placeholder="Blue Dream, BD-125…"
              className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary,154_40%_30%)/0.3)]" />
          </div>
          {(prodData?.data ?? []).map((p: any) => (
            <div key={p.id} className="border border-stone-100 rounded-xl p-3">
              <div className="flex items-center justify-between mb-1">
                <p className="text-sm font-semibold text-stone-900">{p.name}</p>
                {p.thcContent && <span className="text-[10px] font-bold text-green-600">{p.thcContent}% THC</span>}
              </div>
              <p className="text-[10px] text-stone-400 capitalize mb-2">{p.category} · {p.brand}</p>
              {(p.variants ?? []).map((v: any) => (
                <div key={v.id} className="flex justify-between text-xs text-stone-600 py-0.5">
                  <span>{v.name} <span className="text-stone-400 font-mono">{v.sku}</span></span>
                  <span className="font-bold">${v.price?.toFixed(2)} · <span className={v.quantity === 0 ? 'text-red-500' : v.quantity <= 5 ? 'text-amber-500' : 'text-green-600'}>{v.quantity} left</span></span>
                </div>
              ))}
            </div>
          ))}
        </section>
      )}

      {/* ── RETURN PROCESSING panel ───────────────────────────────── */}
      {panel === 'return' && (
        <section aria-label="Return processing panel" className={card + ' space-y-4'}>
          <h2 className="text-sm font-bold text-stone-900">↩️ Process Return</h2>
          <div>
            <label htmlFor={returnOrderId} className="block text-xs font-semibold text-stone-700 mb-1.5">Order Number</label>
            <input id={returnOrderId} type="text" value={returnOrderNum} onChange={(e) => setReturnOrderNum(e.target.value.toUpperCase())}
              placeholder="Enter order number…" maxLength={24}
              className="w-full px-3 py-2.5 text-sm font-mono border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary,154_40%_30%)/0.3)] uppercase" />
          </div>
          {returnOrder && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-stone-900">Order #{returnOrder.orderNumber}</p>
                <StatusPill status={returnOrder.status} />
              </div>
              <p className="text-xs text-stone-500">{returnOrder.customerName} · ${returnOrder.total?.toFixed(2)}</p>
              {returnOrder.status !== 'completed' && returnOrder.status !== 'delivered' && (
                <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg p-2">
                  ⚠️ Only completed orders can be refunded.
                </p>
              )}
              {(returnOrder.status === 'completed' || returnOrder.status === 'delivered') && (
                <button type="button"
                  aria-label={`Issue refund for order #${returnOrder.orderNumber}`}
                  className="w-full py-3 bg-red-600 text-white text-sm font-bold rounded-xl hover:bg-red-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500 transition-all">
                  ↩️ Issue Full Refund
                </button>
              )}
            </div>
          )}
        </section>
      )}
    </div>
  );
}
