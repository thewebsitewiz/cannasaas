/**
 * @file InventorySearch.tsx
 * @app apps/staff
 *
 * Inventory search page for budtenders.
 *
 * Features:
 *   - Fast text search by product name or SKU (debounced 250ms)
 *   - Category filter chips
 *   - Barcode scanner integration placeholder (activates device camera via
 *     a <video> element; parses barcodes with @zxing/browser if available)
 *   - Results grid: product name, category, THC%, variants with stock per variant
 *   - Low-stock alert banner (GET /products/low-stock)
 *   - Each product row expands to show all variants inline
 *
 * API:
 *   GET /products?search=&category=&limit=40    → product search
 *   GET /products/low-stock                     → low-stock alerts
 *
 * Accessibility (WCAG 2.1 AA):
 *   - Search: labelled + result count aria-live (1.3.5, 4.1.3)
 *   - Category chips: role="radiogroup" + aria-pressed (4.1.2)
 *   - Expandable rows: aria-expanded on trigger button (4.1.2)
 *   - Scanner region: aria-label (1.3.1)
 *   - Low-stock alert: role="alert" (4.1.3)
 *   - document.title updated (2.4.2)
 */

import { useState, useEffect, useId } from 'react';
import { useProducts, useLowStockProducts } from '@cannasaas/api-client';
import { useDebounce } from '@cannasaas/utils';

const CATEGORIES = ['All', 'Flower', 'Vape', 'Edible', 'Concentrate', 'Tincture', 'Topical', 'Pre-roll', 'Accessory'];

export function InventorySearchPage() {
  const [search,   setSearch]   = useState('');
  const [category, setCategory] = useState('All');
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [scanOpen, setScanOpen] = useState(false);
  const debouncedQ = useDebounce(search, 250);
  const searchId   = useId();

  useEffect(() => { document.title = 'Inventory Search | CannaSaas Staff'; }, []);

  const { data, isLoading } = useProducts({
    search:   debouncedQ || undefined,
    category: category !== 'All' ? category.toLowerCase() : undefined,
    limit:    40,
  } as any);

  const { data: lowStock = [] } = useLowStockProducts();

  const products  = data?.data ?? [];
  const total     = data?.pagination?.total ?? 0;

  const toggle = (id: string) => setExpanded((prev) => {
    const next = new Set(prev);
    next.has(id) ? next.delete(id) : next.add(id);
    return next;
  });

  const inputCls = 'w-full px-4 py-3 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary,154_40%_30%)/0.3)]';

  return (
    <div className="space-y-5 max-w-2xl">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-lg font-extrabold text-stone-900">Inventory</h1>
        <button type="button" onClick={() => setScanOpen((s) => !s)}
          aria-expanded={scanOpen} aria-controls="barcode-scanner"
          className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border border-stone-200 rounded-xl bg-white hover:bg-stone-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-400 transition-all">
          <span aria-hidden="true">📷</span> {scanOpen ? 'Close Scanner' : 'Scan Barcode'}
        </button>
      </div>

      {/* Barcode scanner placeholder */}
      {scanOpen && (
        <div id="barcode-scanner" role="region" aria-label="Barcode scanner camera view"
          className="bg-stone-900 rounded-2xl overflow-hidden aspect-video relative flex items-center justify-center">
          <p className="text-white text-sm text-center px-6">
            <span aria-hidden="true" className="block text-4xl mb-2">📷</span>
            Camera barcode scanner<br/>
            <span className="text-xs text-stone-400">(react-webcam + @zxing/browser renders here)</span>
          </p>
          <button type="button" onClick={() => setScanOpen(false)}
            aria-label="Close barcode scanner"
            className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center bg-white/20 hover:bg-white/30 rounded-full text-white text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white">
            ✕
          </button>
        </div>
      )}

      {/* Low-stock alert */}
      {(lowStock as any[]).length > 0 && (
        <div role="alert" className="flex items-start gap-2.5 p-4 bg-amber-50 border border-amber-200 rounded-2xl text-sm">
          <span aria-hidden="true" className="text-xl flex-shrink-0">⚠️</span>
          <div>
            <p className="font-bold text-amber-800">{(lowStock as any[]).length} product{(lowStock as any[]).length !== 1 ? 's' : ''} low on stock</p>
            <p className="text-xs text-amber-600 mt-0.5">{(lowStock as any[]).slice(0, 3).map((p: any) => p.name).join(', ')}{(lowStock as any[]).length > 3 ? ` +${(lowStock as any[]).length - 3} more` : ''}</p>
          </div>
        </div>
      )}

      {/* Search */}
      <div>
        <label htmlFor={searchId} className="sr-only">Search products by name or SKU</label>
        <div className="relative">
          <svg aria-hidden="true" className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400"
            fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <circle cx="11" cy="11" r="8"/><path strokeLinecap="round" d="m21 21-4.35-4.35"/>
          </svg>
          <input id={searchId} type="search" value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Product name or SKU…" className={inputCls + ' pl-11'} />
        </div>
        <p aria-live="polite" className="text-[10px] text-stone-400 mt-1">{total.toLocaleString()} products</p>
      </div>

      {/* Category chips */}
      <div role="radiogroup" aria-label="Filter by product category"
        className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {CATEGORIES.map((cat) => (
          <button key={cat} type="button" role="radio" aria-checked={category === cat}
            onClick={() => setCategory(cat)}
            className={['px-3 py-1.5 text-xs font-semibold rounded-full border whitespace-nowrap transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-400',
              category === cat ? 'bg-[hsl(var(--primary,154_40%_30%))] text-white border-[hsl(var(--primary,154_40%_30%))]' : 'bg-white text-stone-500 border-stone-200 hover:border-stone-300'].join(' ')}>
            {cat}
          </button>
        ))}
      </div>

      {/* Results */}
      {isLoading ? (
        <div className="space-y-2">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} aria-hidden="true" className="h-16 bg-white border border-stone-200 rounded-2xl animate-pulse motion-reduce:animate-none" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-12 text-stone-300">
          <span aria-hidden="true" className="text-4xl block mb-2">📦</span>
          <p className="text-sm">No products found</p>
        </div>
      ) : (
        <ul className="space-y-2">
          {products.map((product: any) => {
            const isOpen = expanded.has(product.id);
            const totalStock = (product.variants ?? []).reduce((n: number, v: any) => n + (v.quantity ?? 0), 0);
            const isLow = (lowStock as any[]).some((l: any) => l.id === product.id);
            return (
              <li key={product.id} className="bg-white border border-stone-200 rounded-2xl overflow-hidden shadow-sm">
                {/* Product row */}
                <button type="button" onClick={() => toggle(product.id)}
                  aria-expanded={isOpen} aria-controls={`variants-${product.id}`}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-stone-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[hsl(var(--primary,154_40%_30%))] transition-colors">
                  <div className="w-10 h-10 rounded-lg bg-stone-100 flex-shrink-0 flex items-center justify-center overflow-hidden">
                    {product.images?.[0]?.url
                      ? <img src={product.images[0].url} alt="" aria-hidden="true" loading="lazy" className="w-full h-full object-cover" />
                      : <span aria-hidden="true" className="text-lg">🌿</span>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline gap-2 flex-wrap">
                      <p className="text-sm font-semibold text-stone-900 truncate">{product.name}</p>
                      {product.thcContent && <span className="text-[10px] font-bold text-green-600">{product.thcContent}% THC</span>}
                    </div>
                    <p className="text-[10px] text-stone-400 capitalize">{product.category}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className={['text-sm font-extrabold', totalStock === 0 ? 'text-red-600' : isLow ? 'text-amber-600' : 'text-stone-900'].join(' ')}>
                      {totalStock}
                    </p>
                    <p className="text-[10px] text-stone-400">units</p>
                  </div>
                  <svg aria-hidden="true"
                    className={['w-4 h-4 text-stone-400 transition-transform flex-shrink-0', isOpen ? 'rotate-180' : ''].join(' ')}
                    fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="m6 9 6 6 6-6"/>
                  </svg>
                </button>

                {/* Variants panel */}
                {isOpen && (
                  <div id={`variants-${product.id}`} className="border-t border-stone-100 divide-y divide-stone-50">
                    {(product.variants ?? []).map((v: any) => (
                      <div key={v.id} className="flex items-center justify-between px-4 py-2.5">
                        <div>
                          <p className="text-xs font-semibold text-stone-700">{v.name}</p>
                          <p className="text-[10px] font-mono text-stone-400">{v.sku}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-bold text-stone-900">${v.price?.toFixed(2)}</p>
                          <p className={['text-[10px] font-semibold', v.quantity === 0 ? 'text-red-500' : v.quantity <= (v.reorderThreshold ?? 5) ? 'text-amber-500' : 'text-green-600'].join(' ')}>
                            {v.quantity === 0 ? 'Out of stock' : `${v.quantity} left`}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
