/**
 * @file Login.tsx
 * @app apps/staff
 *
 * Staff portal login page.
 *
 * Simplified, touch-friendly login form for budtenders and drivers
 * who may be logging in on tablets or shared terminals.
 *
 * Features:
 *   - Email + password inputs
 *   - "Remember me" checkbox (stores token in localStorage vs sessionStorage)
 *   - Calls POST /auth/login, stores JWT via useAuthStore
 *   - On success, redirects to /orders
 *   - Error message shown inline (role="alert")
 *
 * Accessibility (WCAG 2.1 AA):
 *   - All inputs have visible labels (1.3.5)
 *   - Error: role="alert" aria-live="assertive" (4.1.3)
 *   - Password: show/hide toggle with aria-label (4.1.2)
 *   - Submit: aria-busy during login request (4.1.2)
 *   - document.title updated (2.4.2)
 */

import { useState, useEffect, useId } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '@cannasaas/stores';
import { STAFF_ROUTES } from '../routes';

export function StaffLogin() {
  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [showPw,   setShowPw]   = useState(false);
  const [remember, setRemember] = useState(false);
  const [error,    setError]    = useState('');
  const [loading,  setLoading]  = useState(false);

  const navigate = useNavigate();
  const { login } = useAuthStore();

  const emailId    = useId();
  const passwordId = useId();
  const rememberId = useId();

  useEffect(() => { document.title = 'Staff Login | CannaSaas'; }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(email, password, remember);
      navigate(STAFF_ROUTES.orderQueue, { replace: true });
    } catch {
      setError('Invalid email or password. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const inputCls = 'w-full px-4 py-3 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary,154_40%_30%)/0.3)] focus:border-[hsl(var(--primary,154_40%_30%)/0.4)] bg-white';

  return (
    <div className="min-h-screen bg-stone-50 flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Brand */}
        <div className="text-center mb-8">
          <div aria-hidden="true" className="w-16 h-16 rounded-2xl bg-[hsl(var(--primary,154_40%_30%))] flex items-center justify-center text-white text-3xl font-extrabold mx-auto mb-4">
            🌿
          </div>
          <h1 className="text-xl font-extrabold text-stone-900">Staff Portal</h1>
          <p className="text-sm text-stone-400 mt-1">CannaSaas</p>
        </div>

        {/* Error */}
        {error && (
          <div role="alert" aria-live="assertive" className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-sm text-red-700 flex items-center gap-2">
            <span aria-hidden="true">⚠️</span>{error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} noValidate className="space-y-4">
          <div>
            <label htmlFor={emailId} className="block text-xs font-semibold text-stone-700 mb-1.5">Email Address</label>
            <input id={emailId} type="email" value={email} onChange={(e) => setEmail(e.target.value)}
              required aria-required="true" autoComplete="username" placeholder="you@dispensary.com" className={inputCls} />
          </div>
          <div>
            <label htmlFor={passwordId} className="block text-xs font-semibold text-stone-700 mb-1.5">Password</label>
            <div className="relative">
              <input id={passwordId} type={showPw ? 'text' : 'password'} value={password}
                onChange={(e) => setPassword(e.target.value)} required aria-required="true"
                autoComplete="current-password" placeholder="••••••••" className={inputCls + ' pr-12'} />
              <button type="button" onClick={() => setShowPw((s) => !s)}
                aria-label={showPw ? 'Hide password' : 'Show password'}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-stone-400 rounded p-1">
                {showPw ? '🙈' : '👁️'}
              </button>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <input id={rememberId} type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)}
              className="w-4 h-4 rounded text-[hsl(var(--primary,154_40%_30%))] focus:ring-[hsl(var(--primary,154_40%_30%))]" />
            <label htmlFor={rememberId} className="text-xs text-stone-500 cursor-pointer">Keep me logged in</label>
          </div>
          <button type="submit" disabled={loading || !email || !password}
            aria-busy={loading}
            className="w-full py-3 bg-[hsl(var(--primary,154_40%_30%))] text-white text-sm font-bold rounded-xl hover:brightness-110 disabled:opacity-60 disabled:cursor-wait focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))] focus-visible:ring-offset-2 transition-all">
            {loading ? 'Signing in…' : 'Sign In'}
          </button>
        </form>
      </div>
    </div>
  );
}
