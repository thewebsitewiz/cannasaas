/**
 * @file DeliveryDispatch.tsx
 * @app apps/staff
 *
 * Delivery dispatch management page.
 *
 * Features:
 *   - Unassigned delivery orders list with "Assign Driver" action per order
 *   - Available driver list (name, phone, current load count)
 *   - Driver assignment: select driver from dropdown, POST /delivery/assign
 *   - Active deliveries list showing driver name + live status from WebSocket
 *   - Map placeholder showing driver pins with last known position
 *   - "Mark Delivered" shortcut for out_for_delivery orders
 *
 * Data:
 *   GET /orders?fulfillmentType=delivery&status=preparing,confirmed,pending → pending delivery orders
 *   GET /delivery/drivers                                                    → available drivers
 *   GET /orders?fulfillmentType=delivery&status=out_for_delivery            → active deliveries
 *   WebSocket /delivery/tracking → useDeliveryTracking hook for live positions
 *
 * Accessibility (WCAG 2.1 AA):
 *   - Map placeholder: role="img" aria-label + skip link (2.1.1)
 *   - Driver selects: aria-label includes order # (4.1.2)
 *   - Sections: <section> with <h2> (1.3.1)
 *   - Live status updates: aria-live on active delivery list (4.1.3)
 *   - document.title updated (2.4.2)
 */

import { useEffect, useId } from 'react';
import { useDeliveryOrders, useAvailableDrivers, useUpdateOrderStatus } from '@cannasaas/api-client';
import { useDeliveryTracking } from '../hooks/useDeliveryTracking';
import { StatusPill } from '../components/ui/StatusPill';

export function DeliveryDispatchPage() {
  const { assignDriver, isAssigning, driverPositions, isConnected } = useDeliveryTracking();
  const { data: pendingDeliveries = [] }  = useDeliveryOrders({ status: ['preparing', 'confirmed', 'pending'] });
  const { data: activeDeliveries  = [] }  = useDeliveryOrders({ status: ['out_for_delivery'] });
  const { data: drivers           = [] }  = useAvailableDrivers();
  const { mutate: updateStatus }          = useUpdateOrderStatus('');

  useEffect(() => { document.title = 'Delivery Dispatch | CannaSaas Staff'; }, []);

  const mapSkipId = useId();
  const card = 'bg-white rounded-2xl border border-stone-200 shadow-sm p-5';

  return (
    <div className="space-y-5 max-w-screen-lg">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-lg font-extrabold text-stone-900">Delivery Dispatch</h1>
        <span role="status" aria-label={isConnected ? 'Live tracking active' : 'Live tracking disconnected'}
          className={['flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-semibold border',
            isConnected ? 'bg-green-50 text-green-700 border-green-200' : 'bg-stone-50 text-stone-500 border-stone-200'].join(' ')}>
          <span aria-hidden="true" className={['w-1.5 h-1.5 rounded-full', isConnected ? 'bg-green-400 animate-pulse motion-reduce:animate-none' : 'bg-stone-300'].join(' ')} />
          {isConnected ? 'Live Tracking' : 'Offline'}
        </span>
      </div>

      {/* ── Map ──────────────────────────────────────────────────────── */}
      <div className="relative rounded-2xl overflow-hidden border border-stone-200">
        <a href={`#dispatch-list`} className="sr-only focus:not-sr-only focus:absolute focus:z-20 focus:top-2 focus:left-2 focus:bg-white focus:text-stone-900 focus:px-3 focus:py-1.5 focus:rounded-lg focus:shadow-lg focus:text-sm">
          Skip map
        </a>
        <div role="img" aria-label={`Delivery map showing ${Object.keys(driverPositions).length} active driver${Object.keys(driverPositions).length !== 1 ? 's' : ''}`}
          className="h-56 bg-gradient-to-br from-blue-50 to-green-50 flex items-center justify-center relative">
          <div className="text-center">
            <span aria-hidden="true" className="text-4xl block mb-2">🗺️</span>
            <p className="text-xs font-medium text-stone-600">
              {Object.keys(driverPositions).length} driver{Object.keys(driverPositions).length !== 1 ? 's' : ''} tracked live
            </p>
            <p className="text-[10px] text-stone-400">react-leaflet renders here in production</p>
          </div>
          {/* Driver position pins (decorative simulation) */}
          {Object.values(driverPositions).map((pos, i) => (
            <div key={pos.driverId} aria-hidden="true"
              className="absolute w-8 h-8 bg-[hsl(var(--primary,154_40%_30%))] rounded-full border-2 border-white shadow-lg flex items-center justify-center text-white text-xs font-bold"
              style={{ left: `${20 + i * 25}%`, top: `${30 + i * 15}%` }}>
              🚗
            </div>
          ))}
        </div>
      </div>

      <div id="dispatch-list" className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* ── Unassigned deliveries ──────────────────────────────────── */}
        <section aria-label="Unassigned delivery orders" className={card}>
          <h2 className="text-sm font-bold text-stone-900 mb-4">
            Unassigned
            {(pendingDeliveries as any[]).length > 0 && (
              <span className="ml-2 px-2 py-0.5 bg-amber-100 text-amber-800 text-[10px] font-bold rounded-full">
                {(pendingDeliveries as any[]).length}
              </span>
            )}
          </h2>
          <div className="space-y-3">
            {(pendingDeliveries as any[]).length === 0 ? (
              <p className="text-xs text-stone-300 text-center py-4">No pending deliveries</p>
            ) : (pendingDeliveries as any[]).map((order: any) => (
              <div key={order.id} className="border border-stone-100 rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-mono font-bold text-stone-700">#{(order.orderNumber ?? order.id.slice(0, 8)).toUpperCase()}</span>
                    <p className="text-xs text-stone-500">{order.customerName}</p>
                    {order.delivery?.address && (
                      <p className="text-[10px] text-stone-400">{order.delivery.address.street}, {order.delivery.address.city}</p>
                    )}
                  </div>
                  <StatusPill status={order.status} />
                </div>
                {/* Driver selector */}
                <div className="flex items-center gap-2">
                  <label htmlFor={`driver-${order.id}`} className="sr-only">
                    Assign driver for order #{order.orderNumber}
                  </label>
                  <select id={`driver-${order.id}`} defaultValue=""
                    onChange={(e) => { if (e.target.value) assignDriver(order.id, e.target.value); }}
                    disabled={isAssigning}
                    className="flex-1 text-xs border border-stone-200 rounded-lg px-2 py-1.5 bg-white appearance-none cursor-pointer focus:outline-none focus:ring-1 text-stone-700 disabled:opacity-50">
                    <option value="" disabled>Select driver…</option>
                    {(drivers as any[]).map((d: any) => (
                      <option key={d.id} value={d.id}>
                        {d.firstName} {d.lastName} ({d.activeDeliveries ?? 0} active)
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ── Active deliveries ──────────────────────────────────────── */}
        <section aria-label="Active delivery orders" className={card} aria-live="polite">
          <h2 className="text-sm font-bold text-stone-900 mb-4">
            Out for Delivery
            {(activeDeliveries as any[]).length > 0 && (
              <span className="ml-2 px-2 py-0.5 bg-indigo-100 text-indigo-800 text-[10px] font-bold rounded-full">
                {(activeDeliveries as any[]).length}
              </span>
            )}
          </h2>
          <div className="space-y-3">
            {(activeDeliveries as any[]).length === 0 ? (
              <p className="text-xs text-stone-300 text-center py-4">No active deliveries</p>
            ) : (activeDeliveries as any[]).map((order: any) => (
              <div key={order.id} className="border border-stone-100 rounded-xl p-3 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-xs font-mono font-bold text-stone-700">#{(order.orderNumber ?? order.id.slice(0, 8)).toUpperCase()}</span>
                    <p className="text-xs text-stone-500">{order.customerName}</p>
                    {order.delivery?.driverName && <p className="text-[10px] text-[hsl(var(--primary,154_40%_30%))] font-medium">🚗 {order.delivery.driverName}</p>}
                  </div>
                  <StatusPill status="out_for_delivery" />
                </div>
                <button type="button"
                  onClick={() => updateStatus({ id: order.id, status: 'delivered' } as any)}
                  aria-label={`Mark order #${order.orderNumber} as delivered`}
                  className="w-full py-2 bg-green-600 text-white text-xs font-bold rounded-lg hover:bg-green-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green-500 transition-all">
                  ✅ Mark Delivered
                </button>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
