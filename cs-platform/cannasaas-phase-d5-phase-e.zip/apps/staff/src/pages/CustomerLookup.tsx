/**
 * @file CustomerLookup.tsx
 * @app apps/staff
 *
 * Customer lookup page for budtenders.
 *
 * Allows quick search by name, phone, or email.
 * On selection shows:
 *   - Customer name, verification badge, medical card status
 *   - Today's remaining purchase limits (flower oz, concentrate g)
 *   - Recent order history (last 5 orders)
 *   - Loyalty points balance
 *   - Quick action: "Verify ID" button (calls POST /age-verification/verify)
 *
 * API calls:
 *   GET /users?search=:q&role=customer&limit=10   → search results
 *   GET /users/:id                                → customer detail
 *   GET /compliance/purchase-limit?customerId=:id → purchase limits
 *   GET /orders?customerId=:id&limit=5            → recent orders
 *   POST /age-verification/verify                 → verify ID
 *
 * Accessibility (WCAG 2.1 AA):
 *   - Search input: labelled, results aria-live (1.3.5, 4.1.3)
 *   - Results list: role="listbox" with role="option" items (4.1.2)
 *   - Purchase limits: <dl> key/value semantic structure (1.3.1)
 *   - Verify button: aria-label, aria-busy during action (4.1.2)
 *   - document.title updated (2.4.2)
 */

import { useState, useEffect, useId } from 'react';
import { useCustomerSearch, useCustomer, useCustomerPurchaseLimit, useCustomerOrders, useVerifyCustomer } from '@cannasaas/api-client';
import { useDebounce } from '@cannasaas/utils';
import { StatusPill } from '../components/ui/StatusPill';

export function CustomerLookupPage() {
  const [query,      setQuery]      = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [verifyMsg,  setVerifyMsg]  = useState('');
  const debouncedQ = useDebounce(query, 300);
  const searchId   = useId();

  useEffect(() => { document.title = 'Customer Lookup | CannaSaas Staff'; }, []);

  const { data: results = [], isLoading: searching } = useCustomerSearch({ q: debouncedQ, limit: 10 } as any, { enabled: debouncedQ.length >= 2 });
  const { data: customer }  = useCustomer(selectedId ?? '', { enabled: !!selectedId });
  const { data: limits }    = useCustomerPurchaseLimit(selectedId ?? '', { enabled: !!selectedId });
  const { data: recentOrders = [] } = useCustomerOrders({ customerId: selectedId ?? '', limit: 5 } as any, { enabled: !!selectedId });
  const { mutate: verify, isPending: isVerifying } = useVerifyCustomer(selectedId ?? '');

  const handleVerify = () => {
    verify({ action: 'approve' }, {
      onSuccess: () => { setVerifyMsg('✅ ID verified successfully'); setTimeout(() => setVerifyMsg(''), 4000); },
      onError:   () => { setVerifyMsg('❌ Verification failed'); setTimeout(() => setVerifyMsg(''), 4000); },
    });
  };

  const inputCls = 'w-full px-4 py-3 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary,154_40%_30%)/0.3)] focus:border-[hsl(var(--primary,154_40%_30%)/0.4)]';
  const card     = 'bg-white rounded-2xl border border-stone-200 shadow-sm p-5';

  return (
    <div className="space-y-5 max-w-2xl">
      <h1 className="text-lg font-extrabold text-stone-900">Customer Lookup</h1>

      {/* Search */}
      <div>
        <label htmlFor={searchId} className="block text-xs font-semibold text-stone-700 mb-1.5">
          Search by name, phone, or email
        </label>
        <div className="relative">
          <svg aria-hidden="true" className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400"
            fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <circle cx="11" cy="11" r="8"/><path strokeLinecap="round" d="m21 21-4.35-4.35"/>
          </svg>
          <input id={searchId} type="search" value={query} onChange={(e) => { setQuery(e.target.value); setSelectedId(null); }}
            placeholder="Jane Smith · (718) 555-0100 · jane@email.com"
            className={inputCls + ' pl-11'} />
        </div>

        {/* Search results dropdown */}
        {debouncedQ.length >= 2 && !selectedId && (
          <ul role="listbox" aria-label="Customer search results" aria-live="polite"
            className="mt-1 bg-white border border-stone-200 rounded-xl shadow-lg overflow-hidden divide-y divide-stone-50 max-h-60 overflow-y-auto">
            {searching && (
              <li className="px-4 py-3 text-xs text-stone-400">Searching…</li>
            )}
            {!searching && (results as any[]).length === 0 && (
              <li className="px-4 py-3 text-xs text-stone-400">No customers found</li>
            )}
            {(results as any[]).map((r) => (
              <li key={r.id} role="option" aria-selected={false}>
                <button type="button" onClick={() => setSelectedId(r.id)}
                  className="w-full text-left px-4 py-3 hover:bg-stone-50 transition-colors focus-visible:outline-none focus-visible:bg-stone-50">
                  <p className="text-sm font-semibold text-stone-900">{r.firstName} {r.lastName}</p>
                  <p className="text-xs text-stone-400">{r.email} · {r.phone ?? 'no phone'}</p>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Customer detail */}
      {customer && (
        <div className="space-y-4">
          {/* Profile card */}
          <div className={card}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-base font-extrabold text-stone-900">{customer.firstName} {customer.lastName}</h2>
                  <StatusPill status={customer.verificationStatus === 'verified' ? 'active' : 'inactive'} />
                </div>
                <p className="text-xs text-stone-500 mt-0.5">{customer.email}</p>
                {customer.phone && <p className="text-xs text-stone-500">{customer.phone}</p>}
                <p className="text-xs text-stone-400 mt-1">⭐ {(customer.loyaltyPoints ?? 0).toLocaleString()} pts</p>
              </div>
              <div className="flex flex-col items-end gap-2">
                {customer.verificationStatus !== 'verified' && (
                  <button type="button" onClick={handleVerify} disabled={isVerifying}
                    aria-busy={isVerifying} aria-label={`Verify ID for ${customer.firstName} ${customer.lastName}`}
                    className="px-4 py-2 bg-[hsl(var(--primary,154_40%_30%))] text-white text-xs font-bold rounded-xl hover:brightness-110 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))] transition-all">
                    🪪 Verify ID
                  </button>
                )}
                {verifyMsg && <p aria-live="polite" role="status" className="text-xs font-medium">{verifyMsg}</p>}
              </div>
            </div>
            {customer.medicalCardExpiry && (
              <p className="text-xs text-stone-500 mt-3 pt-3 border-t border-stone-100">
                🏥 Medical card expires:
                <time dateTime={customer.medicalCardExpiry} className={new Date(customer.medicalCardExpiry) < new Date() ? ' text-red-600 font-bold' : ' font-medium text-stone-700'}>
                  {' '}{new Date(customer.medicalCardExpiry).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                </time>
                {new Date(customer.medicalCardExpiry) < new Date() && ' — EXPIRED'}
              </p>
            )}
          </div>

          {/* Purchase limits */}
          {limits && (
            <div className={card}>
              <h3 className="text-xs font-bold text-stone-900 mb-3">Today's Purchase Limits</h3>
              <dl className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Flower remaining',      value: limits.remaining?.flowerOz != null ? `${limits.remaining.flowerOz} oz` : '—', max: `of ${limits.limits?.maxFlowerOz ?? '?'} oz` },
                  { label: 'Concentrate remaining', value: limits.remaining?.concentrateG != null ? `${limits.remaining.concentrateG}g` : '—', max: `of ${limits.limits?.maxConcentrateG ?? '?'}g` },
                ].map((item) => (
                  <div key={item.label} className="bg-stone-50 rounded-xl p-3">
                    <dt className="text-[10px] font-medium text-stone-400">{item.label}</dt>
                    <dd className="text-sm font-extrabold text-stone-900 mt-0.5">{item.value}</dd>
                    <dd className="text-[9px] text-stone-400">{item.max}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}

          {/* Recent orders */}
          {(recentOrders as any[]).length > 0 && (
            <div className={card}>
              <h3 className="text-xs font-bold text-stone-900 mb-3">Recent Orders</h3>
              <ul className="space-y-2">
                {(recentOrders as any[]).map((o: any) => (
                  <li key={o.id} className="flex items-center justify-between text-xs py-1.5 border-b border-stone-50 last:border-0">
                    <span className="font-mono font-bold text-stone-600">#{(o.orderNumber ?? o.id.slice(0, 8)).toUpperCase()}</span>
                    <time dateTime={o.createdAt} className="text-stone-400">{new Date(o.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</time>
                    <span className="font-bold">${o.total?.toFixed(2)}</span>
                    <StatusPill status={o.status} />
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
