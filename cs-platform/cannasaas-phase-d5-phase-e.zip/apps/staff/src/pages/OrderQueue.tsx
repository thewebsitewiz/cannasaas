/**
 * @file OrderQueue.tsx
 * @app apps/staff
 *
 * Real-time order queue page — the primary page for budtenders.
 *
 * Layout:
 *   Page header with live connection indicator + total pending count
 *   Horizontal scrollable status-group filter (mobile) OR vertical sections (desktop)
 *   Per-status section: heading with count badge + OrderCard grid
 *
 * Status groups displayed (in priority order):
 *   1. Pending      — new orders waiting for confirmation
 *   2. Confirmed    — confirmed, not yet being prepared
 *   3. Preparing    — in preparation
 *   4. Ready        — ready for pickup
 *   5. Out Delivery — out for delivery
 *
 * Data: useOrderQueue hook (WebSocket + TanStack Query hybrid)
 * Orders in each group are sorted oldest-first so the most urgent appear first.
 *
 * One-click advance: each OrderCard has an "Advance" button that calls
 * advanceOrder(id, nextStatus) from the hook.
 *
 * Accessibility (WCAG 2.1 AA):
 *   - document.title includes pending count (2.4.2)
 *   - Live region for new order notifications (4.1.3)
 *   - Status group headings: <h2> (1.3.1)
 *   - Order cards: article elements (1.3.1)
 *   - Loading: aria-busy on main grid (4.1.2)
 */

import { useEffect, useState } from 'react';
import { useOrderQueue }   from '../hooks/useOrderQueue';
import { OrderCard }       from '../components/ui/OrderCard';
import type { OrderStatus } from '../components/ui/OrderCard';

const STATUS_LABELS: Record<OrderStatus, string> = {
  pending:          '⏳ Pending',
  confirmed:        '✅ Confirmed',
  preparing:        '⚗️ Preparing',
  ready_for_pickup: '🛍️ Ready for Pickup',
  out_for_delivery: '🚗 Out for Delivery',
  delivered:        '📦 Delivered',
  completed:        '🎉 Completed',
  cancelled:        '❌ Cancelled',
};

// Status groups shown in the queue (excludes terminal states)
const QUEUE_GROUPS: OrderStatus[] = [
  'pending', 'confirmed', 'preparing', 'ready_for_pickup', 'out_for_delivery',
];

export function OrderQueuePage() {
  const { grouped, isLoading, isConnected, advanceOrder, isAdvancing, queueStatuses } = useOrderQueue();
  const [advancingId, setAdvancingId] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState<OrderStatus | 'all'>('all');

  const totalPending = (grouped.pending?.length ?? 0);

  useEffect(() => {
    document.title = totalPending > 0
      ? `(${totalPending}) Order Queue | CannaSaas Staff`
      : 'Order Queue | CannaSaas Staff';
  }, [totalPending]);

  const handleAdvance = (id: string, next: OrderStatus) => {
    setAdvancingId(id);
    advanceOrder(id, next);
    setTimeout(() => setAdvancingId(null), 1500);
  };

  const visibleGroups = activeFilter === 'all'
    ? QUEUE_GROUPS
    : [activeFilter as OrderStatus];

  const totalActive = QUEUE_GROUPS.reduce((n, s) => n + (grouped[s]?.length ?? 0), 0);

  return (
    <div className="space-y-5 max-w-screen-xl">
      {/* ── Header ──────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-extrabold text-stone-900">Order Queue</h1>
          <p className="text-xs text-stone-400">
            {totalActive} active order{totalActive !== 1 ? 's' : ''}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* WebSocket indicator */}
          <span
            role="status"
            aria-label={isConnected ? 'Live updates active' : 'Live updates disconnected — polling every 30s'}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-semibold border"
            style={isConnected ? { borderColor: '#86efac', backgroundColor: '#f0fdf4', color: '#166534' } : { borderColor: '#d6d3d1', backgroundColor: '#fafaf9', color: '#78716c' }}
          >
            <span aria-hidden="true" className={['w-1.5 h-1.5 rounded-full', isConnected ? 'bg-green-400 animate-pulse motion-reduce:animate-none' : 'bg-stone-300'].join(' ')} />
            {isConnected ? 'Live' : 'Polling'}
          </span>
          {/* Pending badge */}
          {totalPending > 0 && (
            <span aria-live="polite" className="px-2.5 py-1 bg-amber-100 text-amber-800 text-[10px] font-bold rounded-full border border-amber-200">
              {totalPending} new
            </span>
          )}
        </div>
      </div>

      {/* ── Status filter chips ─────────────────────────────────────── */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1" role="group" aria-label="Filter by order status">
        <button type="button" onClick={() => setActiveFilter('all')}
          aria-pressed={activeFilter === 'all'}
          className={['px-3 py-1.5 text-xs font-semibold rounded-full border transition-all whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-400',
            activeFilter === 'all' ? 'bg-stone-800 text-white border-stone-800' : 'bg-white text-stone-500 border-stone-200 hover:border-stone-300'].join(' ')}>
          All ({totalActive})
        </button>
        {QUEUE_GROUPS.map((s) => {
          const count = grouped[s]?.length ?? 0;
          return (
            <button key={s} type="button" onClick={() => setActiveFilter(s)}
              aria-pressed={activeFilter === s}
              className={['px-3 py-1.5 text-xs font-semibold rounded-full border transition-all whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-400',
                activeFilter === s ? 'bg-stone-800 text-white border-stone-800' : 'bg-white text-stone-500 border-stone-200 hover:border-stone-300'].join(' ')}>
              {STATUS_LABELS[s].split(' ').slice(1).join(' ')} ({count})
            </button>
          );
        })}
      </div>

      {/* ── Order groups ─────────────────────────────────────────────── */}
      {isLoading ? (
        <div aria-busy="true" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} aria-hidden="true" className="h-40 bg-white border border-stone-200 rounded-2xl animate-pulse motion-reduce:animate-none" />
          ))}
        </div>
      ) : (
        <div className="space-y-6">
          {visibleGroups.map((status) => {
            const orders = grouped[status] ?? [];
            if (orders.length === 0 && activeFilter !== 'all') return null;
            return (
              <section key={status} aria-label={`${STATUS_LABELS[status]} orders`}>
                <div className="flex items-center gap-2 mb-3">
                  <h2 className="text-sm font-bold text-stone-800">{STATUS_LABELS[status]}</h2>
                  <span className={['px-2 py-0.5 text-[10px] font-bold rounded-full',
                    orders.length > 0 ? 'bg-stone-100 text-stone-600' : 'bg-stone-50 text-stone-300'].join(' ')}>
                    {orders.length}
                  </span>
                </div>
                {orders.length === 0 ? (
                  <p className="text-xs text-stone-300 py-4 text-center border-2 border-dashed border-stone-100 rounded-2xl">
                    No orders in this status
                  </p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                    {orders.map((order) => (
                      <OrderCard
                        key={order.id}
                        {...order}
                        onAdvance={handleAdvance}
                        isAdvancing={advancingId === order.id}
                      />
                    ))}
                  </div>
                )}
              </section>
            );
          })}

          {totalActive === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-stone-300">
              <span aria-hidden="true" className="text-5xl mb-3">✅</span>
              <p className="text-sm font-semibold">Queue is clear</p>
              <p className="text-xs mt-1">All orders have been fulfilled</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
