/**
 * @file useDeliveryTracking.ts
 * @app apps/staff
 *
 * WebSocket hook for real-time delivery tracking on the Delivery Dispatch page.
 *
 * Connects to wss://api.cannasaas.com/delivery/tracking and receives:
 *   { type: 'DRIVER_LOCATION',  payload: { driverId, lat, lng, orderId, timestamp } }
 *   { type: 'DELIVERY_STATUS',  payload: { orderId, status, driverId, timestamp } }
 *
 * Maintains a live map of driver positions and delivery statuses in local state.
 * The Delivery Dispatch page subscribes to this hook to render the map markers.
 *
 * REST fallback:
 *   If WebSocket is unavailable, GET /delivery/drivers is polled every 15s.
 *
 * Exported:
 *   driverPositions  Record<driverId, { lat, lng, orderId, updatedAt }>
 *   deliveryStatuses Record<orderId, { status, driverId }>
 *   isConnected      boolean
 *   assignDriver(orderId, driverId)  → POST /delivery/assign mutation
 */

import { useEffect, useRef, useState, useCallback } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuthStore, useOrganizationStore } from '@cannasaas/stores';

export interface DriverPosition {
  driverId:  string;
  lat:       number;
  lng:       number;
  orderId?:  string;
  updatedAt: string;
}

export interface DeliveryStatusEntry {
  status:    string;
  driverId?: string;
  updatedAt: string;
}

export function useDeliveryTracking() {
  const { token }           = useAuthStore();
  const { dispensary }      = useOrganizationStore();
  const queryClient         = useQueryClient();
  const wsRef               = useRef<WebSocket | null>(null);
  const reconnectRef        = useRef<ReturnType<typeof setTimeout>>();
  const delayRef            = useRef(1000);

  const [isConnected,       setIsConnected]       = useState(false);
  const [driverPositions,   setDriverPositions]   = useState<Record<string, DriverPosition>>({});
  const [deliveryStatuses,  setDeliveryStatuses]  = useState<Record<string, DeliveryStatusEntry>>({});

  const connect = useCallback(() => {
    if (!token || !dispensary?.id) return;
    const protocol = window.location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${protocol}://api.cannasaas.com/delivery/tracking?dispensaryId=${dispensary.id}&token=${token}`);
    wsRef.current = ws;

    ws.onopen  = () => { setIsConnected(true); delayRef.current = 1000; };
    ws.onerror = () => setIsConnected(false);
    ws.onclose = () => {
      setIsConnected(false);
      const delay = Math.min(delayRef.current, 30_000);
      delayRef.current = delay * 2;
      reconnectRef.current = setTimeout(connect, delay);
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data) as { type: string; payload: any };

        if (msg.type === 'DRIVER_LOCATION') {
          const { driverId, lat, lng, orderId, timestamp } = msg.payload;
          setDriverPositions((prev) => ({
            ...prev,
            [driverId]: { driverId, lat, lng, orderId, updatedAt: timestamp },
          }));
        }

        if (msg.type === 'DELIVERY_STATUS') {
          const { orderId, status, driverId, timestamp } = msg.payload;
          setDeliveryStatuses((prev) => ({
            ...prev,
            [orderId]: { status, driverId, updatedAt: timestamp },
          }));
          // Also invalidate the orders query so the dispatch list refreshes
          queryClient.invalidateQueries({ queryKey: ['deliveryOrders'] });
        }
      } catch {
        // Ignore malformed messages
      }
    };
  }, [token, dispensary?.id, queryClient]);

  useEffect(() => {
    connect();
    return () => { clearTimeout(reconnectRef.current); wsRef.current?.close(); };
  }, [connect]);

  // Assign driver mutation
  const { mutate: assignDriver, isPending: isAssigning } = useMutation({
    mutationFn: async ({ orderId, driverId }: { orderId: string; driverId: string }) => {
      const res = await fetch('/api/v1/delivery/assign', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body:    JSON.stringify({ orderId, driverId }),
      });
      if (!res.ok) throw new Error('Failed to assign driver');
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['deliveryOrders'] }),
  });

  return {
    driverPositions,
    deliveryStatuses,
    isConnected,
    assignDriver: (orderId: string, driverId: string) => assignDriver({ orderId, driverId }),
    isAssigning,
  };
}
