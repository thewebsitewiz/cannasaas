/**
 * @file useOrderQueue.ts
 * @app apps/staff
 *
 * Hybrid TanStack Query + WebSocket hook for real-time order queue data.
 *
 * Strategy:
 *   1. Initial data fetched via GET /orders (TanStack Query, staleTime: 30s)
 *   2. WebSocket at wss://api.cannasaas.com/delivery/tracking sends order
 *      update events; the hook patches the query cache on each event so the
 *      UI reflects changes instantly without a full re-fetch.
 *   3. If the WebSocket disconnects, the hook polls every 30 seconds as a
 *      fallback (refetchInterval).
 *
 * WebSocket message format (from Sprint 10 delivery/notifications module):
 *   { type: 'ORDER_UPDATED', payload: { orderId, status, updatedAt } }
 *   { type: 'ORDER_CREATED', payload: { order } }
 *
 * Exported:
 *   - orders[]   — flat array of all active orders
 *   - grouped    — orders keyed by status for the queue view
 *   - isLoading  — true on initial fetch
 *   - isConnected — WebSocket connection state
 *   - advanceOrder(id, nextStatus) — PUT /orders/:id/status mutation
 *
 * The hook automatically subscribes on mount and cleans up the WebSocket
 * on unmount. Reconnection uses exponential back-off (max 30s).
 */

import { useEffect, useRef, useState, useCallback } from 'react';
import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query';
import { useAuthStore, useOrganizationStore } from '@cannasaas/stores';
import type { OrderStatus } from '../components/ui/OrderCard';

// ── Types ────────────────────────────────────────────────────────────────────

export interface QueueOrder {
  id:              string;
  orderNumber:     string;
  customerName:    string;
  itemCount:       number;
  total:           number;
  status:          OrderStatus;
  fulfillmentType: 'pickup' | 'delivery';
  createdAt:       string;
  updatedAt:       string;
}

export type GroupedOrders = Record<OrderStatus, QueueOrder[]>;

// Active statuses shown in the queue (completed / cancelled are excluded)
const QUEUE_STATUSES: OrderStatus[] = [
  'pending', 'confirmed', 'preparing', 'ready_for_pickup', 'out_for_delivery',
];

// ── Helpers ──────────────────────────────────────────────────────────────────

function groupOrders(orders: QueueOrder[]): GroupedOrders {
  const grouped = {} as GroupedOrders;
  QUEUE_STATUSES.forEach((s) => { grouped[s] = []; });
  orders.forEach((o) => {
    if (QUEUE_STATUSES.includes(o.status)) {
      grouped[o.status].push(o);
    }
  });
  // Sort each group oldest-first so staff work from top to bottom
  QUEUE_STATUSES.forEach((s) => {
    grouped[s].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  });
  return grouped;
}

// ── Hook ─────────────────────────────────────────────────────────────────────

export function useOrderQueue() {
  const queryClient             = useQueryClient();
  const { token }               = useAuthStore();
  const { dispensary }          = useOrganizationStore();
  const wsRef                   = useRef<WebSocket | null>(null);
  const reconnectTimerRef       = useRef<ReturnType<typeof setTimeout>>();
  const reconnectDelayRef       = useRef(1000); // ms, doubles each attempt
  const [isConnected, setIsConnected] = useState(false);

  const QUERY_KEY = ['orderQueue', dispensary?.id];

  // ── Initial REST fetch ───────────────────────────────────────────────────
  const { data: orders = [], isLoading } = useQuery<QueueOrder[]>({
    queryKey: QUERY_KEY,
    queryFn:  async () => {
      const res = await fetch('/api/v1/orders?status=active&limit=100', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error('Failed to fetch orders');
      const data = await res.json();
      return data.data ?? [];
    },
    // Poll as fallback when WebSocket is disconnected
    refetchInterval: isConnected ? false : 30_000,
    staleTime: 30_000,
  });

  // ── Advance order mutation ───────────────────────────────────────────────
  const { mutate: advanceOrder, isPending: isAdvancing } = useMutation({
    mutationFn: async ({ id, next }: { id: string; next: OrderStatus }) => {
      const res = await fetch(`/api/v1/orders/${id}/status`, {
        method:  'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body:    JSON.stringify({ status: next }),
      });
      if (!res.ok) throw new Error('Failed to advance order');
      return res.json();
    },
    onSuccess: (updated: QueueOrder) => {
      // Patch the cached orders array with the updated order
      queryClient.setQueryData<QueueOrder[]>(QUERY_KEY, (prev) =>
        (prev ?? []).map((o) => o.id === updated.id ? updated : o),
      );
    },
  });

  // ── WebSocket setup ──────────────────────────────────────────────────────
  const connect = useCallback(() => {
    if (!token || !dispensary?.id) return;

    const wsUrl = `${window.location.protocol === 'https:' ? 'wss' : 'ws'}://api.cannasaas.com/delivery/tracking?dispensaryId=${dispensary.id}&token=${token}`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
      reconnectDelayRef.current = 1000; // Reset back-off on successful connect
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data) as { type: string; payload: any };

        if (msg.type === 'ORDER_UPDATED') {
          const { orderId, status, updatedAt } = msg.payload;
          queryClient.setQueryData<QueueOrder[]>(QUERY_KEY, (prev) =>
            (prev ?? []).map((o) => o.id === orderId ? { ...o, status, updatedAt } : o),
          );
        }

        if (msg.type === 'ORDER_CREATED') {
          queryClient.setQueryData<QueueOrder[]>(QUERY_KEY, (prev) =>
            [msg.payload.order, ...(prev ?? [])],
          );
        }
      } catch {
        // Silently ignore malformed messages
      }
    };

    ws.onerror = () => setIsConnected(false);

    ws.onclose = () => {
      setIsConnected(false);
      // Exponential back-off reconnect (cap at 30 s)
      const delay = Math.min(reconnectDelayRef.current, 30_000);
      reconnectDelayRef.current = delay * 2;
      reconnectTimerRef.current = setTimeout(connect, delay);
    };
  }, [token, dispensary?.id, queryClient]);

  useEffect(() => {
    connect();
    return () => {
      clearTimeout(reconnectTimerRef.current);
      wsRef.current?.close();
    };
  }, [connect]);

  return {
    orders,
    grouped:    groupOrders(orders),
    isLoading,
    isConnected,
    advanceOrder: (id: string, next: OrderStatus) => advanceOrder({ id, next }),
    isAdvancing,
    queueStatuses: QUEUE_STATUSES,
  };
}
