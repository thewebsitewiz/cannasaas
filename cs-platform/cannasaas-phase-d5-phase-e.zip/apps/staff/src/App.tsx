/**
 * @file App.tsx
 * @app apps/staff
 *
 * Root application component for the Staff Portal.
 *
 * Routing structure:
 *   /login                → StaffLogin (unauthenticated)
 *   /                     → redirect to /orders
 *   /orders               → OrderQueue (lazy)
 *   /customers            → CustomerLookup (lazy)
 *   /inventory            → InventorySearch (lazy)
 *   /delivery             → DeliveryDispatch (lazy)
 *   /quick-actions        → QuickActions (lazy)
 *   *                     → redirect to /orders
 *
 * All authenticated routes are wrapped in StaffLayout and guarded by
 * ProtectedRoute which checks Zustand auth state for role "budtender" or
 * higher. If the user is not authenticated they are redirected to /login.
 *
 * Code splitting: every page is lazy-loaded behind React.lazy + Suspense
 * so the initial bundle only contains the router shell.
 */

import { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { StaffLayout }    from './components/StaffLayout';
import { STAFF_ROUTES }   from './routes';

// Auth guard — checks useAuthStore from @cannasaas/stores
import { useAuthStore } from '@cannasaas/stores';

// Lazy-loaded pages
const StaffLogin       = lazy(() => import('./pages/Login').then((m) => ({ default: m.StaffLogin })));
const OrderQueue       = lazy(() => import('./pages/OrderQueue').then((m) => ({ default: m.OrderQueuePage })));
const CustomerLookup   = lazy(() => import('./pages/CustomerLookup').then((m) => ({ default: m.CustomerLookupPage })));
const InventorySearch  = lazy(() => import('./pages/InventorySearch').then((m) => ({ default: m.InventorySearchPage })));
const DeliveryDispatch = lazy(() => import('./pages/DeliveryDispatch').then((m) => ({ default: m.DeliveryDispatchPage })));
const QuickActions     = lazy(() => import('./pages/QuickActions').then((m) => ({ default: m.QuickActionsPage })));

/** Full-page loading spinner shown during lazy page loads */
function PageLoader() {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-white z-50" role="status" aria-label="Loading page">
      <div className="flex flex-col items-center gap-3">
        <div className="w-8 h-8 border-4 border-[hsl(var(--primary,154_40%_30%))] border-t-transparent rounded-full animate-spin motion-reduce:animate-none" aria-hidden="true" />
        <p className="text-sm text-stone-400">Loading…</p>
      </div>
    </div>
  );
}

/** Wraps authenticated routes — redirects to /login if not authenticated */
function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user } = useAuthStore();
  if (!user) return <Navigate to={STAFF_ROUTES.login} replace />;
  return <>{children}</>;
}

export default function App() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Routes>
        {/* Public */}
        <Route path={STAFF_ROUTES.login} element={<StaffLogin />} />

        {/* Authenticated staff routes inside the shared layout */}
        <Route element={<RequireAuth><StaffLayout /></RequireAuth>}>
          <Route index element={<Navigate to={STAFF_ROUTES.orderQueue} replace />} />
          <Route path={STAFF_ROUTES.orderQueue}      element={<OrderQueue />} />
          <Route path={STAFF_ROUTES.customerLookup}  element={<CustomerLookup />} />
          <Route path={STAFF_ROUTES.inventorySearch} element={<InventorySearch />} />
          <Route path={STAFF_ROUTES.deliveryDispatch} element={<DeliveryDispatch />} />
          <Route path={STAFF_ROUTES.quickActions}    element={<QuickActions />} />
          <Route path="*" element={<Navigate to={STAFF_ROUTES.orderQueue} replace />} />
        </Route>
      </Routes>
    </Suspense>
  );
}
