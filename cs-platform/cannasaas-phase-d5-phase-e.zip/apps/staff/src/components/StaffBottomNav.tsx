/**
 * @file StaffBottomNav.tsx
 * @app apps/staff
 *
 * Fixed bottom navigation bar for mobile screens (< md breakpoint).
 *
 * Shows 5 icon + label tabs; hidden on md+ (replaced by StaffSidebar).
 *
 * Design:
 *   - Full-width white bar with top border shadow
 *   - Active item: primary colour icon + label; inactive: stone-400
 *   - Touch targets: minimum 44×44px (WCAG 2.5.5 AAA, best practice)
 *   - Safe area inset bottom via padding-bottom env() for notched phones
 *
 * Accessibility (WCAG 2.1 AA):
 *   - <nav> with aria-label="Staff mobile navigation" (1.3.1)
 *   - Active link: aria-current="page" (4.1.2)
 *   - Icon + label visible; icon is aria-hidden (1.1.1)
 *   - Minimum touch target 44×44px via min-h + min-w (2.5.5)
 */

import { NavLink, useLocation } from 'react-router-dom';
import { STAFF_ROUTES } from '../routes';

const NAV_ITEMS = [
  { path: STAFF_ROUTES.orderQueue,       label: 'Queue',    icon: '📋' },
  { path: STAFF_ROUTES.customerLookup,   label: 'Customer', icon: '🔍' },
  { path: STAFF_ROUTES.inventorySearch,  label: 'Stock',    icon: '📦' },
  { path: STAFF_ROUTES.deliveryDispatch, label: 'Delivery', icon: '🚗' },
  { path: STAFF_ROUTES.quickActions,     label: 'Actions',  icon: '⚡' },
];

export function StaffBottomNav() {
  const { pathname } = useLocation();

  return (
    <nav
      aria-label="Staff mobile navigation"
      className={[
        'md:hidden fixed bottom-0 left-0 right-0 z-40',
        'bg-white border-t border-stone-200 shadow-[0_-1px_6px_rgba(0,0,0,0.06)]',
        'flex items-stretch',
        // Safe area inset for notched/dynamic-island iPhones
        'pb-[env(safe-area-inset-bottom,0px)]',
      ].join(' ')}
    >
      {NAV_ITEMS.map((item) => {
        const isActive = pathname.startsWith(item.path);
        return (
          <NavLink
            key={item.path}
            to={item.path}
            aria-current={isActive ? 'page' : undefined}
            className={[
              'flex-1 flex flex-col items-center justify-center',
              'min-h-[56px] min-w-[44px] py-2',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[hsl(var(--primary,154_40%_30%))]',
              'transition-colors',
              isActive ? 'text-[hsl(var(--primary,154_40%_30%))]' : 'text-stone-400',
            ].join(' ')}
          >
            <span aria-hidden="true" className="text-xl leading-none">{item.icon}</span>
            <span className={['text-[10px] font-medium mt-0.5', isActive ? 'font-semibold' : ''].join(' ')}>
              {item.label}
            </span>
            {isActive && <span className="sr-only">(current page)</span>}
          </NavLink>
        );
      })}
    </nav>
  );
}
