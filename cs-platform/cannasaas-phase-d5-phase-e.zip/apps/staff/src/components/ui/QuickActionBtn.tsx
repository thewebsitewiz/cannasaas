/**
 * @file QuickActionBtn.tsx
 * @app apps/staff
 *
 * Large tap-friendly action button tile used on the Quick Actions page.
 *
 * Design:
 *   - Square-ish card (min 80px wide, 80px tall)
 *   - Prominent emoji icon + label underneath
 *   - Coloured border on hover/focus; pressed scale animation
 *   - Disabled state dims the tile and prevents interaction
 *
 * Accessibility (WCAG 2.1 AA):
 *   - Renders as a <button> with explicit type="button" (4.1.2)
 *   - Icon is aria-hidden; label is the accessible name (1.1.1)
 *   - Focus ring: 2px solid with offset (2.4.7)
 *   - Disabled: aria-disabled + pointer-events-none (4.1.2)
 *   - Min touch target: 44×44px enforced via min-h / min-w (2.5.5)
 */

interface QuickActionBtnProps {
  icon:      string;        // Emoji or icon character
  label:     string;        // Button label (visible + a11y)
  onClick:   () => void;
  disabled?: boolean;
  variant?:  'default' | 'danger' | 'success';
  badge?:    string | number; // Optional notification badge
}

const VARIANT_CLS = {
  default: 'border-stone-200 hover:border-[hsl(var(--primary,154_40%_30%))] hover:bg-[hsl(var(--primary,154_40%_30%)/0.03)]',
  danger:  'border-stone-200 hover:border-red-400 hover:bg-red-50',
  success: 'border-stone-200 hover:border-green-500 hover:bg-green-50',
};

export function QuickActionBtn({ icon, label, onClick, disabled = false, variant = 'default', badge }: QuickActionBtnProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-disabled={disabled}
      aria-label={label}
      className={[
        'relative flex flex-col items-center justify-center gap-2',
        'min-h-[80px] min-w-[80px] w-full p-4',
        'bg-white border-2 rounded-2xl',
        'transition-all active:scale-[0.97]',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))] focus-visible:ring-offset-2',
        disabled ? 'opacity-40 cursor-not-allowed pointer-events-none' : 'cursor-pointer',
        VARIANT_CLS[variant],
      ].join(' ')}
    >
      {/* Badge (e.g. unread count) */}
      {badge != null && (
        <span
          aria-label={`${badge} pending`}
          className="absolute top-2 right-2 min-w-[18px] h-[18px] bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center px-1"
        >
          {badge}
        </span>
      )}
      <span aria-hidden="true" className="text-2xl leading-none">{icon}</span>
      <span className="text-xs font-semibold text-stone-700 text-center leading-tight">{label}</span>
    </button>
  );
}
