/**
 * @file OrderCard.tsx
 * @app apps/staff
 *
 * Compact order card used in the Order Queue grouped lists.
 *
 * Displays:
 *   - Order number (monospace) + fulfillment type icon
 *   - Customer name
 *   - Item count + total price
 *   - Time elapsed since order was placed (e.g. "12 min ago")
 *   - Status pill
 *   - Advance button: one-click status advancement
 *
 * The advance button label changes based on current status:
 *   pending          → "Confirm"
 *   confirmed        → "Start Prep"
 *   preparing        → "Mark Ready" (pickup) | "Send for Delivery" (delivery)
 *   ready_for_pickup → "Mark Picked Up"
 *   out_for_delivery → "Mark Delivered"
 *
 * Accessibility (WCAG 2.1 AA):
 *   - Card: article element with aria-label (1.3.1)
 *   - Time elapsed: <time dateTime="..."> (1.3.1)
 *   - Advance button: aria-label includes order number (4.1.2)
 *   - Loading state: aria-busy on button (4.1.2)
 */

import { StatusPill } from './StatusPill';

export type OrderStatus =
  | 'pending' | 'confirmed' | 'preparing'
  | 'ready_for_pickup' | 'out_for_delivery'
  | 'delivered' | 'completed' | 'cancelled';

interface OrderCardProps {
  id:              string;
  orderNumber:     string;
  customerName:    string;
  itemCount:       number;
  total:           number;
  status:          OrderStatus;
  fulfillmentType: 'pickup' | 'delivery';
  createdAt:       string;
  onAdvance?:      (id: string, next: OrderStatus) => void;
  isAdvancing?:    boolean;
}

/** Determine the next logical status and button label */
function getAdvance(status: OrderStatus, type: 'pickup' | 'delivery'): { label: string; next: OrderStatus } | null {
  switch (status) {
    case 'pending':          return { label: 'Confirm',          next: 'confirmed'        };
    case 'confirmed':        return { label: 'Start Prep',       next: 'preparing'        };
    case 'preparing':        return type === 'pickup'
      ? { label: 'Mark Ready',     next: 'ready_for_pickup'  }
      : { label: 'Out for Delivery', next: 'out_for_delivery' };
    case 'ready_for_pickup': return { label: 'Mark Picked Up',   next: 'completed'        };
    case 'out_for_delivery': return { label: 'Mark Delivered',   next: 'delivered'        };
    default:                 return null;
  }
}

function timeAgo(iso: string): string {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 60_000);
  if (diff < 1)  return 'just now';
  if (diff < 60) return `${diff} min ago`;
  return `${Math.floor(diff / 60)}h ${diff % 60}m ago`;
}

export function OrderCard({
  id, orderNumber, customerName, itemCount, total,
  status, fulfillmentType, createdAt, onAdvance, isAdvancing = false,
}: OrderCardProps) {
  const advance = getAdvance(status, fulfillmentType);

  return (
    <article
      aria-label={`Order #${orderNumber} — ${customerName}`}
      className="bg-white border border-stone-200 rounded-2xl shadow-sm p-4 flex flex-col gap-3 hover:shadow-md transition-shadow"
    >
      {/* ── Header row ───────────────────────────────────────── */}
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="flex items-center gap-1.5">
            <span aria-hidden="true" className="text-base">
              {fulfillmentType === 'delivery' ? '🚗' : '🛍️'}
            </span>
            <span className="text-xs font-mono font-bold text-stone-800">
              #{orderNumber.toUpperCase()}
            </span>
          </div>
          <p className="text-sm font-semibold text-stone-900 mt-0.5">{customerName}</p>
        </div>
        <StatusPill status={status} />
      </div>

      {/* ── Meta row ─────────────────────────────────────────── */}
      <div className="flex items-center justify-between text-xs text-stone-400">
        <span>{itemCount} item{itemCount !== 1 ? 's' : ''} · <strong className="text-stone-700">${total.toFixed(2)}</strong></span>
        <time dateTime={createdAt} title={new Date(createdAt).toLocaleString()}>
          {timeAgo(createdAt)}
        </time>
      </div>

      {/* ── Advance button ────────────────────────────────────── */}
      {advance && onAdvance && (
        <button
          type="button"
          disabled={isAdvancing}
          aria-busy={isAdvancing}
          aria-label={`${advance.label} — order #${orderNumber}`}
          onClick={() => onAdvance(id, advance.next)}
          className={[
            'w-full py-2.5 rounded-xl text-sm font-bold transition-all',
            'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))] focus-visible:ring-offset-1',
            'disabled:opacity-60 disabled:cursor-wait',
            'bg-[hsl(var(--primary,154_40%_30%))] text-white hover:brightness-110 active:scale-[0.98]',
          ].join(' ')}
        >
          {isAdvancing ? '…' : advance.label}
        </button>
      )}

      {/* Completed / cancelled — no action */}
      {(status === 'completed' || status === 'cancelled' || status === 'delivered') && (
        <p className="text-xs text-center text-stone-400 py-1">
          {status === 'completed' ? '✅ Completed' : status === 'delivered' ? '📦 Delivered' : '❌ Cancelled'}
        </p>
      )}
    </article>
  );
}
