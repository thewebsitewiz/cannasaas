/**
 * @file StatusPill.tsx
 * @app apps/staff
 *
 * Compact status pill badge optimised for the staff portal context.
 *
 * Uses colour + text label so status is never conveyed by colour alone (WCAG 1.4.1).
 *
 * Accessibility (WCAG 2.1 AA):
 *   - aria-label on the outer span carries the full "Status: <value>" label (4.1.2)
 *   - Colour differences have ≥ 3:1 contrast against the white card background (1.4.3)
 */

export type PillStatus =
  | 'pending' | 'confirmed' | 'preparing'
  | 'ready_for_pickup' | 'out_for_delivery'
  | 'delivered' | 'completed' | 'cancelled' | 'refunded'
  | 'active' | 'inactive';

const CONFIG: Record<PillStatus, { label: string; cls: string }> = {
  pending:          { label: '⏳ Pending',        cls: 'bg-amber-50  text-amber-800  border-amber-200'  },
  confirmed:        { label: '✅ Confirmed',       cls: 'bg-blue-50   text-blue-800   border-blue-200'   },
  preparing:        { label: '⚗️ Preparing',       cls: 'bg-purple-50 text-purple-800 border-purple-200' },
  ready_for_pickup: { label: '🛍️ Ready',           cls: 'bg-teal-50   text-teal-800   border-teal-200'   },
  out_for_delivery: { label: '🚗 En Route',        cls: 'bg-indigo-50 text-indigo-800 border-indigo-200' },
  delivered:        { label: '📦 Delivered',       cls: 'bg-sky-50    text-sky-800    border-sky-200'    },
  completed:        { label: '🎉 Completed',       cls: 'bg-green-50  text-green-800  border-green-200'  },
  cancelled:        { label: '❌ Cancelled',       cls: 'bg-red-50    text-red-800    border-red-200'    },
  refunded:         { label: '↩️ Refunded',        cls: 'bg-stone-50  text-stone-600  border-stone-200'  },
  active:           { label: '● Active',           cls: 'bg-green-50  text-green-700  border-green-200'  },
  inactive:         { label: '○ Inactive',         cls: 'bg-stone-50  text-stone-500  border-stone-200'  },
};

interface StatusPillProps { status: PillStatus; className?: string }

export function StatusPill({ status, className = '' }: StatusPillProps) {
  const cfg = CONFIG[status] ?? { label: status, cls: 'bg-stone-50 text-stone-600 border-stone-200' };
  return (
    <span
      aria-label={`Status: ${cfg.label.replace(/^[^\s]+\s/, '')}`}
      className={[
        'inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold border whitespace-nowrap',
        cfg.cls, className,
      ].join(' ')}
    >
      {cfg.label}
    </span>
  );
}
