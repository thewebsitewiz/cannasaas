/**
 * @file StaffSidebar.tsx
 * @app apps/staff
 *
 * Desktop left sidebar navigation for the Staff Portal.
 *
 * Visible only on md+ screens (hidden on mobile — replaced by StaffBottomNav).
 *
 * Contents:
 *   - Dispensary name + logo (from useOrganizationStore)
 *   - Navigation links (5 pages) with active indicator
 *   - Connection status indicator (WebSocket live indicator)
 *   - Bottom: logged-in user name, role badge, logout button
 *
 * Active link detection: uses useLocation().pathname.startsWith(route.path)
 * so nested routes (e.g. /orders/123) still highlight the parent nav item.
 *
 * Accessibility (WCAG 2.1 AA):
 *   - <nav> with aria-label="Staff navigation" (1.3.1)
 *   - Active link: aria-current="page" (4.1.2)
 *   - Logout button: aria-label (4.1.2)
 *   - Connection badge: role="status" aria-label (4.1.3)
 */

import { useLocation, NavLink } from 'react-router-dom';
import { useAuthStore, useOrganizationStore } from '@cannasaas/stores';
import { STAFF_ROUTES } from '../routes';

const NAV_ITEMS = [
  { path: STAFF_ROUTES.orderQueue,       label: 'Order Queue',       icon: '📋' },
  { path: STAFF_ROUTES.customerLookup,   label: 'Customer Lookup',   icon: '🔍' },
  { path: STAFF_ROUTES.inventorySearch,  label: 'Inventory',         icon: '📦' },
  { path: STAFF_ROUTES.deliveryDispatch, label: 'Delivery Dispatch', icon: '🚗' },
  { path: STAFF_ROUTES.quickActions,     label: 'Quick Actions',     icon: '⚡' },
];

const ROLE_LABELS: Record<string, string> = {
  budtender: 'Budtender',
  manager:   'Manager',
  driver:    'Driver',
  admin:     'Admin',
};

interface StaffSidebarProps {
  /** If true, a green dot is shown indicating live WebSocket connection */
  isConnected?: boolean;
}

export function StaffSidebar({ isConnected = false }: StaffSidebarProps) {
  const { user, logout }       = useAuthStore();
  const { dispensary }         = useOrganizationStore();
  const { pathname }           = useLocation();

  const primaryRole = user?.roles?.[0] ?? 'budtender';

  return (
    <aside
      aria-label="Staff navigation"
      className="hidden md:flex flex-col w-[220px] bg-white border-r border-stone-200 flex-shrink-0 h-full"
    >
      {/* ── Brand header ───────────────────────────────────────────── */}
      <div className="px-4 py-5 border-b border-stone-100">
        <div className="flex items-center gap-2.5">
          <div aria-hidden="true" className="w-8 h-8 rounded-lg bg-[hsl(var(--primary,154_40%_30%))] flex items-center justify-center text-white text-sm font-extrabold flex-shrink-0">
            {(dispensary?.name ?? 'S')[0].toUpperCase()}
          </div>
          <div className="min-w-0">
            <p className="text-xs font-extrabold text-stone-900 truncate">{dispensary?.name ?? 'Staff Portal'}</p>
            <p className="text-[10px] text-stone-400">Staff Interface</p>
          </div>
        </div>
        {/* WebSocket connection indicator */}
        <div
          role="status"
          aria-label={isConnected ? 'Live updates connected' : 'Live updates disconnected'}
          className="flex items-center gap-1.5 mt-3"
        >
          <span
            aria-hidden="true"
            className={['w-2 h-2 rounded-full flex-shrink-0',
              isConnected ? 'bg-green-400 animate-pulse motion-reduce:animate-none' : 'bg-stone-300'].join(' ')}
          />
          <span className={['text-[10px] font-medium', isConnected ? 'text-green-600' : 'text-stone-400'].join(' ')}>
            {isConnected ? 'Live' : 'Offline'}
          </span>
        </div>
      </div>

      {/* ── Navigation links ───────────────────────────────────────── */}
      <nav aria-label="Main staff navigation" className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const isActive = pathname.startsWith(item.path);
          return (
            <NavLink
              key={item.path}
              to={item.path}
              aria-current={isActive ? 'page' : undefined}
              className={[
                'flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-all',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))] focus-visible:ring-offset-1',
                isActive
                  ? 'bg-[hsl(var(--primary,154_40%_30%)/0.08)] text-[hsl(var(--primary,154_40%_30%))] font-semibold'
                  : 'text-stone-500 hover:bg-stone-50 hover:text-stone-800',
              ].join(' ')}
            >
              <span aria-hidden="true" className="text-base">{item.icon}</span>
              <span>{item.label}</span>
              {isActive && (
                <span className="sr-only">(current page)</span>
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* ── User info + logout ─────────────────────────────────────── */}
      <div className="px-4 py-4 border-t border-stone-100">
        <div className="flex items-center gap-2.5 mb-2.5">
          <div aria-hidden="true" className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center text-xs font-bold text-stone-500 flex-shrink-0">
            {(user?.firstName?.[0] ?? '?').toUpperCase()}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold text-stone-800 truncate">
              {user?.firstName} {user?.lastName}
            </p>
            <span className="inline-block px-1.5 py-0.5 text-[9px] font-bold bg-[hsl(var(--primary,154_40%_30%)/0.08)] text-[hsl(var(--primary,154_40%_30%))] rounded capitalize">
              {ROLE_LABELS[primaryRole] ?? primaryRole}
            </span>
          </div>
        </div>
        <button
          type="button"
          onClick={() => logout()}
          aria-label="Log out of staff portal"
          className="w-full text-xs text-stone-400 hover:text-stone-600 hover:bg-stone-50 py-1.5 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-stone-400"
        >
          Log out
        </button>
      </div>
    </aside>
  );
}
