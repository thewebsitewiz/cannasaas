/**
 * @file StaffLayout.tsx
 * @app apps/staff
 *
 * Responsive shell layout for all authenticated Staff Portal pages.
 *
 * Layout behaviour:
 *   Mobile  (< md):  Full-screen main content + fixed bottom navigation bar (StaffBottomNav)
 *   Desktop (≥ md):  Left sidebar (StaffSidebar, 220px fixed) + scrollable main content
 *
 * The layout renders <Outlet /> from React Router v6 in the main content area
 * so every child page receives the correct positioning context.
 *
 * Skip link:
 *   The very first focusable element is a "Skip to main content" link that
 *   becomes visible on focus. It targets #staff-main to bypass the nav on
 *   each page load for keyboard / screen reader users.
 *
 * Accessibility (WCAG 2.1 AA):
 *   - Skip navigation link: visible on focus (2.4.1)
 *   - main landmark: id="staff-main" with tabIndex={-1} for skip target (1.3.1)
 *   - nav landmark: provided by StaffSidebar / StaffBottomNav (1.3.1)
 *   - Keyboard trap prevention: no modal-style shells (2.1.2)
 */

import { useRef, useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { StaffSidebar }   from './StaffSidebar';
import { StaffBottomNav } from './StaffBottomNav';

export function StaffLayout() {
  const mainRef = useRef<HTMLElement>(null);
  const { pathname } = useLocation();

  /** Move focus to main on route change — helps screen reader users */
  useEffect(() => {
    mainRef.current?.focus();
  }, [pathname]);

  return (
    <div className="flex h-screen bg-stone-50 overflow-hidden">
      {/* Skip navigation link — only visible on keyboard focus */}
      <a
        href="#staff-main"
        className={[
          'sr-only focus:not-sr-only focus:fixed focus:z-[100] focus:top-3 focus:left-3',
          'focus:bg-[hsl(var(--primary,154_40%_30%))] focus:text-white',
          'focus:px-4 focus:py-2 focus:rounded-xl focus:text-sm focus:font-semibold',
          'focus:shadow-lg focus:outline-none',
        ].join(' ')}
      >
        Skip to main content
      </a>

      {/* Desktop sidebar — hidden on mobile */}
      <StaffSidebar />

      {/* Main content area */}
      <main
        id="staff-main"
        ref={mainRef}
        tabIndex={-1}
        className={[
          'flex-1 overflow-y-auto outline-none',
          // On mobile: add padding-bottom for the fixed bottom nav bar
          'pb-20 md:pb-0',
          // Page content padding
          'px-4 py-4 md:px-6 md:py-6',
        ].join(' ')}
      >
        <Outlet />
      </main>

      {/* Mobile bottom navigation — hidden on desktop */}
      <StaffBottomNav />
    </div>
  );
}
