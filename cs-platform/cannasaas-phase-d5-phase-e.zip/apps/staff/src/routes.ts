/**
 * @file routes.ts
 * @app apps/staff
 *
 * Centralised route path constants for the Staff Portal.
 * Import this module wherever links or navigation calls reference a route
 * so that path changes only need to be made in one place.
 */

export const STAFF_ROUTES = {
  /** Unauthenticated */
  login:              '/login',

  /** Main pages */
  orderQueue:         '/orders',
  customerLookup:     '/customers',
  inventorySearch:    '/inventory',
  deliveryDispatch:   '/delivery',
  quickActions:       '/quick-actions',
} as const;
