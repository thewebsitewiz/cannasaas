/**
 * @file SettingsStaff.tsx
 * @app apps/admin
 *
 * Staff account management inside the Settings page.
 *
 * Features:
 *   - Staff table: name, email, role badge, status, last login
 *   - Invite new staff: email + role dropdown → POST /users
 *   - Change role inline: select dropdown → PUT /users/:id/roles
 *   - Deactivate / reactivate → PUT /users/:id { isActive }
 *
 * Roles available to assign: admin | manager | budtender | driver
 *
 * Accessibility (WCAG 2.1 AA):
 *   - Table: <table> with <caption> (1.3.1)
 *   - Role selects: aria-label includes staff name (4.1.2)
 *   - Action buttons: aria-label includes staff name (4.1.2)
 *   - Invite form: labeled inputs, aria-required (1.3.5)
 *   - Table loading: aria-busy (4.1.2)
 */

import { useState, useId } from 'react';
import { useStaffUsers, useInviteUser, useUpdateUserRole, useToggleUserActive } from '@cannasaas/api-client';
import { StatusBadge } from '../ui/StatusBadge';
import { LoadingSpinner } from '../ui/LoadingSpinner';

type StaffRole = 'admin' | 'manager' | 'budtender' | 'driver';

interface StaffMember {
  id: string; firstName: string; lastName: string;
  email: string; roles: StaffRole[]; isActive: boolean; lastLoginAt?: string;
}

const ROLE_COLORS: Record<StaffRole, string> = {
  admin:     'bg-purple-100 text-purple-700',
  manager:   'bg-blue-100 text-blue-700',
  budtender: 'bg-green-100 text-green-700',
  driver:    'bg-amber-100 text-amber-700',
};

export function SettingsStaff() {
  const { data: staff = [], isLoading, refetch } = useStaffUsers();
  const { mutate: inviteUser,  isPending: isInviting } = useInviteUser();
  const { mutate: updateRole } = useUpdateUserRole();
  const { mutate: toggleActive } = useToggleUserActive();

  const [showInvite, setShowInvite] = useState(false);
  const [invite, setInvite] = useState({ email: '', role: 'manager' as StaffRole });

  const emailId = useId();
  const roleId  = useId();

  const inputCls  = 'w-full px-3 py-2 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:border-[hsl(var(--primary,154_40%_30%)/0.4)]';
  const selectCls = 'text-xs border border-stone-200 rounded-lg px-2 py-1.5 bg-white appearance-none cursor-pointer focus:outline-none focus:ring-1 text-stone-700';

  const handleInvite = () => {
    if (!invite.email) return;
    inviteUser({ email: invite.email, roles: [invite.role] }, {
      onSuccess: () => { refetch(); setShowInvite(false); setInvite({ email: '', role: 'manager' }); },
    });
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between pb-2 border-b border-stone-100">
        <h3 className="text-sm font-bold text-stone-900">Staff Accounts</h3>
        <button type="button" onClick={() => setShowInvite((s) => !s)}
          className="px-3 py-2 text-sm font-semibold bg-[hsl(var(--primary,154_40%_30%))] text-white rounded-xl hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))] transition-all">
          {showInvite ? '✕ Cancel' : '+ Invite Staff'}
        </button>
      </div>

      {/* Invite form */}
      {showInvite && (
        <div className="border border-[hsl(var(--primary,154_40%_30%)/0.2)] rounded-2xl p-4 bg-[hsl(var(--primary,154_40%_30%)/0.02)] space-y-3">
          <p className="text-xs font-bold text-stone-700">Invite New Staff Member</p>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1">
              <label htmlFor={emailId} className="block text-xs font-semibold text-stone-600 mb-1">
                Email Address <span aria-hidden="true" className="text-red-500">*</span>
              </label>
              <input id={emailId} type="email" required aria-required="true" value={invite.email}
                onChange={(e) => setInvite((i) => ({ ...i, email: e.target.value }))}
                placeholder="staff@dispensary.com" className={inputCls} />
            </div>
            <div>
              <label htmlFor={roleId} className="block text-xs font-semibold text-stone-600 mb-1">Role</label>
              <select id={roleId} value={invite.role} onChange={(e) => setInvite((i) => ({ ...i, role: e.target.value as StaffRole }))}
                className={selectCls + ' py-2 pl-3 pr-8'}>
                <option value="admin">Admin</option>
                <option value="manager">Manager</option>
                <option value="budtender">Budtender</option>
                <option value="driver">Driver</option>
              </select>
            </div>
          </div>
          <button type="button" onClick={handleInvite} disabled={!invite.email || isInviting}
            className="px-4 py-2 text-sm font-semibold bg-[hsl(var(--primary,154_40%_30%))] text-white rounded-xl hover:brightness-110 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))] transition-all">
            {isInviting ? 'Sending…' : 'Send Invite'}
          </button>
        </div>
      )}

      {/* Staff table */}
      <div aria-busy={isLoading} className="overflow-x-auto">
        <table className="w-full text-sm">
          <caption className="sr-only">Staff accounts list</caption>
          <thead>
            <tr className="border-b border-stone-100">
              <th scope="col" className="text-left pb-2 text-xs font-semibold text-stone-500 uppercase tracking-wider">Staff Member</th>
              <th scope="col" className="text-left pb-2 text-xs font-semibold text-stone-500 uppercase tracking-wider hidden sm:table-cell">Role</th>
              <th scope="col" className="pb-2 text-xs font-semibold text-stone-500 uppercase tracking-wider hidden md:table-cell">Last Login</th>
              <th scope="col" className="pb-2 text-xs font-semibold text-stone-500 uppercase tracking-wider w-8"><span className="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-50">
            {isLoading ? Array.from({ length: 4 }).map((_, i) => (
              <tr key={i} aria-hidden="true">
                <td className="py-3"><div className="h-4 w-32 bg-stone-100 rounded animate-pulse motion-reduce:animate-none" /></td>
                <td className="py-3 hidden sm:table-cell"><div className="h-5 w-16 bg-stone-100 rounded-full animate-pulse" /></td>
                <td className="py-3 hidden md:table-cell"><div className="h-4 w-24 bg-stone-100 rounded animate-pulse" /></td>
                <td />
              </tr>
            )) : (staff as StaffMember[]).map((member) => {
              const fullName    = `${member.firstName} ${member.lastName}`;
              const primaryRole = member.roles[0] ?? 'budtender';
              return (
                <tr key={member.id} className="hover:bg-stone-50/50 transition-colors">
                  <td className="py-3 pr-4">
                    <p className="text-xs font-semibold text-stone-900">{fullName}</p>
                    <p className="text-[10px] text-stone-400">{member.email}</p>
                  </td>
                  <td className="py-3 hidden sm:table-cell">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full capitalize ${ROLE_COLORS[primaryRole as StaffRole] ?? 'bg-stone-100 text-stone-600'}`}>
                        {primaryRole}
                      </span>
                      {!member.isActive && <StatusBadge status="inactive" />}
                    </div>
                  </td>
                  <td className="py-3 hidden md:table-cell">
                    {member.lastLoginAt ? (
                      <time dateTime={member.lastLoginAt} className="text-[10px] text-stone-400">
                        {new Date(member.lastLoginAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </time>
                    ) : <span className="text-[10px] text-stone-300">Never</span>}
                  </td>
                  <td className="py-3">
                    <div className="flex items-center gap-1">
                      <select
                        value={primaryRole}
                        onChange={(e) => updateRole({ userId: member.id, role: e.target.value as StaffRole }, { onSuccess: refetch })}
                        aria-label={`Change role for ${fullName}`}
                        className={selectCls + ' py-1 pl-2 pr-5 text-[10px]'}>
                        <option value="admin">Admin</option>
                        <option value="manager">Manager</option>
                        <option value="budtender">Budtender</option>
                        <option value="driver">Driver</option>
                      </select>
                      <button type="button"
                        onClick={() => toggleActive({ userId: member.id, isActive: !member.isActive }, { onSuccess: refetch })}
                        aria-label={member.isActive ? `Deactivate ${fullName}` : `Reactivate ${fullName}`}
                        className={['text-[10px] px-2 py-1 rounded-lg font-semibold transition-colors focus-visible:outline-none focus-visible:ring-1',
                          member.isActive ? 'text-red-600 hover:bg-red-50 focus-visible:ring-red-400' : 'text-green-600 hover:bg-green-50 focus-visible:ring-green-400'].join(' ')}>
                        {member.isActive ? 'Deactivate' : 'Reactivate'}
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {!isLoading && (staff as StaffMember[]).length === 0 && (
          <p className="text-sm text-stone-400 text-center py-6">No staff members yet. Invite someone to get started.</p>
        )}
      </div>
    </div>
  );
}
