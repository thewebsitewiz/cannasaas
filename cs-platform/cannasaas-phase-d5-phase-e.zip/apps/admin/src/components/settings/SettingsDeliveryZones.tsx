/**
 * @file SettingsDeliveryZones.tsx
 * @app apps/admin
 *
 * Delivery zone management inside the Settings page.
 *
 * Features:
 *   - Zone list showing name, fee, min order, estimated delivery time
 *   - Create zone form (name, fee, min order, ETA minutes)
 *   - Delete zone with ConfirmDialog
 *
 * Map integration note:
 *   A full Leaflet + leaflet-draw polygon editor would render in the blue
 *   placeholder region. The component provides a skip link so keyboard users
 *   can bypass the map entirely and use the text-based zone form instead.
 *
 * API:
 *   GET    /delivery/zones          → list zones
 *   POST   /delivery/zones          → create zone
 *   DELETE /delivery/zones/:id      → delete zone
 *
 * Accessibility (WCAG 2.1 AA):
 *   - Map region: role="img" aria-label + skip link (2.1.1)
 *   - Zone list: role="list" + role="listitem" (1.3.1)
 *   - Delete button: aria-label includes zone name (4.1.2)
 *   - Form inputs: htmlFor labels + aria-required (1.3.5)
 *   - Confirm dialog: focus trap on open (2.1.2)
 */

import { useState, useId } from 'react';
import { useDeliveryZones, useCreateDeliveryZone, useDeleteDeliveryZone } from '@cannasaas/api-client';
import { ConfirmDialog } from '../ui/ConfirmDialog';
import { LoadingSpinner } from '../ui/LoadingSpinner';

interface Zone {
  id: string; name: string;
  deliveryFee: number; minOrderValue: number; estimatedMinutes: number;
}

export function SettingsDeliveryZones() {
  const { data: zones = [], isLoading, refetch } = useDeliveryZones();
  const { mutate: createZone, isPending: isCreating } = useCreateDeliveryZone();
  const { mutate: deleteZone, isPending: isDeleting } = useDeleteDeliveryZone();

  const [showForm,       setShowForm]       = useState(false);
  const [confirmDelete,  setConfirmDelete]  = useState<string | null>(null);
  const [form, setForm] = useState({ name: '', deliveryFee: 5, minOrderValue: 30, estimatedMinutes: 45 });

  const nameId = useId(); const feeId = useId(); const minId = useId(); const etaId = useId();
  const inputCls = 'w-full px-3 py-2 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:border-[hsl(var(--primary,154_40%_30%)/0.4)]';

  const handleCreate = () => {
    if (!form.name) return;
    createZone({ ...form, polygon: { type: 'Polygon', coordinates: [] } }, {
      onSuccess: () => { refetch(); setShowForm(false); setForm({ name: '', deliveryFee: 5, minOrderValue: 30, estimatedMinutes: 45 }); },
    });
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between pb-2 border-b border-stone-100">
        <h3 className="text-sm font-bold text-stone-900">Delivery Zones</h3>
        <button type="button" onClick={() => setShowForm((s) => !s)}
          className="px-3 py-2 text-sm font-semibold bg-[hsl(var(--primary,154_40%_30%))] text-white rounded-xl hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))] transition-all">
          {showForm ? '✕ Cancel' : '+ Add Zone'}
        </button>
      </div>

      {/* Map placeholder */}
      <div className="relative rounded-2xl overflow-hidden border border-stone-200">
        <a href="#zones-list" className="sr-only focus:not-sr-only focus:absolute focus:z-20 focus:top-2 focus:left-2 focus:bg-white focus:text-stone-900 focus:px-3 focus:py-1.5 focus:rounded-lg focus:shadow-lg focus:text-sm">
          Skip map and go to zone list
        </a>
        <div role="img" aria-label="Delivery zone polygon map — use the list below to manage zones" className="h-52 bg-gradient-to-br from-blue-50 to-stone-100 flex items-center justify-center">
          <div className="text-center">
            <span aria-hidden="true" className="text-4xl block mb-2">🗺️</span>
            <p className="text-xs font-medium text-stone-600">Interactive polygon editor</p>
            <p className="text-[10px] text-stone-400 mt-0.5">react-leaflet + leaflet-draw renders here</p>
          </div>
        </div>
      </div>

      {/* Create form */}
      {showForm && (
        <div className="border border-[hsl(var(--primary,154_40%_30%)/0.2)] rounded-2xl p-4 bg-[hsl(var(--primary,154_40%_30%)/0.02)] space-y-3">
          <p className="text-xs font-bold text-stone-700">New Delivery Zone</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div><label htmlFor={nameId} className="block text-xs font-semibold text-stone-600 mb-1">Zone Name <span aria-hidden="true" className="text-red-500">*</span></label>
              <input id={nameId} type="text" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="e.g. Brooklyn North" className={inputCls} /></div>
            <div><label htmlFor={minId} className="block text-xs font-semibold text-stone-600 mb-1">Min Order ($)</label>
              <input id={minId} type="number" min="0" step="5" value={form.minOrderValue} onChange={(e) => setForm((f) => ({ ...f, minOrderValue: +e.target.value }))} className={inputCls} /></div>
            <div><label htmlFor={feeId} className="block text-xs font-semibold text-stone-600 mb-1">Delivery Fee ($)</label>
              <input id={feeId} type="number" min="0" step="0.5" value={form.deliveryFee} onChange={(e) => setForm((f) => ({ ...f, deliveryFee: +e.target.value }))} className={inputCls} /></div>
            <div><label htmlFor={etaId} className="block text-xs font-semibold text-stone-600 mb-1">Estimated Time (min)</label>
              <input id={etaId} type="number" min="10" step="5" value={form.estimatedMinutes} onChange={(e) => setForm((f) => ({ ...f, estimatedMinutes: +e.target.value }))} className={inputCls} /></div>
          </div>
          <button type="button" onClick={handleCreate} disabled={!form.name || isCreating}
            className="px-4 py-2 text-sm font-semibold bg-[hsl(var(--primary,154_40%_30%))] text-white rounded-xl hover:brightness-110 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))] transition-all">
            {isCreating ? 'Creating…' : 'Create Zone'}
          </button>
        </div>
      )}

      {/* Zones list */}
      <div id="zones-list">
        {isLoading ? (
          <div className="flex items-center justify-center h-24" aria-busy="true"><LoadingSpinner label="Loading zones…" /></div>
        ) : (zones as Zone[]).length === 0 ? (
          <p className="text-sm text-stone-400 text-center py-6">No delivery zones configured.</p>
        ) : (
          <ul role="list" className="space-y-2">
            {(zones as Zone[]).map((z) => (
              <li key={z.id} role="listitem" className="flex items-center justify-between gap-4 p-4 border border-stone-200 rounded-2xl hover:bg-stone-50 transition-colors">
                <div>
                  <p className="text-sm font-semibold text-stone-800">{z.name}</p>
                  <p className="text-xs text-stone-400">Min ${z.minOrderValue} · Fee ${z.deliveryFee} · ~{z.estimatedMinutes} min</p>
                </div>
                <button type="button" onClick={() => setConfirmDelete(z.id)} aria-label={`Delete zone ${z.name}`}
                  className="w-7 h-7 flex items-center justify-center text-stone-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-red-400">
                  <svg aria-hidden="true" className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <ConfirmDialog isOpen={!!confirmDelete} onClose={() => setConfirmDelete(null)}
        onConfirm={() => deleteZone(confirmDelete!, { onSuccess: () => { setConfirmDelete(null); refetch(); } })}
        title="Delete Delivery Zone"
        description="This zone will be removed. Existing orders in this zone will not be affected."
        confirmLabel="Delete Zone" isLoading={isDeleting} />
    </div>
  );
}
