/**
 * @file SettingsBranding.tsx
 * @app apps/admin
 *
 * Branding configuration panel inside the Settings page.
 *
 * Three sub-sections:
 *
 * 1. LOGO UPLOAD
 *    Drag-and-drop zone + file input fallback.
 *    Previews existing logo; uploads to S3 via POST /dispensaries/:id/branding/logo.
 *    Accepted: PNG, SVG, WebP, JPEG · Max 2MB.
 *
 * 2. COLOUR PALETTE
 *    Three brand colours: primary, secondary, accent.
 *    Each: native <input type="color"> paired with a hex text input.
 *    A mini "sample button" previews how the colour looks in context.
 *
 * 3. FONT SELECTION
 *    Dropdown from curated 8-font list.
 *    Preview paragraph updates live via inline style.
 *
 * Changes are collected by the parent Settings form and saved via
 *   PUT /dispensaries/:id/branding { primaryColor, secondaryColor, accentColor, fontFamily, logoUrl }
 *
 * Accessibility (WCAG 2.1 AA):
 *   - Logo drop zone: role="region" aria-label, keyboard activated via Enter/Space (2.1.1)
 *   - Each colour input: htmlFor label (1.3.5); native picker + hex text input side-by-side
 *   - Sample buttons are aria-hidden (decorative previews) (1.1.1)
 *   - Font preview: aria-hidden (decorative) (1.1.1)
 *   - Upload progress: aria-live="polite" (4.1.3)
 */

import { useState, useRef, useId } from 'react';
import { useFormContext } from 'react-hook-form';

const FONTS = [
  { label: 'System UI (default)', value: 'system-ui' },
  { label: 'Inter',               value: 'Inter' },
  { label: 'DM Sans',             value: 'DM Sans' },
  { label: 'Plus Jakarta Sans',   value: 'Plus Jakarta Sans' },
  { label: 'Nunito',              value: 'Nunito' },
  { label: 'Poppins',             value: 'Poppins' },
  { label: 'Merriweather',        value: 'Merriweather' },
];

interface ColorRowProps { label: string; value: string; onChange: (v: string) => void }

function ColorRow({ label, value, onChange }: ColorRowProps) {
  const pickerId = useId();
  const hexId    = useId();
  return (
    <div className="flex items-center gap-3">
      <span className="text-xs font-semibold text-stone-700 w-20 flex-shrink-0">{label}</span>
      <label htmlFor={pickerId} className="sr-only">{label} colour picker</label>
      <input id={pickerId} type="color" value={value} onChange={(e) => onChange(e.target.value)}
        className="w-9 h-9 rounded-lg border border-stone-200 cursor-pointer p-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-400 focus-visible:ring-offset-1" />
      <label htmlFor={hexId} className="sr-only">{label} hex value</label>
      <input id={hexId} type="text" value={value}
        onChange={(e) => /^#[0-9A-Fa-f]{0,6}$/.test(e.target.value) && onChange(e.target.value)}
        maxLength={7} placeholder="#000000"
        className="w-24 px-2.5 py-1.5 text-sm font-mono border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:border-[hsl(var(--primary,154_40%_30%)/0.4)] uppercase" />
      <div aria-hidden="true" className="flex items-center gap-2 overflow-hidden">
        <span className="px-3 py-1 rounded-lg text-xs font-semibold text-white shadow-sm" style={{ backgroundColor: value }}>Button</span>
        <span className="w-4 h-4 rounded-full border-2 border-white shadow-sm" style={{ backgroundColor: value }} />
      </div>
    </div>
  );
}

interface SettingsBrandingProps { dispensaryId: string; existingLogoUrl?: string }

export function SettingsBranding({ dispensaryId, existingLogoUrl }: SettingsBrandingProps) {
  const { register, watch, setValue } = useFormContext();
  const [isDragOver,  setIsDragOver]  = useState(false);
  const [uploading,   setUploading]   = useState(false);
  const [uploadMsg,   setUploadMsg]   = useState('');
  const [logoPreview, setLogoPreview] = useState(existingLogoUrl ?? '');
  const fileRef = useRef<HTMLInputElement>(null);
  const fontId  = useId();

  const primary   = watch('primaryColor')   ?? '#1f6342';
  const secondary = watch('secondaryColor') ?? '#f59e0b';
  const accent    = watch('accentColor')    ?? '#3b82f6';
  const font      = watch('fontFamily')     ?? 'system-ui';

  const handleFile = async (file: File) => {
    if (!file.type.startsWith('image/') || file.size > 2 * 1024 * 1024) return;
    setUploading(true);
    setUploadMsg('Uploading logo…');
    setLogoPreview(URL.createObjectURL(file));
    try {
      const fd = new FormData();
      fd.append('logo', file);
      const res  = await fetch(`/api/v1/dispensaries/${dispensaryId}/branding/logo`, { method: 'POST', body: fd });
      const data = await res.json();
      if (data.url) { setValue('logoUrl', data.url); setLogoPreview(data.url); setUploadMsg('Logo uploaded.'); }
    } catch { setUploadMsg('Upload failed. Please try again.'); }
    finally   { setUploading(false); setTimeout(() => setUploadMsg(''), 3000); }
  };

  return (
    <div className="space-y-6">
      <h3 className="text-sm font-bold text-stone-900 pb-2 border-b border-stone-100">Branding</h3>

      {/* Logo */}
      <div>
        <p className="text-xs font-semibold text-stone-700 mb-2">Dispensary Logo</p>
        <div className="flex items-start gap-4">
          <div aria-hidden="true" className="w-16 h-16 rounded-xl border-2 border-stone-200 bg-stone-50 flex items-center justify-center overflow-hidden flex-shrink-0">
            {logoPreview ? <img src={logoPreview} alt="" className="w-full h-full object-contain p-1" /> : <span className="text-2xl">🏪</span>}
          </div>
          <div
            role="region" aria-label="Logo upload area. Drag and drop or press Enter to browse." aria-busy={uploading}
            tabIndex={0}
            onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && fileRef.current?.click()}
            onClick={() => fileRef.current?.click()}
            onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
            onDragLeave={() => setIsDragOver(false)}
            onDrop={(e) => { e.preventDefault(); setIsDragOver(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
            className={['flex-1 border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))]',
              isDragOver ? 'border-[hsl(var(--primary,154_40%_30%))] bg-[hsl(var(--primary,154_40%_30%)/0.03)]' : 'border-stone-200 hover:border-stone-300'].join(' ')}
          >
            <p className="text-xs text-stone-500">{uploading ? 'Uploading…' : isDragOver ? 'Drop to upload' : 'Drag & drop or click to browse'}</p>
            <p className="text-[10px] text-stone-400 mt-0.5">PNG, SVG, WebP · Max 2MB</p>
          </div>
          <input ref={fileRef} type="file" accept="image/*" aria-label="Select logo image" className="sr-only"
            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
        </div>
        <p aria-live="polite" className="text-xs text-stone-500 mt-1">{uploadMsg}</p>
      </div>

      {/* Colours */}
      <div>
        <p className="text-xs font-semibold text-stone-700 mb-3">Brand Colours</p>
        <div className="space-y-3">
          <ColorRow label="Primary"   value={primary}   onChange={(v) => setValue('primaryColor', v)} />
          <ColorRow label="Secondary" value={secondary} onChange={(v) => setValue('secondaryColor', v)} />
          <ColorRow label="Accent"    value={accent}    onChange={(v) => setValue('accentColor', v)} />
        </div>
      </div>

      {/* Font */}
      <div>
        <label htmlFor={fontId} className="block text-xs font-semibold text-stone-700 mb-1.5">Storefront Font</label>
        <select id={fontId} {...register('fontFamily')}
          className="py-2 pl-3 pr-8 text-sm border border-stone-200 rounded-xl bg-white appearance-none cursor-pointer focus:outline-none focus:ring-1 w-56"
          style={{ fontFamily: font }}>
          {FONTS.map((f) => <option key={f.value} value={f.value} style={{ fontFamily: f.value }}>{f.label}</option>)}
        </select>
      </div>

      {/* Live preview */}
      <div aria-hidden="true" className="rounded-2xl border border-stone-200 p-4 bg-white">
        <p className="text-[10px] font-semibold text-stone-400 uppercase tracking-wider mb-3">Preview</p>
        <div style={{ fontFamily: font }} className="space-y-2">
          <div className="flex items-center gap-2">
            {logoPreview
              ? <img src={logoPreview} alt="" className="w-7 h-7 rounded object-contain" />
              : <div className="w-7 h-7 rounded flex items-center justify-center text-white text-xs font-bold" style={{ backgroundColor: primary }}>D</div>}
            <span className="text-sm font-bold" style={{ color: primary }}>Your Dispensary</span>
          </div>
          <div className="flex gap-2">
            <button style={{ backgroundColor: primary }} className="px-3 py-1 text-white text-xs font-semibold rounded-lg">Shop Now</button>
            <button style={{ borderColor: secondary, color: secondary }} className="px-3 py-1 text-xs font-semibold rounded-lg border">Learn More</button>
            <button style={{ backgroundColor: accent }} className="px-3 py-1 text-white text-xs font-semibold rounded-lg">Order</button>
          </div>
        </div>
      </div>
    </div>
  );
}
