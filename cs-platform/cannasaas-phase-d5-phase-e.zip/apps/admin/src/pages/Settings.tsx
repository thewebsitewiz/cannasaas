/**
 * @file Settings.tsx
 * @app apps/admin
 *
 * Settings page — tabbed management panel.
 *
 * Four tabs:
 *   1. Profile    — dispensary name, operating hours, contact info, license
 *   2. Branding   — SettingsBranding component (logo, colours, font)
 *   3. Delivery   — SettingsDeliveryZones component
 *   4. Staff      — SettingsStaff component
 *
 * Profile form fields:
 *   - Dispensary name (text, required)
 *   - Phone (tel input)
 *   - Email (email input)
 *   - Website (url input)
 *   - License number (read-only — set at company level)
 *   - Operating hours: per-day open/close time selects, closed toggle
 *
 * Submit: PUT /dispensaries/:id with the full form body.
 *
 * Uses React Hook Form with FormProvider so sub-components (SettingsBranding)
 * can access the form context via useFormContext().
 *
 * Auto-saves indication: "Saved ✓" toast appears for 3 seconds after PUT.
 *
 * Accessibility (WCAG 2.1 AA):
 *   - document.title updated (2.4.2)
 *   - Tabs: role="tablist" / role="tab" / role="tabpanel" with aria-selected (4.1.2)
 *   - Tab panel: aria-labelledby links panel to its tab (1.3.1)
 *   - Hours form: fieldset per day with <legend> (1.3.1)
 *   - Save button: aria-busy during save (4.1.2)
 *   - Success toast: role="status" aria-live="polite" (4.1.3)
 */

import { useState, useEffect, useId } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import { useDispensary, useUpdateDispensary } from '@cannasaas/api-client';
import { useOrganizationStore } from '@cannasaas/stores';
import { PageHeader }             from '../components/ui/PageHeader';
import { LoadingSpinner }         from '../components/ui/LoadingSpinner';
import { SettingsBranding }       from '../components/settings/SettingsBranding';
import { SettingsDeliveryZones }  from '../components/settings/SettingsDeliveryZones';
import { SettingsStaff }          from '../components/settings/SettingsStaff';

type TabId = 'profile' | 'branding' | 'delivery' | 'staff';

const TABS: { id: TabId; label: string; icon: string }[] = [
  { id: 'profile',  label: 'Profile',  icon: '🏪' },
  { id: 'branding', label: 'Branding', icon: '🎨' },
  { id: 'delivery', label: 'Delivery', icon: '🚗' },
  { id: 'staff',    label: 'Staff',    icon: '👥' },
];

const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'] as const;
type Day = typeof DAYS[number];

const HOURS = Array.from({ length: 29 }, (_, i) => {
  const h = Math.floor(i / 2) + 7;
  const m = i % 2 === 0 ? '00' : '30';
  const hh = h % 12 === 0 ? 12 : h % 12;
  const ampm = h < 12 ? 'AM' : 'PM';
  return { value: `${String(h).padStart(2, '0')}:${m}`, label: `${hh}:${m} ${ampm}` };
});

export function SettingsPage() {
  const [activeTab, setActiveTab] = useState<TabId>('profile');
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const tablistId = useId();
  const { dispensary } = useOrganizationStore();

  const { data: settings, isLoading } = useDispensary(dispensary?.id ?? '');
  const { mutate: updateDispensary, isPending: isSaving } = useUpdateDispensary(dispensary?.id ?? '');

  useEffect(() => { document.title = 'Settings | CannaSaas Admin'; }, []);

  const methods = useForm({ defaultValues: { name: '', phone: '', email: '', website: '', primaryColor: '#1f6342', secondaryColor: '#f59e0b', accentColor: '#3b82f6', fontFamily: 'system-ui', logoUrl: '', hours: {} as Record<Day, { open: string; close: string; closed: boolean }> } });
  const { register, handleSubmit, reset, formState: { isDirty } } = methods;

  useEffect(() => { if (settings) reset(settings); }, [settings, reset]);

  const onSubmit = (data: any) => {
    setSaveStatus('saving');
    updateDispensary(data, {
      onSuccess: () => { setSaveStatus('saved'); setTimeout(() => setSaveStatus('idle'), 3000); },
      onError:   () => { setSaveStatus('error');  setTimeout(() => setSaveStatus('idle'), 5000); },
    });
  };

  const inputCls = 'w-full px-3 py-2.5 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:border-[hsl(var(--primary,154_40%_30%)/0.4)]';

  if (isLoading) return <div className="flex items-center justify-center h-64"><LoadingSpinner size="lg" label="Loading settings…" /></div>;

  return (
    <FormProvider {...methods}>
      <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-6 max-w-3xl">
        {/* Header */}
        <div className="flex items-start justify-between">
          <PageHeader title="Settings" description="Manage your dispensary configuration" />
          <div className="flex items-center gap-3 flex-shrink-0">
            <span aria-live="polite" role="status" className="text-xs font-medium">
              {saveStatus === 'saved' && <span className="text-green-600">✓ Saved</span>}
              {saveStatus === 'error' && <span className="text-red-600">Save failed</span>}
            </span>
            <button type="submit" disabled={isSaving || !isDirty} aria-busy={isSaving}
              className="px-4 py-2 text-sm font-bold bg-[hsl(var(--primary,154_40%_30%))] text-white rounded-xl hover:brightness-110 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))] transition-all">
              {isSaving ? 'Saving…' : 'Save Changes'}
            </button>
          </div>
        </div>

        {/* Tab navigation */}
        <div role="tablist" id={tablistId} aria-label="Settings sections"
          className="flex items-center gap-1 border-b border-stone-200 overflow-x-auto pb-px">
          {TABS.map((tab) => (
            <button key={tab.id} type="button" role="tab"
              id={`stab-${tab.id}`} aria-selected={activeTab === tab.id} aria-controls={`spanel-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={['flex items-center gap-1.5 px-3 py-2.5 text-xs font-medium whitespace-nowrap border-b-2 -mb-px transition-colors',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))] focus-visible:ring-inset',
                activeTab === tab.id ? 'border-[hsl(var(--primary,154_40%_30%))] text-[hsl(var(--primary,154_40%_30%))]' : 'border-transparent text-stone-500 hover:text-stone-700'].join(' ')}>
              <span aria-hidden="true">{tab.icon}</span>{tab.label}
            </button>
          ))}
        </div>

        {/* Tab panels */}
        <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-6">
          {/* Profile */}
          <div role="tabpanel" id="spanel-profile" aria-labelledby="stab-profile" hidden={activeTab !== 'profile'}>
            <div className="space-y-5">
              <h3 className="text-sm font-bold text-stone-900 pb-2 border-b border-stone-100">Dispensary Profile</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">Dispensary Name <span aria-hidden="true" className="text-red-500">*</span></label>
                  <input {...register('name', { required: true })} type="text" placeholder="Green Leaf Brooklyn" className={inputCls} required />
                </div>
                <div><label className="block text-xs font-semibold text-stone-700 mb-1.5">Phone</label>
                  <input {...register('phone')} type="tel" placeholder="+1 (718) 555-0100" className={inputCls} /></div>
                <div><label className="block text-xs font-semibold text-stone-700 mb-1.5">Email</label>
                  <input {...register('email')} type="email" placeholder="contact@dispensary.com" className={inputCls} /></div>
                <div className="sm:col-span-2"><label className="block text-xs font-semibold text-stone-700 mb-1.5">Website</label>
                  <input {...register('website')} type="url" placeholder="https://www.dispensary.com" className={inputCls} /></div>
                {settings?.licenseNumber && (
                  <div className="sm:col-span-2">
                    <p className="text-xs font-semibold text-stone-700 mb-1.5">License Number</p>
                    <p className="font-mono text-sm text-stone-600 bg-stone-50 border border-stone-100 rounded-xl px-3 py-2.5">{settings.licenseNumber}</p>
                    <p className="text-[10px] text-stone-400 mt-1">License is set at the company level. Contact your account manager to update.</p>
                  </div>
                )}
              </div>

              {/* Operating hours */}
              <div>
                <h4 className="text-xs font-bold text-stone-900 mb-3">Operating Hours</h4>
                <div className="space-y-2">
                  {DAYS.map((day) => (
                    <fieldset key={day} className="flex items-center gap-3 flex-wrap">
                      <legend className="text-xs font-semibold text-stone-700 w-24 flex-shrink-0">{day.slice(0, 3)}</legend>
                      <label className="flex items-center gap-1.5 text-xs text-stone-500 cursor-pointer">
                        <input {...register(`hours.${day}.closed`)} type="checkbox"
                          className="w-3.5 h-3.5 rounded text-[hsl(var(--primary,154_40%_30%))]" />
                        Closed
                      </label>
                      <div className="flex items-center gap-2">
                        <select {...register(`hours.${day}.open`)} aria-label={`${day} opening time`}
                          className="text-xs border border-stone-200 rounded-lg px-2 py-1.5 bg-white appearance-none cursor-pointer focus:outline-none focus:ring-1 text-stone-700">
                          {HOURS.map((h) => <option key={h.value} value={h.value}>{h.label}</option>)}
                        </select>
                        <span aria-hidden="true" className="text-stone-400 text-xs">–</span>
                        <select {...register(`hours.${day}.close`)} aria-label={`${day} closing time`}
                          className="text-xs border border-stone-200 rounded-lg px-2 py-1.5 bg-white appearance-none cursor-pointer focus:outline-none focus:ring-1 text-stone-700">
                          {HOURS.map((h) => <option key={h.value} value={h.value}>{h.label}</option>)}
                        </select>
                      </div>
                    </fieldset>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Branding */}
          <div role="tabpanel" id="spanel-branding" aria-labelledby="stab-branding" hidden={activeTab !== 'branding'}>
            <SettingsBranding dispensaryId={dispensary?.id ?? ''} existingLogoUrl={settings?.logoUrl} />
          </div>

          {/* Delivery zones */}
          <div role="tabpanel" id="spanel-delivery" aria-labelledby="stab-delivery" hidden={activeTab !== 'delivery'}>
            <SettingsDeliveryZones />
          </div>

          {/* Staff */}
          <div role="tabpanel" id="spanel-staff" aria-labelledby="stab-staff" hidden={activeTab !== 'staff'}>
            <SettingsStaff />
          </div>
        </div>
      </form>
    </FormProvider>
  );
}
