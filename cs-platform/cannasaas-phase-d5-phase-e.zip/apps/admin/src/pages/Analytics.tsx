/**
 * @file Analytics.tsx
 * @app apps/admin
 *
 * Extended analytics dashboard page.
 *
 * Layout (responsive):
 *   Row 1: 4 KPI StatsCards with range selector + CSV Export button
 *   Row 2: Revenue over time — AreaChart (full width)
 *   Row 3: Orders by fulfillment (BarChart 1/2) | Top products pie (PieChart 1/2)
 *   Row 4: Customer acquisition (LineChart 1/2) | Conversion funnel (custom 1/2)
 *   Row 5: Product performance table (full width)
 *
 * Data sources:
 *   GET /analytics/dashboard?range=30d   → KPIs, revenue by day, top products
 *   GET /analytics/products?range=30d    → product performance table
 *   GET /analytics/customers?range=30d   → acquisition/funnel
 *   GET /analytics/export?format=csv     → CSV blob download
 *
 * Each chart has:
 *   - role="img" aria-label summarising the data (WCAG 1.1.1)
 *   - <details> data table alternative for screen readers (WCAG 1.1.1)
 *
 * Accessibility (WCAG 2.1 AA):
 *   - document.title updated (2.4.2)
 *   - Range selector: role="radiogroup" (4.1.2)
 *   - CSV export: aria-live announces state changes (4.1.3)
 *   - Chart colours + separate legends / labels (1.4.1)
 *   - prefers-reduced-motion: disables Recharts animation (2.3.3)
 */

import { useState, useEffect, useId } from 'react';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  Legend, ResponsiveContainer,
} from 'recharts';
import {
  useDashboardAnalytics, useAnalyticsProducts,
  useAnalyticsCustomers, useExportAnalytics,
} from '@cannasaas/api-client';
import { PageHeader } from '../components/ui/PageHeader';
import { StatsCard }  from '../components/ui/StatsCard';
import { LoadingSpinner } from '../components/ui/LoadingSpinner';

type DateRange = '7d' | '30d' | '90d' | '12m';
const RANGES: { value: DateRange; label: string }[] = [
  { value: '7d', label: '7 days' }, { value: '30d', label: '30 days' },
  { value: '90d', label: '90 days' }, { value: '12m', label: '12 months' },
];

const PALETTE = [
  'hsl(154,40%,30%)', 'hsl(215,70%,55%)', 'hsl(270,50%,60%)',
  'hsl(35,80%,55%)',  'hsl(0,65%,55%)',
];

const noAnim = () =>
  typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/** Compact tooltip */
function ChartTip({ active, payload, label, fmt }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-stone-100 rounded-xl shadow-lg p-3 text-xs">
      {label && <p className="font-semibold text-stone-700 mb-1">{label}</p>}
      {payload.map((p: any) => (
        <p key={p.dataKey} className="font-bold" style={{ color: p.color }}>
          {p.name}: {fmt ? fmt(p.value) : p.value?.toLocaleString()}
        </p>
      ))}
    </div>
  );
}

/** Reusable chart card with loading, aria wrapper, and data table toggle */
function ChartCard({ title, ariaLabel, loading, children, tableAlt, className = '' }: {
  title: string; ariaLabel: string; loading?: boolean;
  children: React.ReactNode; tableAlt?: React.ReactNode; className?: string;
}) {
  return (
    <div className={`bg-white rounded-2xl border border-stone-200 shadow-sm p-5 ${className}`}>
      <h2 className="text-sm font-bold text-stone-900 mb-4">{title}</h2>
      {loading ? (
        <div className="flex items-center justify-center h-52" aria-busy="true">
          <LoadingSpinner label={`Loading ${title}…`} />
        </div>
      ) : (
        <>
          <div role="img" aria-label={ariaLabel} className="h-52">{children}</div>
          {tableAlt && (
            <details className="mt-3">
              <summary className="text-xs text-stone-400 cursor-pointer hover:text-stone-600 focus-visible:outline-none focus-visible:underline">View data table</summary>
              <div className="overflow-x-auto mt-2 text-xs">{tableAlt}</div>
            </details>
          )}
        </>
      )}
    </div>
  );
}

/** Horizontal funnel bars */
function Funnel({ steps, loading }: { steps?: { label: string; value: number; pct: number }[]; loading?: boolean }) {
  const defaults = [
    { label: 'Visitors', value: 0, pct: 100 },
    { label: 'Product Views', value: 0, pct: 0 },
    { label: 'Add to Cart', value: 0, pct: 0 },
    { label: 'Checkout', value: 0, pct: 0 },
    { label: 'Orders', value: 0, pct: 0 },
  ];
  const data = steps ?? defaults;
  return (
    <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-5">
      <h2 className="text-sm font-bold text-stone-900 mb-4">Conversion Funnel</h2>
      {loading ? <div className="flex items-center justify-center h-52" aria-busy="true"><LoadingSpinner label="Loading funnel…" /></div> : (
        <ol role="list" className="space-y-3 mt-2">
          {data.map((step, i) => (
            <li key={step.label}>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-stone-700">{step.label}</span>
                <span className="text-stone-400">{step.value.toLocaleString()} ({step.pct.toFixed(1)}%)</span>
              </div>
              <div className="h-2 bg-stone-100 rounded-full overflow-hidden" aria-hidden="true">
                <div className="h-full rounded-full transition-all duration-700"
                  style={{ width: `${step.pct}%`, backgroundColor: PALETTE[i % PALETTE.length] }} />
              </div>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

export function AnalyticsPage() {
  const [range, setRange] = useState<DateRange>('30d');
  const [csvState, setCsvState] = useState<'idle' | 'loading' | 'done' | 'error'>('idle');
  const rangeId = useId();
  const skip    = noAnim();

  useEffect(() => { document.title = 'Analytics | CannaSaas Admin'; }, []);

  const { data: dash, isLoading: dL }  = useDashboardAnalytics({ range });
  const { data: prods, isLoading: pL } = useAnalyticsProducts({ range });
  const { data: custs, isLoading: cL } = useAnalyticsCustomers({ range });
  const { mutate: exportCsv }          = useExportAnalytics();

  // Chart data transforms
  const revData = (dash?.revenue?.byDay ?? []).map((d: any) => ({
    date:    new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    revenue: d.revenue ?? 0, orders: d.orders ?? 0,
  }));
  const fulfData  = [
    { name: 'Pickup',   value: dash?.fulfillmentSplit?.pickup   ?? 0 },
    { name: 'Delivery', value: dash?.fulfillmentSplit?.delivery ?? 0 },
  ];
  const topPie = (dash?.topProducts ?? []).slice(0, 5).map((p: any) => ({ name: p.name, value: p.revenue ?? 0 }));
  const acqData = (custs?.acquisition ?? []).map((d: any) => ({
    date:      new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    new:       d.new ?? 0, returning: d.returning ?? 0,
  }));

  const $f = (n: number) => `$${n.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
  const $k = (n: number) => `$${(n / 1000).toFixed(1)}k`;

  const handleExport = () => {
    setCsvState('loading');
    exportCsv({ range }, {
      onSuccess: (blob: Blob) => {
        const url = URL.createObjectURL(blob);
        const a   = Object.assign(document.createElement('a'), { href: url, download: `analytics-${range}.csv` });
        a.click();
        URL.revokeObjectURL(url);
        setCsvState('done');
        setTimeout(() => setCsvState('idle'), 4000);
      },
      onError: () => { setCsvState('error'); setTimeout(() => setCsvState('idle'), 5000); },
    });
  };

  return (
    <div className="space-y-6 max-w-screen-2xl">
      {/* Header + controls */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <PageHeader title="Analytics" description="Dispensary performance metrics" />
        <div className="flex items-center gap-3 flex-shrink-0 flex-wrap">
          {/* Range */}
          <div role="radiogroup" id={rangeId} aria-label="Analytics date range" className="flex items-center bg-stone-100 rounded-xl p-0.5">
            {RANGES.map((r) => (
              <button key={r.value} type="button" role="radio" aria-checked={range === r.value}
                onClick={() => setRange(r.value)}
                className={['px-3 py-1.5 text-xs font-medium rounded-lg transition-all focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-stone-400',
                  range === r.value ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-500 hover:text-stone-700'].join(' ')}>
                {r.label}
              </button>
            ))}
          </div>
          {/* CSV export */}
          <button type="button" onClick={handleExport} disabled={csvState === 'loading'}
            aria-busy={csvState === 'loading'} aria-label="Export analytics as CSV file"
            className="flex items-center gap-1.5 px-3 py-2 text-sm font-semibold border border-stone-200 rounded-xl bg-white hover:bg-stone-50 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-400 transition-all">
            <span aria-hidden="true">{csvState === 'loading' ? '⏳' : csvState === 'done' ? '✅' : '⬇️'}</span>
            {csvState === 'loading' ? 'Exporting…' : csvState === 'done' ? 'Downloaded!' : 'Export CSV'}
          </button>
          <span aria-live="polite" className="sr-only">
            {csvState === 'loading' ? 'Preparing CSV…' : csvState === 'done' ? 'CSV ready.' : csvState === 'error' ? 'Export failed.' : ''}
          </span>
        </div>
      </div>

      {/* KPI row */}
      <section aria-label="Key performance indicators">
        <h2 className="sr-only">Key Performance Indicators</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          <StatsCard title="Total Revenue"   value={dash ? $f(dash.revenue?.total ?? 0) : '$0'}         change={dash?.revenue?.change}        changeLabel="vs prev period" icon="💰" isLoading={dL} />
          <StatsCard title="Total Orders"    value={dash ? (dash.orders?.total ?? 0).toLocaleString() : '0'} change={dash?.orders?.change}     changeLabel="vs prev period" icon="📦" isLoading={dL} />
          <StatsCard title="New Customers"   value={custs ? (custs.newCount ?? 0).toLocaleString() : '0'} change={custs?.newChange}           changeLabel="vs prev period" icon="👥" isLoading={cL} />
          <StatsCard title="Avg Order Value" value={dash ? $f(dash.avgOrderValue?.value ?? 0) : '$0'}    change={dash?.avgOrderValue?.change}  changeLabel="vs prev period" icon="🧾" isLoading={dL} />
        </div>
      </section>

      {/* Revenue area chart */}
      <ChartCard title="Revenue Over Time"
        ariaLabel={`Revenue area chart for last ${range}. Total: ${$f(dash?.revenue?.total ?? 0)}`}
        loading={dL}
        tableAlt={
          <table className="w-full">
            <caption className="sr-only">Daily revenue data</caption>
            <thead><tr className="border-b border-stone-100"><th scope="col" className="text-left py-1 pr-3 text-stone-500">Date</th><th scope="col" className="text-right py-1 text-stone-500">Revenue</th><th scope="col" className="text-right py-1 text-stone-500">Orders</th></tr></thead>
            <tbody>{revData.map((r) => <tr key={r.date}><td className="py-1 pr-3 text-stone-600">{r.date}</td><td className="py-1 text-right">{$f(r.revenue)}</td><td className="py-1 text-right">{r.orders}</td></tr>)}</tbody>
          </table>
        }
      >
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={revData} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="rg" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor={PALETTE[0]} stopOpacity={0.15} />
                <stop offset="95%" stopColor={PALETTE[0]} stopOpacity={0.01} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
            <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#9ca3af' }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
            <YAxis tick={{ fontSize: 10, fill: '#9ca3af' }} tickLine={false} axisLine={false} tickFormatter={$k} width={44} />
            <Tooltip content={<ChartTip fmt={$f} />} cursor={{ stroke: '#e7e5e4', strokeWidth: 1 }} />
            <Area type="monotone" dataKey="revenue" name="Revenue" stroke={PALETTE[0]} strokeWidth={2} fill="url(#rg)" dot={false} isAnimationActive={!skip()} />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Fulfillment + top products */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard title="Orders by Fulfillment Type"
          ariaLabel={`Bar chart: ${fulfData.map((f) => `${f.name} ${f.value}`).join(', ')} orders`}
          loading={dL}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={fulfData} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#9ca3af' }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 10, fill: '#9ca3af' }} tickLine={false} axisLine={false} width={36} />
              <Tooltip content={<ChartTip />} cursor={{ fill: '#f9fafb' }} />
              <Bar dataKey="value" name="Orders" isAnimationActive={!skip()} radius={[6, 6, 0, 0]}>
                {fulfData.map((_, i) => <Cell key={i} fill={PALETTE[i % PALETTE.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Top Products by Revenue"
          ariaLabel={`Pie chart: ${topPie.map((p) => `${p.name} ${$f(p.value)}`).join(', ')}`}
          loading={dL}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={topPie} cx="50%" cy="50%" outerRadius={80} dataKey="value" nameKey="name"
                isAnimationActive={!skip()}
                label={({ name, percent }) => `${String(name).slice(0, 8)} ${(percent * 100).toFixed(0)}%`}
                labelLine={false}>
                {topPie.map((_, i) => <Cell key={i} fill={PALETTE[i % PALETTE.length]} />)}
              </Pie>
              <Tooltip content={<ChartTip fmt={$f} />} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Customer acquisition + funnel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard title="Customer Acquisition"
          ariaLabel={`Line chart of new and returning customers over last ${range}`}
          loading={cL}
          tableAlt={
            <table className="w-full">
              <caption className="sr-only">Customer acquisition by day</caption>
              <thead><tr className="border-b border-stone-100"><th scope="col" className="text-left py-1 pr-3 text-stone-500">Date</th><th scope="col" className="text-right py-1 text-stone-500">New</th><th scope="col" className="text-right py-1 text-stone-500">Returning</th></tr></thead>
              <tbody>{acqData.map((d) => <tr key={d.date}><td className="py-1 pr-3 text-stone-600">{d.date}</td><td className="py-1 text-right">{d.new}</td><td className="py-1 text-right">{d.returning}</td></tr>)}</tbody>
            </table>
          }
        >
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={acqData} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#9ca3af' }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
              <YAxis tick={{ fontSize: 10, fill: '#9ca3af' }} tickLine={false} axisLine={false} width={32} />
              <Tooltip content={<ChartTip />} cursor={{ stroke: '#e7e5e4' }} />
              <Legend iconType="line" wrapperStyle={{ fontSize: 11 }} />
              <Line type="monotone" dataKey="new"       name="New"       stroke={PALETTE[0]} strokeWidth={2} dot={false} isAnimationActive={!skip()} />
              <Line type="monotone" dataKey="returning" name="Returning" stroke={PALETTE[1]} strokeWidth={2} dot={false} strokeDasharray="4 3" isAnimationActive={!skip()} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <Funnel steps={custs?.funnel} loading={cL} />
      </div>

      {/* Product performance table */}
      <section aria-label="Product performance table">
        <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-5">
          <h2 className="text-sm font-bold text-stone-900 mb-4">Product Performance</h2>
          {pL ? (
            <div className="flex items-center justify-center h-32" aria-busy="true"><LoadingSpinner label="Loading products…" /></div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <caption className="sr-only">Product performance for selected period</caption>
                <thead>
                  <tr className="border-b border-stone-100">
                    <th scope="col" className="text-left pb-2 text-xs font-semibold text-stone-500 uppercase tracking-wider">Product</th>
                    <th scope="col" className="text-right pb-2 text-xs font-semibold text-stone-500 uppercase tracking-wider hidden sm:table-cell">Units</th>
                    <th scope="col" className="text-right pb-2 text-xs font-semibold text-stone-500 uppercase tracking-wider">Revenue</th>
                    <th scope="col" className="pb-2 w-28 hidden md:table-cell"><span className="sr-only">Revenue share</span></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-50">
                  {(prods?.data ?? []).map((p: any, i: number) => {
                    const maxR  = Math.max(...(prods?.data ?? []).map((x: any) => x.revenue), 1);
                    const share = ((p.revenue / maxR) * 100).toFixed(0);
                    return (
                      <tr key={p.productId} className="hover:bg-stone-50/50 transition-colors">
                        <td className="py-2.5 pr-4">
                          <div className="flex items-center gap-2">
                            <span aria-hidden="true" className="text-xs font-bold text-stone-300 w-4 text-center">{i + 1}</span>
                            <p className="text-xs font-semibold text-stone-800">{p.name}</p>
                          </div>
                        </td>
                        <td className="py-2.5 text-right text-xs text-stone-500 hidden sm:table-cell">{p.quantity?.toLocaleString()}</td>
                        <td className="py-2.5 text-right text-xs font-bold">{$f(p.revenue)}</td>
                        <td className="py-2.5 hidden md:table-cell pl-4">
                          <div className="flex items-center gap-1.5">
                            <div className="flex-1 h-1.5 bg-stone-100 rounded-full overflow-hidden" aria-hidden="true">
                              <div className="h-full bg-[hsl(var(--primary,154_40%_30%))] rounded-full" style={{ width: `${share}%` }} />
                            </div>
                            <span className="text-[10px] text-stone-400 w-6 text-right">{share}%</span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
