/**
 * @file index.ts
 * @package @cannasaas/api-client
 *
 * Barrel export for the entire @cannasaas/api-client package.
 *
 * ── Phase F Hook Coverage Map ───────────────────────────────────────────────
 *
 * Backend Endpoint           │ Hook                  │ File
 * ───────────────────────────┼───────────────────────┼───────────────────────
 * POST /auth/login           │ useLogin              │ hooks/useAuth.ts
 * POST /auth/register        │ useRegister           │ hooks/useAuth.ts
 * POST /auth/refresh         │ (internal, axiosClient)│ axiosClient.ts
 * GET  /auth/profile         │ useCurrentUser        │ hooks/useAuth.ts
 * GET  /products             │ useProducts           │ hooks/useProducts.ts
 * GET  /products/:id         │ useProduct            │ hooks/useProducts.ts
 * POST /products             │ useCreateProduct      │ hooks/useProducts.ts
 * PUT  /products/:id         │ useUpdateProduct      │ hooks/useProducts.ts
 * GET  /products/low-stock   │ useLowStockProducts   │ hooks/useProducts.ts
 * GET  /cart                 │ useCart               │ hooks/useCart.ts
 * POST /cart/items           │ useAddToCart (optim.) │ hooks/useCart.ts
 * PUT  /cart/items/:id       │ useUpdateCartItem     │ hooks/useCart.ts
 * DELETE /cart/items/:id     │ useRemoveCartItem     │ hooks/useCart.ts
 * POST /cart/promo           │ useApplyPromo         │ hooks/useCart.ts
 * GET  /orders               │ useOrders             │ hooks/useOrders.ts
 * POST /orders               │ useCreateOrder        │ hooks/useOrders.ts
 * GET  /orders/:id           │ useOrder              │ hooks/useOrders.ts
 * PUT  /orders/:id/status    │ useUpdateOrderStatus  │ hooks/useDelivery.ts
 * GET  /analytics/dashboard  │ useDashboardAnalytics │ hooks/useAnalytics.ts
 * GET  /analytics/products   │ useAnalyticsProducts  │ hooks/useAnalytics.ts
 * GET  /analytics/customers  │ useAnalyticsCustomers │ hooks/useAnalytics.ts
 * GET  /analytics/export     │ useExportAnalytics    │ hooks/useAnalytics.ts
 * GET  /users                │ useUsers, useStaff…   │ hooks/useUsers.ts
 * POST /users                │ useInviteUser         │ hooks/useUsers.ts
 * PUT  /users/:id/roles      │ useUpdateUserRole     │ hooks/useUsers.ts
 * GET  /compliance/logs      │ useComplianceLogs     │ hooks/useCompliance.ts
 * GET  /compliance/purchase… │ useCustomerPurchase…  │ hooks/useCompliance.ts
 * GET  /dispensaries         │ useDispensaries       │ hooks/useDispensaries.ts
 * GET  /dispensaries/:id     │ useDispensary         │ hooks/useDispensaries.ts
 * GET  /dispensaries/nearby  │ useNearbyDispensaries │ hooks/useDispensaries.ts
 * PUT  /dispensaries/:id     │ useUpdateDispensary   │ hooks/useDispensaries.ts
 * GET  /delivery/zones       │ useDeliveryZones      │ hooks/useDelivery.ts
 * POST /delivery/zones       │ useCreateDelivery…    │ hooks/useDelivery.ts
 * GET  /delivery/drivers     │ useAvailableDrivers   │ hooks/useDelivery.ts
 * POST /delivery/assign      │ useAssignDriver       │ hooks/useDelivery.ts
 * GET  /search               │ useProductSearch      │ hooks/useSearch.ts
 * GET  /search/suggest       │ useSearchSuggestions  │ hooks/useSearch.ts
 * GET  /reviews/:productId   │ useProductReviews     │ hooks/useRecommendations.ts
 * POST /ai/recommendations   │ useRecommendations    │ hooks/useRecommendations.ts
 * POST /ai/product-desc…     │ useGenerate…          │ hooks/useAI.ts
 * POST /ai/chatbot           │ useDispensaryChatbot  │ hooks/useAI.ts
 * POST /age-verification/…   │ useVerifyCustomer     │ hooks/useCustomers.ts
 *
 * ── QueryClient ──────────────────────────────────────────────────────────────
 *
 * The `queryClient` singleton should be imported by each app's main.tsx:
 *   import { queryClient } from '@cannasaas/api-client';
 *   <QueryClientProvider client={queryClient}>...</QueryClientProvider>
 */

// ── QueryClient ───────────────────────────────────────────────────────────────
export { queryClient } from './lib/queryClient';

// ── Axios client ──────────────────────────────────────────────────────────────
export { apiClient, wireAuthToAxios } from './axiosClient';
export type { NormalisedApiError } from './axiosClient';

// ── Endpoints ────────────────────────────────────────────────────────────────
export { ENDPOINTS_ADDENDUM } from './endpoints.addendum';

// ── Auth ─────────────────────────────────────────────────────────────────────
export {
  useLogin, useRegister, useLogout, useCurrentUser, useUpdateProfile,
  authKeys,
} from './hooks/useAuth';

// ── Products ─────────────────────────────────────────────────────────────────
export {
  useProducts, useProduct, useCreateProduct, useUpdateProduct, useDeleteProduct,
  useLowStockProducts, useProductCategories,
  productKeys,
} from './hooks/useProducts';

// ── Cart (with optimistic updates) ───────────────────────────────────────────
export {
  useCart, useAddToCart, useUpdateCartItem, useRemoveCartItem,
  useApplyPromo, useRemovePromo,
  cartKeys,
} from './hooks/useCart';

// ── Orders ───────────────────────────────────────────────────────────────────
export {
  useOrders, useOrder, useCreateOrder, useCancelOrder, useRefundOrder,
  orderKeys,
} from './hooks/useOrders';

// ── Analytics ────────────────────────────────────────────────────────────────
export {
  useDashboardAnalytics, useAnalyticsProducts, useAnalyticsCustomers, useExportAnalytics,
  analyticsKeys,
} from './hooks/useAnalytics';

// ── Users + Staff ────────────────────────────────────────────────────────────
export {
  useUsers, useStaffUsers, useUser, useInviteUser,
  useUpdateUser, useUpdateUserRole, useToggleUserActive, useDeactivateUser,
  userKeys,
} from './hooks/useUsers';

// ── Compliance ───────────────────────────────────────────────────────────────
export {
  useComplianceLogs, useCustomerPurchaseLimit, useGenerateDailyReport,
  useComplianceSalesAnalytics, useComplianceTopProducts, useComplianceRevenue,
  complianceKeys,
} from './hooks/useCompliance';

// ── Dispensaries ─────────────────────────────────────────────────────────────
export {
  useDispensaries, useDispensary, useNearbyDispensaries,
  useCreateDispensary, useUpdateDispensary, useDeleteDispensary, useUpdateBranding,
  dispensaryKeys,
} from './hooks/useDispensaries';

// ── Delivery ─────────────────────────────────────────────────────────────────
export {
  useDeliveryZones, useCreateDeliveryZone, useDeleteDeliveryZone,
  useDeliveryOrders, useAvailableDrivers, useAssignDriver,
  useCheckDeliveryAddress, useUpdateOrderStatus,
  deliveryKeys,
} from './hooks/useDelivery';

// ── Customers ────────────────────────────────────────────────────────────────
export {
  useCustomerSearch, useCustomer, useCustomerOrders,
  useVerifyCustomer, useCustomerList,
  customerKeys,
} from './hooks/useCustomers';

// ── Search ───────────────────────────────────────────────────────────────────
export {
  useProductSearch, useSearchSuggestions,
  searchKeys,
} from './hooks/useSearch';

// ── Recommendations + Reviews ────────────────────────────────────────────────
export {
  useProductReviews, useCreateReview, useRecommendations, useSimilarProducts,
  reviewKeys, recKeys,
} from './hooks/useRecommendations';

// ── AI Services ──────────────────────────────────────────────────────────────
export {
  useGenerateProductDescription, useDispensaryChatbot,
} from './hooks/useAI';
