/**
 * @file useRecommendations.ts
 * @package @cannasaas/api-client
 *
 * TanStack Query hooks for product reviews and AI-powered recommendations.
 *
 * Hooks:
 *   useProductReviews(productId, filters) — GET /reviews/:productId
 *   useCreateReview()                     — POST /reviews (authenticated)
 *   useRecommendations(context)           — POST /ai/recommendations
 *   useSimilarProducts(productId)         — GET /products?similar=:id (Sprint 9)
 *
 * Query Keys (table from Phase F spec):
 *   ['reviews', productId]   — per-product review list
 *
 * ── Recommendations staleTime ────────────────────────────────────────────────
 *
 * AI recommendations are computed server-side based on purchase history,
 * browsing behaviour, and the current dispensary inventory. They are given a
 * 10-minute staleTime — fresh enough to reflect recent purchases without
 * triggering a model inference call on every page load.
 *
 * ── Reviews staleTime ────────────────────────────────────────────────────────
 *
 * Product reviews are given a 5-minute staleTime. Reviews change slowly
 * (customers don't leave reviews by the second) and the review list is a
 * secondary concern compared to inventory accuracy.
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '../client';
import { ENDPOINTS }  from '../endpoints';
import type { ApiListResponse, ApiError } from '@cannasaas/types';

// ── Types ────────────────────────────────────────────────────────────────────

export interface ProductReview {
  id:         string;
  productId:  string;
  userId:     string;
  rating:     1 | 2 | 3 | 4 | 5;
  title?:     string;
  body?:      string;
  verified:   boolean;  // Verified purchase
  createdAt:  string;
  user: { firstName: string; avatarUrl?: string };
}

export interface ReviewFilters {
  rating?:    number;
  verified?:  boolean;
  sort?:      'newest' | 'helpful' | 'rating_asc' | 'rating_desc';
  page?:      number;
  limit?:     number;
}

export interface RecommendationContext {
  /** Current product being viewed (for "similar products") */
  currentProductId?: string;
  /** Reason for recommendations — drives the model prompt */
  reason?: 'similar' | 'trending' | 'personalised' | 'mood';
  /** Mood/effect tags (e.g. 'relaxing', 'energising', 'pain relief') */
  mood?: string;
  /** Max number of recommendations to return */
  limit?: number;
}

// ── Query Key Factory ─────────────────────────────────────────────────────────

export const reviewKeys = {
  all:    ['reviews']                                                         as const,
  list:   (productId: string, f?: object) => ['reviews', productId, f]       as const,
};

export const recKeys = {
  all:      ['recommendations']                                               as const,
  forCtx:   (ctx: object)       => [...recKeys.all, ctx]                     as const,
};

// ── Hooks ─────────────────────────────────────────────────────────────────────

/**
 * GET /reviews/:productId — paginated review list for a product.
 *
 * Returns reviews with star rating, text body, and a "verified purchase" badge.
 *
 * @example
 *   const { data: reviews } = useProductReviews('uuid', { sort: 'newest', limit: 10 });
 */
export function useProductReviews(productId: string, filters?: ReviewFilters) {
  return useQuery<ApiListResponse<ProductReview>, ApiError>({
    queryKey: reviewKeys.list(productId, filters),
    queryFn:  async () => {
      const p = new URLSearchParams();
      if (filters?.rating)   p.set('rating',   String(filters.rating));
      if (filters?.verified) p.set('verified', 'true');
      if (filters?.sort)     p.set('sort',     filters.sort);
      if (filters?.page)     p.set('page',     String(filters.page));
      if (filters?.limit)    p.set('limit',    String(filters.limit ?? 10));
      const { data } = await apiClient.get(
        `${ENDPOINTS.reviews.list(productId)}?${p}`,
      );
      return data;
    },
    enabled:   !!productId,
    staleTime: 5 * 60_000,
  });
}

/**
 * POST /reviews — submit a product review (authenticated customers only).
 *
 * On success: invalidates the product's review list and updates the product
 * detail cache's reviewSummary if present.
 */
export function useCreateReview() {
  const queryClient = useQueryClient();
  return useMutation<ProductReview, ApiError, {
    productId: string; rating: 1|2|3|4|5; title?: string; body?: string;
  }>({
    mutationFn: async (body) => {
      const { data } = await apiClient.post(ENDPOINTS.reviews.create, body);
      return data.data;
    },
    onSuccess: (_v, vars) => {
      queryClient.invalidateQueries({ queryKey: reviewKeys.list(vars.productId) });
    },
  });
}

/**
 * POST /ai/recommendations — AI-powered personalised product recommendations.
 *
 * The backend calls the recommendations module which combines:
 *   - Customer purchase history (if authenticated)
 *   - Current inventory availability
 *   - Trending products for the dispensary
 *   - Mood/effect tags if provided
 *
 * Uses `useMutation` (not useQuery) because recommendations depend on request
 * context that changes per call. Call `.mutate(context)` when the user lands
 * on the recommendations section or changes their mood filter.
 *
 * @example
 *   const { mutate: getRecommendations, data } = useRecommendations();
 *   getRecommendations({ reason: 'mood', mood: 'relaxing', limit: 6 });
 */
export function useRecommendations() {
  return useMutation({
    mutationFn: async (context: RecommendationContext) => {
      const { data } = await apiClient.post(ENDPOINTS.ai.recommendations, context);
      return data;
    },
  });
}

/**
 * GET /products?similar=:productId — products similar to the current one (Sprint 9).
 *
 * Returns up to 6 products in the same category with similar effects and
 * price range. Powered by the recommendations module's content-based filter.
 */
export function useSimilarProducts(productId: string) {
  return useQuery({
    queryKey: recKeys.forCtx({ type: 'similar', productId }),
    queryFn:  async () => {
      const { data } = await apiClient.get(`${ENDPOINTS.products.list}?similar=${productId}&limit=6`);
      return data.data ?? [];
    },
    enabled:   !!productId,
    staleTime: 10 * 60_000,
  });
}
