/**
 * @file useDelivery.ts
 * @package @cannasaas/api-client
 *
 * TanStack Query hooks for the Delivery API.
 *
 * Hooks:
 *   useDeliveryZones()          — GET  /delivery/zones
 *   useCreateDeliveryZone()     — POST /delivery/zones
 *   useDeleteDeliveryZone()     — DELETE /delivery/zones/:id
 *   useDeliveryOrders(status)   — GET  /orders?fulfillmentType=delivery&status=...
 *   useAvailableDrivers()       — GET  /delivery/drivers
 *   useAssignDriver()           — POST /delivery/assign
 *   useCheckDeliveryAddress()   — POST /delivery/check-address
 *   useUpdateOrderStatus()      — PUT  /orders/:id/status  (with optimistic update)
 *
 * ── Optimistic Order Status Update ──────────────────────────────────────────
 *
 * `useUpdateOrderStatus` implements the full four-step TanStack Query optimistic
 * pattern (from Phase F specification):
 *
 *   onMutate  → cancel queries, snapshot old data, apply optimistic state
 *   onError   → roll back to snapshot
 *   onSettled → always refetch to ensure server-state accuracy
 *
 * This makes the Delivery Dispatch "Mark Delivered" button respond instantly
 * while the PUT request is in flight, without a visible loading spinner.
 *
 * ── Delivery Zone staleTime ──────────────────────────────────────────────────
 *
 * Delivery zones change very rarely (typically only when an admin manually
 * adds or removes one). 15-minute staleTime is appropriate, matching
 * dispensary detail staleTime.
 *
 * ── Driver List staleTime ────────────────────────────────────────────────────
 *
 * Active driver list can change as drivers clock in/out. 2-minute staleTime
 * gives dispatch a reasonably fresh list without hammering the API. The
 * WebSocket hook (useDeliveryTracking) provides real-time position updates
 * independently of this REST hook.
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '../client';
import { ENDPOINTS }  from '../endpoints';
import type {
  DeliveryZone, Order, Driver,
  ApiResponse, ApiListResponse, ApiError,
} from '@cannasaas/types';

// ── Query Key Factory ─────────────────────────────────────────────────────────

export const deliveryKeys = {
  all:     ['delivery']                               as const,
  zones:   () => [...deliveryKeys.all, 'zones']       as const,
  drivers: () => [...deliveryKeys.all, 'drivers']     as const,
  orders:  (status?: string | string[]) => [...deliveryKeys.all, 'orders', status] as const,
};

// ── Hooks ─────────────────────────────────────────────────────────────────────

/**
 * GET /delivery/zones — list all delivery zones for the current dispensary.
 *
 * Each zone includes the GeoJSON polygon, min order value, delivery fee,
 * and estimated delivery time.
 */
export function useDeliveryZones() {
  return useQuery<DeliveryZone[], ApiError>({
    queryKey: deliveryKeys.zones(),
    queryFn:  async () => {
      const { data } = await apiClient.get<ApiListResponse<DeliveryZone>>(ENDPOINTS.delivery.zones);
      return data.data ?? data;
    },
    staleTime: 15 * 60_000,
  });
}

/**
 * POST /delivery/zones — create a new delivery zone with a GeoJSON polygon.
 *
 * The polygon is typically drawn in the Leaflet map editor in SettingsDeliveryZones.
 * For zones added via the form (without the map), an empty polygon is sent and
 * the backend will require the admin to draw the polygon before the zone goes live.
 *
 * @example
 *   const { mutate: createZone } = useCreateDeliveryZone();
 *   createZone({ name: 'Brooklyn North', deliveryFee: 5, minOrderValue: 30, estimatedMinutes: 45 });
 */
export function useCreateDeliveryZone() {
  const queryClient = useQueryClient();
  return useMutation<DeliveryZone, ApiError, Partial<DeliveryZone> & { name: string }>({
    mutationFn: async (body) => {
      const { data } = await apiClient.post<ApiResponse<DeliveryZone>>(
        ENDPOINTS.delivery.createZone,
        body,
      );
      return data.data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: deliveryKeys.zones() }),
  });
}

/**
 * DELETE /delivery/zones/:id — remove a delivery zone.
 *
 * Existing orders in the zone are not affected — this only prevents new
 * orders from being placed to that zone.
 */
export function useDeleteDeliveryZone() {
  const queryClient = useQueryClient();
  return useMutation<void, ApiError, string>({
    mutationFn: async (zoneId) => {
      await apiClient.delete(`${ENDPOINTS.delivery.zones}/${zoneId}`);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: deliveryKeys.zones() }),
  });
}

/**
 * GET /orders?fulfillmentType=delivery&status=... — delivery orders filtered by status.
 *
 * Used in DeliveryDispatch.tsx to display unassigned and active delivery orders.
 *
 * @example
 *   const { data } = useDeliveryOrders({ status: ['pending', 'confirmed', 'preparing'] });
 */
export function useDeliveryOrders(opts: { status: string | string[] }) {
  const statuses = Array.isArray(opts.status) ? opts.status : [opts.status];
  return useQuery<Order[], ApiError>({
    queryKey: deliveryKeys.orders(statuses),
    queryFn:  async () => {
      const params = new URLSearchParams({ fulfillmentType: 'delivery' });
      statuses.forEach((s) => params.append('status', s));
      const { data } = await apiClient.get<ApiListResponse<Order>>(
        `${ENDPOINTS.orders.list}?${params}`,
      );
      return data.data ?? [];
    },
    staleTime: 30_000,          // 30s — delivery dispatch needs reasonably fresh data
    refetchInterval: 60_000,    // Poll every 60s as fallback when WebSocket is unavailable
  });
}

/**
 * GET /delivery/drivers — list available drivers for the current dispensary.
 *
 * Returns drivers with their current active delivery count so dispatch staff
 * can see who has capacity.
 */
export function useAvailableDrivers() {
  return useQuery<Driver[], ApiError>({
    queryKey: deliveryKeys.drivers(),
    queryFn:  async () => {
      const { data } = await apiClient.get<ApiListResponse<Driver>>(ENDPOINTS.delivery.drivers);
      return data.data ?? data;
    },
    staleTime: 2 * 60_000,
  });
}

/**
 * POST /delivery/assign — assign a driver to a delivery order.
 *
 * Invalidates both the delivery orders cache and the drivers cache so that
 * the dispatch UI reflects the assignment immediately after refresh.
 *
 * @example
 *   const { mutate: assignDriver } = useAssignDriver();
 *   assignDriver({ orderId: 'abc', driverId: 'def' });
 */
export function useAssignDriver() {
  const queryClient = useQueryClient();
  return useMutation<Order, ApiError, { orderId: string; driverId: string }>({
    mutationFn: async (body) => {
      const { data } = await apiClient.post<ApiResponse<Order>>(ENDPOINTS.delivery.assign, body);
      return data.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: deliveryKeys.orders() });
      queryClient.invalidateQueries({ queryKey: deliveryKeys.drivers() });
    },
  });
}

/**
 * POST /delivery/check-address — verify whether an address falls within a delivery zone.
 *
 * Used in the storefront checkout flow before the customer commits to delivery.
 */
export function useCheckDeliveryAddress() {
  return useMutation<{ deliverable: boolean; zone?: DeliveryZone; fee?: number }, ApiError, { address: string; city: string; zip: string }>({
    mutationFn: async (body) => {
      const { data } = await apiClient.post(ENDPOINTS.delivery.checkAddress, body);
      return data;
    },
  });
}

/**
 * PUT /orders/:id/status — update order status with FULL optimistic update pattern.
 *
 * This hook demonstrates the complete Phase F optimistic update specification:
 *
 *   Step 1 — onMutate: Cancel in-flight queries for the orders cache to prevent
 *             stale server data from overwriting our optimistic state during the
 *             mutation window.
 *
 *   Step 2 — onMutate: Snapshot the current cache value so we have something
 *             to roll back to if the mutation fails.
 *
 *   Step 3 — onMutate: Apply the optimistic state immediately. The UI reflects
 *             the new status without waiting for the server response.
 *
 *   Step 4 — onError: Roll back to the snapshot. The "Mark Delivered" button
 *             should un-advance if the PUT returns an error.
 *
 *   Step 5 — onSettled: Always invalidate regardless of success or error.
 *             This ensures the cache reflects true server state after the
 *             optimistic window closes.
 *
 * @example
 *   const { mutate: updateStatus } = useUpdateOrderStatus('out_for_delivery');
 *   updateStatus({ id: order.id, status: 'delivered' });
 */
export function useUpdateOrderStatus(currentStatus: string) {
  const queryClient = useQueryClient();
  // Target both the flat orders list and the delivery-specific cache
  const targetKey = deliveryKeys.orders(currentStatus);

  return useMutation<
    Order,
    ApiError,
    { id: string; status: string },
    { snapshot: Order[] | undefined }
  >({
    mutationFn: async ({ id, status }) => {
      const { data } = await apiClient.put<ApiResponse<Order>>(
        ENDPOINTS.orders.updateStatus(id),
        { status },
      );
      return data.data;
    },

    // ── Step 1 + 2 + 3: Cancel, snapshot, apply optimistic ──────────────────
    onMutate: async ({ id, status }) => {
      // Step 1 — cancel in-flight fetches for this cache key
      await queryClient.cancelQueries({ queryKey: targetKey });

      // Step 2 — capture snapshot for potential rollback
      const snapshot = queryClient.getQueryData<Order[]>(targetKey);

      // Step 3 — immediately apply the optimistic state
      queryClient.setQueryData<Order[]>(targetKey, (prev) =>
        (prev ?? []).map((order) =>
          order.id === id ? { ...order, status } : order,
        ),
      );

      return { snapshot };
    },

    // ── Step 4: Roll back on error ───────────────────────────────────────────
    onError: (_err, _vars, context) => {
      // Restore the snapshotted state so the UI reverts
      queryClient.setQueryData(targetKey, context?.snapshot);
    },

    // ── Step 5: Always refetch on settle ────────────────────────────────────
    onSettled: () => {
      // Invalidate to ensure the cache is eventually consistent with the server
      queryClient.invalidateQueries({ queryKey: deliveryKeys.orders() });
    },
  });
}
