/**
 * @file useAI.ts
 * @package @cannasaas/api-client
 *
 * TanStack Query hooks for the AI Services API endpoints.
 *
 * Hooks:
 *   useGenerateProductDescription()  — POST /ai/product-description (Admin, Manager+)
 *   useDispensaryChatbot()           — POST /ai/chatbot  (Public — storefront)
 *
 * Both hooks use `useMutation` because AI responses are non-deterministic —
 * caching them would result in the same generated copy being served repeatedly.
 *
 * ── Product Description Generation ──────────────────────────────────────────
 *
 * Used in the Admin Product form when a manager wants AI-assisted copy.
 * Sends the product name, category, strain type, THC %, effects, and flavors
 * as context. The AI returns a 2-3 sentence marketing description.
 *
 * The result is never auto-populated into the form — the manager sees a
 * modal with the generated copy and can "Use this description" or dismiss.
 * This keeps humans in the loop for all published content.
 *
 * ── Dispensary Chatbot ────────────────────────────────────────────────────────
 *
 * The chatbot is a public endpoint that powers the storefront help widget.
 * It has knowledge of the dispensary's current inventory, operating hours,
 * and frequently asked questions. It does NOT have access to individual
 * customer order history or personal data.
 */

import { useMutation } from '@tanstack/react-query';
import { apiClient } from '../client';
import { ENDPOINTS }  from '../endpoints';

// ── Types ─────────────────────────────────────────────────────────────────────

export interface ProductDescriptionContext {
  name:        string;
  category:    string;
  strainType?: string;
  thcContent?: number;
  cbdContent?: number;
  effects?:    string[];
  flavors?:    string[];
  brand?:      string;
  tone?:       'clinical' | 'friendly' | 'premium'; // Desired copy tone
}

export interface ChatMessage {
  role:    'user' | 'assistant';
  content: string;
}

export interface ChatbotRequest {
  messages:    ChatMessage[];  // Full conversation history for context
  dispensaryId?: string;       // Allows server to inject dispensary-specific context
}

// ── Hooks ─────────────────────────────────────────────────────────────────────

/**
 * POST /ai/product-description — generate marketing copy for a product.
 *
 * @example
 *   const { mutate: generate, data, isPending } = useGenerateProductDescription();
 *
 *   generate({
 *     name: 'Blue Dream',
 *     category: 'flower',
 *     thcContent: 24,
 *     effects: ['uplifting', 'creative'],
 *     tone: 'friendly',
 *   });
 *
 *   // Then show data.description in a modal for review
 */
export function useGenerateProductDescription() {
  return useMutation<{ description: string }, Error, ProductDescriptionContext>({
    mutationFn: async (context) => {
      const { data } = await apiClient.post(ENDPOINTS.ai.productDescription, context);
      return data;
    },
  });
}

/**
 * POST /ai/chatbot — multi-turn dispensary chatbot.
 *
 * The caller maintains the conversation history in component state and passes
 * the full `messages` array with each call so the model has context.
 *
 * @example
 *   const { mutate: sendMessage, isPending } = useDispensaryChatbot();
 *
 *   const [messages, setMessages] = useState<ChatMessage[]>([]);
 *
 *   const send = (userText: string) => {
 *     const updated = [...messages, { role: 'user', content: userText }];
 *     setMessages(updated);
 *     sendMessage(
 *       { messages: updated },
 *       {
 *         onSuccess: (res) => setMessages([...updated, { role: 'assistant', content: res.reply }]),
 *       }
 *     );
 *   };
 */
export function useDispensaryChatbot() {
  return useMutation<{ reply: string }, Error, ChatbotRequest>({
    mutationFn: async (body) => {
      const { data } = await apiClient.post(ENDPOINTS.ai.chatbot, body);
      return data;
    },
  });
}
