/**
 * @file useUsers.ts
 * @package @cannasaas/api-client
 *
 * TanStack Query hooks for user and staff management (Admin API).
 *
 * All hooks require Admin+ or Manager+ authorization.
 *
 * Hooks:
 *   useUsers(filters)       — GET /users?role=...&isActive=...
 *   useStaffUsers()         — GET /users?role[]=admin,manager,budtender,driver
 *   useUser(id)             — GET /users/:id
 *   useInviteUser()         — POST /users  { email, roles }
 *   useUpdateUser()         — PUT  ive /users/:id  (general update)
 *   useUpdateUserRole()     — PUT  /users/:id/roles  { role }
 *   useToggleUserActive()   — PUT  /users/:id  { isActive }
 *   useDeactivateUser()     — DELETE /users/:id  (soft delete / deactivate)
 *
 * Query Keys (stable factory pattern):
 *   userKeys.all                 → ['users']
 *   userKeys.lists()             → ['users', 'list']
 *   userKeys.list(filters)       → ['users', 'list', { ...filters }]
 *   userKeys.detail(id)          → ['users', 'detail', id]
 *
 * Invalidation strategy:
 *   Mutations that change user state (invite, role change, toggle active)
 *   invalidate `userKeys.lists()` so the staff table re-fetches.
 *   They do NOT invalidate detail queries to avoid unnecessary re-fetches on
 *   list views where detail panels are not open.
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '../client';
import { ENDPOINTS }  from '../endpoints';
import type { User, ApiResponse, ApiListResponse, ApiError } from '@cannasaas/types';

// ── Query Key Factory ─────────────────────────────────────────────────────────

export const userKeys = {
  all:          ['users']                        as const,
  lists:        () => [...userKeys.all, 'list']  as const,
  list:  (f: object) => [...userKeys.lists(), f] as const,
  detail: (id: string) => [...userKeys.all, 'detail', id] as const,
};

// ── Filter type for user list queries ────────────────────────────────────────

export interface UserListFilters {
  /** Filter by one or more role names */
  role?:     string | string[];
  /** Filter by active/inactive status */
  isActive?: boolean;
  /** Cursor-based pagination */
  page?:     number;
  limit?:    number;
  /** Free-text search (name or email) */
  search?:   string;
}

// ── Hooks ─────────────────────────────────────────────────────────────────────

/**
 * GET /users — paginated user list with optional role + active filters.
 *
 * @example
 *   const { data } = useUsers({ role: 'customer', isActive: true, limit: 20 });
 */
export function useUsers(filters: UserListFilters = {}) {
  return useQuery<ApiListResponse<User>, ApiError>({
    queryKey: userKeys.list(filters),
    queryFn:  async () => {
      const params = new URLSearchParams();
      if (filters.search)   params.set('search',   filters.search);
      if (filters.isActive != null) params.set('isActive', String(filters.isActive));
      if (filters.page)     params.set('page',   String(filters.page));
      if (filters.limit)    params.set('limit',  String(filters.limit));
      // role may be a single string or array
      if (filters.role) {
        const roles = Array.isArray(filters.role) ? filters.role : [filters.role];
        roles.forEach((r) => params.append('role', r));
      }
      const { data } = await apiClient.get<ApiListResponse<User>>(`${ENDPOINTS.users.list}?${params}`);
      return data;
    },
    staleTime: 60_000, // 1 minute — staff list changes infrequently
  });
}

/**
 * GET /users — filtered to staff roles only (admin, manager, budtender, driver).
 *
 * Convenience wrapper used by SettingsStaff.tsx to avoid passing roles every time.
 */
export function useStaffUsers() {
  return useUsers({ role: ['admin', 'manager', 'budtender', 'driver'] });
}

/**
 * GET /users/:id — single user detail.
 *
 * Enabled only when `id` is a non-empty string. Caller can pass '' and the
 * query stays disabled until an id is selected.
 */
export function useUser(id: string) {
  return useQuery<User, ApiError>({
    queryKey: userKeys.detail(id),
    queryFn:  async () => {
      const { data } = await apiClient.get<ApiResponse<User>>(ENDPOINTS.users.detail(id));
      return data.data;
    },
    enabled: !!id,
  });
}

/**
 * POST /users — invite a new staff member.
 *
 * The API sends an invitation email to the provided address.
 * On success, the user is created in the database with a pending status.
 *
 * @example
 *   const { mutate: inviteUser } = useInviteUser();
 *   inviteUser({ email: 'budtender@example.com', roles: ['budtender'] });
 */
export function useInviteUser() {
  const queryClient = useQueryClient();
  return useMutation<User, ApiError, { email: string; roles: string[]; firstName?: string; lastName?: string }>({
    mutationFn: async (body) => {
      const { data } = await apiClient.post<ApiResponse<User>>(ENDPOINTS.users.create, body);
      return data.data;
    },
    onSuccess: () => {
      // Invalidate the staff list so the new invitation appears
      queryClient.invalidateQueries({ queryKey: userKeys.lists() });
    },
  });
}

/**
 * PUT /users/:id — general user profile update.
 */
export function useUpdateUser() {
  const queryClient = useQueryClient();
  return useMutation<User, ApiError, { userId: string } & Partial<User>>({
    mutationFn: async ({ userId, ...body }) => {
      const { data } = await apiClient.put<ApiResponse<User>>(ENDPOINTS.users.update(userId), body);
      return data.data;
    },
    onSuccess: (updated) => {
      queryClient.setQueryData(userKeys.detail(updated.id), updated);
      queryClient.invalidateQueries({ queryKey: userKeys.lists() });
    },
  });
}

/**
 * PUT /users/:id/roles — change a staff member's role.
 *
 * Roles are sent as an array because a user can theoretically hold multiple.
 * For the staff settings UI, role changes replace the existing roles entirely.
 *
 * @example
 *   const { mutate: updateRole } = useUpdateUserRole();
 *   updateRole({ userId: 'abc', role: 'manager' });
 */
export function useUpdateUserRole() {
  const queryClient = useQueryClient();
  return useMutation<User, ApiError, { userId: string; role: string }>({
    mutationFn: async ({ userId, role }) => {
      const { data } = await apiClient.post<ApiResponse<User>>(
        ENDPOINTS.users.assignRoles(userId),
        { roles: [role] },
      );
      return data.data;
    },
    onSuccess: (updated) => {
      queryClient.setQueryData(userKeys.detail(updated.id), updated);
      queryClient.invalidateQueries({ queryKey: userKeys.lists() });
    },
  });
}

/**
 * PUT /users/:id { isActive } — activate or deactivate a staff account.
 *
 * Deactivated accounts cannot log in but their history is preserved.
 *
 * @example
 *   const { mutate: toggleActive } = useToggleUserActive();
 *   toggleActive({ userId: 'abc', isActive: false });
 */
export function useToggleUserActive() {
  const queryClient = useQueryClient();
  return useMutation<User, ApiError, { userId: string; isActive: boolean }>({
    mutationFn: async ({ userId, isActive }) => {
      const { data } = await apiClient.put<ApiResponse<User>>(
        ENDPOINTS.users.update(userId),
        { isActive },
      );
      return data.data;
    },
    onSuccess: (updated) => {
      queryClient.setQueryData(userKeys.detail(updated.id), updated);
      queryClient.invalidateQueries({ queryKey: userKeys.lists() });
    },
  });
}

/**
 * DELETE /users/:id — soft-delete (deactivate) a user account.
 *
 * This is a hard deactivation; data is retained for compliance.
 */
export function useDeactivateUser() {
  const queryClient = useQueryClient();
  return useMutation<void, ApiError, string>({
    mutationFn: async (userId) => {
      await apiClient.delete(ENDPOINTS.users.delete(userId));
    },
    onSuccess: (_v, userId) => {
      queryClient.removeQueries({ queryKey: userKeys.detail(userId) });
      queryClient.invalidateQueries({ queryKey: userKeys.lists() });
    },
  });
}
