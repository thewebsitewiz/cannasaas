/**
 * @file useDispensaries.ts
 * @package @cannasaas/api-client
 *
 * TanStack Query hooks for the Dispensaries API.
 *
 * Hooks:
 *   useDispensaries(filters)   — GET /dispensaries  (list, filtered by org)
 *   useDispensary(id)          — GET /dispensaries/:id
 *   useNearbyDispensaries(geo) — GET /dispensaries/nearby?lat=...&lng=...&radius=
 *   useCreateDispensary()      — POST /dispensaries
 *   useUpdateDispensary(id)    — PUT  /dispensaries/:id
 *   useDeleteDispensary()      — DELETE /dispensaries/:id
 *
 * Branding:
 *   useUpdateBranding(id)      — PUT  /dispensaries/:id/branding
 *   (logo upload is handled separately via a direct POST with FormData
 *    because TanStack Query mutation is not optimal for multipart uploads —
 *    see SettingsBranding.tsx which calls the API directly)
 *
 * Query Keys:
 *   dispensaryKeys.all                  → ['dispensaries']
 *   dispensaryKeys.lists()              → ['dispensaries', 'list']
 *   dispensaryKeys.list(filters)        → ['dispensaries', 'list', { ...filters }]
 *   dispensaryKeys.detail(id)           → ['dispensaries', 'detail', id]
 *   dispensaryKeys.nearby(lat, lng, r)  → ['dispensaries', 'nearby', lat, lng, r]
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '../client';
import { ENDPOINTS }  from '../endpoints';
import type { Dispensary, ApiResponse, ApiListResponse, ApiError } from '@cannasaas/types';

// ── Query Key Factory ─────────────────────────────────────────────────────────

export const dispensaryKeys = {
  all:    ['dispensaries'] as const,
  lists:  () => [...dispensaryKeys.all, 'list'] as const,
  list:   (f?: object) => [...dispensaryKeys.lists(), f] as const,
  detail: (id: string)  => [...dispensaryKeys.all, 'detail', id] as const,
  nearby: (lat: number, lng: number, r: number) => [...dispensaryKeys.all, 'nearby', lat, lng, r] as const,
};

// ── Hooks ─────────────────────────────────────────────────────────────────────

/**
 * GET /dispensaries — list dispensaries filtered by the current organisation context.
 * The tenant context headers (X-Organization-Id) handle filtering on the server.
 */
export function useDispensaries(filters?: { companyId?: string; isActive?: boolean }) {
  return useQuery<ApiListResponse<Dispensary>, ApiError>({
    queryKey: dispensaryKeys.list(filters),
    queryFn:  async () => {
      const params = new URLSearchParams();
      if (filters?.companyId) params.set('companyId', filters.companyId);
      if (filters?.isActive != null) params.set('isActive', String(filters.isActive));
      const { data } = await apiClient.get<ApiListResponse<Dispensary>>(
        `${ENDPOINTS.dispensaries.list}?${params}`,
      );
      return data;
    },
    staleTime: 15 * 60_000, // Dispensary details change rarely — 15 min
  });
}

/**
 * GET /dispensaries/:id — single dispensary with all configuration.
 *
 * Used in the Settings page to load branding, hours, and license info.
 * Enabled only when `id` is non-empty.
 */
export function useDispensary(id: string) {
  return useQuery<Dispensary, ApiError>({
    queryKey: dispensaryKeys.detail(id),
    queryFn:  async () => {
      const { data } = await apiClient.get<ApiResponse<Dispensary>>(
        ENDPOINTS.dispensaries.detail(id),
      );
      return data.data;
    },
    enabled:   !!id,
    staleTime: 15 * 60_000,
  });
}

/**
 * GET /dispensaries/nearby — PostGIS-powered nearby dispensary search.
 *
 * Used in the public-facing storefront to show dispensaries within radius km.
 * Enabled only when valid coordinates are provided.
 *
 * @example
 *   const { data } = useNearbyDispensaries({ lat: 40.68, lng: -73.94, radius: 25 });
 */
export function useNearbyDispensaries(geo?: { lat: number; lng: number; radius: number }) {
  return useQuery({
    queryKey: geo ? dispensaryKeys.nearby(geo.lat, geo.lng, geo.radius) : ['dispensaries', 'nearby', null],
    queryFn:  async () => {
      const { data } = await apiClient.get(
        `${ENDPOINTS.dispensaries.nearby}?latitude=${geo!.lat}&longitude=${geo!.lng}&radius=${geo!.radius}`,
      );
      return data;
    },
    enabled:   !!geo,
    staleTime: 10 * 60_000,
  });
}

/**
 * POST /dispensaries — create a new dispensary under the current company.
 * Requires Company Admin role.
 */
export function useCreateDispensary() {
  const queryClient = useQueryClient();
  return useMutation<Dispensary, ApiError, Partial<Dispensary>>({
    mutationFn: async (body) => {
      const { data } = await apiClient.post<ApiResponse<Dispensary>>(
        ENDPOINTS.dispensaries.create,
        body,
      );
      return data.data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: dispensaryKeys.lists() }),
  });
}

/**
 * PUT /dispensaries/:id — update dispensary profile, hours, settings.
 *
 * The Settings page form uses this. It receives the full dispensary object
 * including branding colours, font, and operating hours.
 *
 * On success: the detail cache is updated immediately with the returned value,
 * and the list query is invalidated to keep the sidebar/nav in sync.
 *
 * @example
 *   const { mutate: update } = useUpdateDispensary(dispensary.id);
 *   update({ name: 'Green Leaf Brooklyn Updated', primaryColor: '#2d7a4f' });
 */
export function useUpdateDispensary(id: string) {
  const queryClient = useQueryClient();
  return useMutation<Dispensary, ApiError, Partial<Dispensary>>({
    mutationFn: async (body) => {
      const { data } = await apiClient.put<ApiResponse<Dispensary>>(
        ENDPOINTS.dispensaries.update(id),
        body,
      );
      return data.data;
    },
    onSuccess: (updated) => {
      queryClient.setQueryData(dispensaryKeys.detail(id), updated);
      queryClient.invalidateQueries({ queryKey: dispensaryKeys.lists() });
    },
  });
}

/**
 * PUT /dispensaries/:id/branding — update branding config (colours, font, etc).
 *
 * Separate from the full dispensary update so that branding changes can be
 * previewed and saved independently without touching hours or license fields.
 */
export function useUpdateBranding(dispensaryId: string) {
  const queryClient = useQueryClient();
  return useMutation<
    Dispensary,
    ApiError,
    { primaryColor?: string; secondaryColor?: string; accentColor?: string; fontFamily?: string; logoUrl?: string }
  >({
    mutationFn: async (body) => {
      const { data } = await apiClient.put<ApiResponse<Dispensary>>(
        ENDPOINTS.dispensaries.updateBranding(dispensaryId),
        body,
      );
      return data.data;
    },
    onSuccess: (updated) => {
      queryClient.setQueryData(dispensaryKeys.detail(dispensaryId), updated);
    },
  });
}

/**
 * DELETE /dispensaries/:id — soft-delete a dispensary.
 * Requires Company Admin role.
 */
export function useDeleteDispensary() {
  const queryClient = useQueryClient();
  return useMutation<void, ApiError, string>({
    mutationFn: async (id) => {
      await apiClient.delete(ENDPOINTS.dispensaries.delete(id));
    },
    onSuccess: (_v, id) => {
      queryClient.removeQueries({ queryKey: dispensaryKeys.detail(id) });
      queryClient.invalidateQueries({ queryKey: dispensaryKeys.lists() });
    },
  });
}
