/**
 * @file useSearch.ts
 * @package @cannasaas/api-client
 *
 * TanStack Query hooks for the Elasticsearch-backed product search API.
 *
 * Hooks:
 *   useProductSearch(query, filters)  — GET /search?q=...  (full-text with relevance scoring)
 *   useSearchSuggestions(query)       — GET /search/suggest?q=...  (autocomplete)
 *
 * ── Search vs. Product Listing ────────────────────────────────────────────────
 *
 * `useProductSearch` is distinct from `useProducts` (which calls GET /products):
 *   - /products uses SQL filtering — good for category browsing with exact filters
 *   - /search uses Elasticsearch — good for free-text input with typo tolerance,
 *     cannabis synonym expansion (weed→flower, cart→vape cartridge), and relevance
 *     ranking by THC %, reviews, and sales velocity
 *
 * Use `useProductSearch` for the storefront search bar.
 * Use `useProducts` for category pages, admin product management, and inventory.
 *
 * ── Suggestion staleTime ────────────────────────────────────────────────────
 *
 * Autocomplete suggestions are given a 2-minute staleTime. They're typed
 * in rapid succession — caching the last few queries avoids redundant
 * Elasticsearch requests when a user backspaces and re-types.
 *
 * ── Enabled condition ────────────────────────────────────────────────────────
 *
 * Both hooks are disabled when the query string is empty or < 2 characters,
 * since a 1-character query is unlikely to be intentional and would spam the
 * Elasticsearch cluster.
 */

import { useQuery } from '@tanstack/react-query';
import { apiClient } from '../client';
import { ENDPOINTS }  from '../endpoints';
import type { Product, ApiError } from '@cannasaas/types';

// ── Query Key Factory ─────────────────────────────────────────────────────────

export const searchKeys = {
  all:         ['search']                                          as const,
  results:     (q: string, f?: object) => [...searchKeys.all, 'results', q, f] as const,
  suggestions: (q: string) => [...searchKeys.all, 'suggest', q]  as const,
};

// ── Filter type ───────────────────────────────────────────────────────────────

export interface SearchFilters {
  category?:    string;
  strainType?:  string;
  minThc?:      number;
  maxThc?:      number;
  minPrice?:    number;
  maxPrice?:    number;
  effects?:     string[];
  page?:        number;
  limit?:       number;
}

// ── Hooks ─────────────────────────────────────────────────────────────────────

/**
 * GET /search?q=:query — full-text product search with Elasticsearch.
 *
 * Returns products ranked by relevance, supporting:
 *   - Typo tolerance (fuzzy matching)
 *   - Cannabis synonym expansion: "weed" → flower, "cart" → vape cartridge
 *   - Multi-field boosting: name > brand > description > effects
 *   - Optional filters applied post-search
 *
 * The caller should debounce the `query` string (300ms recommended) to
 * avoid firing on every keystroke.
 *
 * @example
 *   const debouncedQ = useDebounce(searchTerm, 300);
 *   const { data } = useProductSearch(debouncedQ, { category: 'flower' });
 */
export function useProductSearch(query: string, filters?: SearchFilters) {
  return useQuery<{ data: Product[]; total: number; took: number }, ApiError>({
    queryKey: searchKeys.results(query, filters),
    queryFn:  async () => {
      const params = new URLSearchParams({ q: query });
      if (filters?.category)   params.set('category',   filters.category);
      if (filters?.strainType) params.set('strainType', filters.strainType);
      if (filters?.minThc)     params.set('minThc',     String(filters.minThc));
      if (filters?.maxThc)     params.set('maxThc',     String(filters.maxThc));
      if (filters?.minPrice)   params.set('minPrice',   String(filters.minPrice));
      if (filters?.maxPrice)   params.set('maxPrice',   String(filters.maxPrice));
      if (filters?.page)       params.set('page',       String(filters.page));
      if (filters?.limit)      params.set('limit',      String(filters.limit ?? 20));
      if (filters?.effects?.length) {
        filters.effects.forEach((e) => params.append('effects', e));
      }
      const { data } = await apiClient.get(`${ENDPOINTS.search.query}?${params}`);
      return data;
    },
    enabled:   query.length >= 2,
    staleTime: 2 * 60_000,         // 2 min — search index rarely changes mid-session
    placeholderData: (previousData) => previousData, // Keep showing previous results while fetching
  });
}

/**
 * GET /search/suggest?q=:query — typeahead autocomplete suggestions.
 *
 * Returns up to 8 product name / brand / category suggestions for displaying
 * in the storefront search dropdown before the user submits.
 *
 * Suggestions come from an Elasticsearch completion suggester and are
 * very fast (<20ms typical) so can be fetched on each debounced keystroke.
 *
 * @example
 *   const { data: suggestions } = useSearchSuggestions('blue');
 *   // ['Blue Dream', 'Blueberry Kush', 'Blue Cheese', ...]
 */
export function useSearchSuggestions(query: string) {
  return useQuery<string[], ApiError>({
    queryKey: searchKeys.suggestions(query),
    queryFn:  async () => {
      const { data } = await apiClient.get(
        `${ENDPOINTS.search.suggest}?q=${encodeURIComponent(query)}`,
      );
      return data.suggestions ?? data;
    },
    enabled:   query.length >= 2,
    staleTime: 2 * 60_000,
  });
}
