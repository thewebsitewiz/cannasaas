/**
 * @file useCustomers.ts
 * @package @cannasaas/api-client
 *
 * TanStack Query hooks for customer search and detail — primarily used in the
 * Staff Portal (CustomerLookup, QuickActions) and Admin Portal (Customers page).
 *
 * Hooks:
 *   useCustomerSearch(query)       — GET /users?search=...&role=customer
 *   useCustomer(id)                — GET /users/:id  (with customer profile data)
 *   useCustomerOrders(filters)     — GET /orders?customerId=...
 *   useVerifyCustomer(customerId)  — POST /age-verification/verify
 *   useCustomerList(filters)       — GET /users?role=customer (paginated, Admin)
 *
 * ── Search staleTime ─────────────────────────────────────────────────────────
 *
 * Customer search results (GET /users?search=...) are given a 30-second staleTime.
 * Staff lookup is a rapid workflow — searching for a customer, checking their
 * limits, then handing them their order. 30 seconds is enough to not re-fetch
 * while the staff member is looking at the result, but fresh enough that the
 * next search doesn't return cached results for a different query.
 *
 * ── Verification staleTime ────────────────────────────────────────────────────
 *
 * useCustomer() (which includes verificationStatus) uses staleTime: 0 when
 * called from a verification workflow. The Staff Portal overrides this by
 * calling queryClient.invalidateQueries(customerKeys.detail(id)) after a
 * successful POST /age-verification/verify mutation to show the updated badge.
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '../client';
import { ENDPOINTS }  from '../endpoints';
import type { User, Order, ApiResponse, ApiListResponse, ApiError } from '@cannasaas/types';

// ── Query Key Factory ─────────────────────────────────────────────────────────

export const customerKeys = {
  all:       ['customers']                                         as const,
  lists:     () => [...customerKeys.all, 'list']                   as const,
  list:      (f?: object) => [...customerKeys.lists(), f]          as const,
  search:    (q: string)  => [...customerKeys.all, 'search', q]   as const,
  detail:    (id: string) => [...customerKeys.all, 'detail', id]  as const,
  orders:    (id: string, f?: object) => [...customerKeys.all, 'orders', id, f] as const,
};

// ── Hooks ─────────────────────────────────────────────────────────────────────

/**
 * GET /users?search=:q&role=customer — debounced customer search.
 *
 * Used in the Staff Portal Customer Lookup search input. The caller (component)
 * is responsible for debouncing the query string before passing it here.
 *
 * Enabled only when `q` has 2+ characters to avoid unnecessary requests.
 *
 * @example
 *   const debouncedQ = useDebounce(searchInput, 300);
 *   const { data } = useCustomerSearch({ q: debouncedQ, limit: 10 }, { enabled: debouncedQ.length >= 2 });
 */
export function useCustomerSearch(
  params: { q: string; limit?: number },
  opts?:  { enabled?: boolean },
) {
  return useQuery<User[], ApiError>({
    queryKey: customerKeys.search(params.q),
    queryFn:  async () => {
      const p = new URLSearchParams({ search: params.q, role: 'customer' });
      if (params.limit) p.set('limit', String(params.limit));
      const { data } = await apiClient.get<ApiListResponse<User>>(`${ENDPOINTS.users.list}?${p}`);
      return data.data ?? [];
    },
    enabled:   (opts?.enabled ?? true) && params.q.length >= 2,
    staleTime: 30_000,
  });
}

/**
 * GET /users/:id — customer profile with verification status and medical card info.
 *
 * Enabled only when `id` is non-empty. When called from a verification
 * workflow, pass staleTime override of 0 via queryClient.invalidateQueries.
 */
export function useCustomer(id: string, opts?: { enabled?: boolean }) {
  return useQuery<User, ApiError>({
    queryKey: customerKeys.detail(id),
    queryFn:  async () => {
      const { data } = await apiClient.get<ApiResponse<User>>(ENDPOINTS.users.detail(id));
      return data.data;
    },
    enabled:   (opts?.enabled ?? true) && !!id,
    staleTime: 60_000, // 1 min — profile data; re-fetch after verification via invalidate
  });
}

/**
 * GET /orders?customerId=:id — customer order history.
 *
 * Used in CustomerDetail and CustomerLookup panels. The limit param lets
 * callers get just the most recent 5 orders for a quick summary, or all
 * orders for the full history view.
 *
 * @example
 *   const { data: recentOrders } = useCustomerOrders({ customerId: id, limit: 5 });
 */
export function useCustomerOrders(
  params:  { customerId: string; limit?: number; page?: number },
  opts?:   { enabled?: boolean },
) {
  const { customerId, limit = 20, page = 1 } = params;
  return useQuery<ApiListResponse<Order>, ApiError>({
    queryKey: customerKeys.orders(customerId, { limit, page }),
    queryFn:  async () => {
      const p = new URLSearchParams({
        customerId,
        limit: String(limit),
        page:  String(page),
        sort:  'createdAt_desc',
      });
      const { data } = await apiClient.get<ApiListResponse<Order>>(
        `${ENDPOINTS.orders.list}?${p}`,
      );
      return data;
    },
    enabled:   (opts?.enabled ?? true) && !!customerId,
    staleTime: 60_000,
  });
}

/**
 * POST /age-verification/verify — staff-initiated ID verification.
 *
 * Called from:
 *   - Staff Portal Quick Actions "Verify Age" tile
 *   - Staff Portal Customer Lookup "Verify ID" button
 *   - Admin Portal CustomerDetail "Initiate Verification" button
 *
 * After a successful mutation, the customer's detail cache is invalidated
 * so their verificationStatus badge updates without a manual refresh.
 *
 * Payload for manual (budtender-checks-ID) verification:
 *   { action: 'approve', customerId: '...', verificationType: 'manual' }
 *
 * Payload for rejection:
 *   { action: 'reject', reason: 'ID expired' }
 *
 * @example
 *   const { mutate: verify } = useVerifyCustomer(customer.id);
 *   verify({ action: 'approve' });
 */
export function useVerifyCustomer(customerId: string) {
  const queryClient = useQueryClient();
  return useMutation<User, ApiError, { action: 'approve' | 'reject'; reason?: string }>({
    mutationFn: async ({ action, reason }) => {
      const { data } = await apiClient.post<ApiResponse<User>>(
        ENDPOINTS.ageVerification.verify,
        { customerId, action, reason, verificationType: 'manual' },
      );
      return data.data;
    },
    onSuccess: (updated) => {
      // Update detail cache so verification badge refreshes immediately
      queryClient.setQueryData(customerKeys.detail(customerId), updated);
    },
  });
}

/**
 * GET /users?role=customer — paginated customer list for Admin portal.
 *
 * The full admin Customers page uses this with search, verification filter,
 * and active status filter.
 *
 * @example
 *   const { data } = useCustomerList({ search: 'jane', verificationStatus: 'verified', page: 1 });
 */
export function useCustomerList(filters: {
  search?:             string;
  verificationStatus?: 'unverified' | 'pending' | 'verified';
  isActive?:           boolean;
  page?:               number;
  limit?:              number;
}) {
  return useQuery<ApiListResponse<User>, ApiError>({
    queryKey: customerKeys.list(filters),
    queryFn:  async () => {
      const p = new URLSearchParams({ role: 'customer' });
      if (filters.search)             p.set('search',             filters.search);
      if (filters.verificationStatus) p.set('verificationStatus', filters.verificationStatus);
      if (filters.isActive != null)   p.set('isActive',           String(filters.isActive));
      if (filters.page)               p.set('page',               String(filters.page));
      if (filters.limit)              p.set('limit',              String(filters.limit ?? 20));
      const { data } = await apiClient.get<ApiListResponse<User>>(`${ENDPOINTS.users.list}?${p}`);
      return data;
    },
    staleTime: 60_000,
  });
}
