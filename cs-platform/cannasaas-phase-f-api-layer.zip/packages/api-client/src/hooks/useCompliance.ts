/**
 * @file useCompliance.ts
 * @package @cannasaas/api-client
 *
 * TanStack Query hooks for the Compliance API.
 *
 * Compliance is a critical domain — every hook here has conservative staleTime
 * settings to ensure staff always see accurate data (no stale limits served
 * to a budtender who just processed a large purchase).
 *
 * Hooks:
 *   useComplianceLogs(filters)         — GET /compliance/logs
 *   useCustomerPurchaseLimit(customerId) — GET /compliance/purchase-limit?customerId=
 *   useGenerateDailyReport()           — POST /compliance/reports/daily
 *   useComplianceSalesAnalytics(range) — GET /compliance/analytics/sales
 *   useComplianceTopProducts(range)    — GET /compliance/analytics/top-products
 *   useComplianceRevenue(range)        — GET /compliance/analytics/revenue
 *
 * ── Purchase Limit staleTime ────────────────────────────────────────────────
 *
 * The purchase limit endpoint is called on CustomerLookup and QuickActions
 * pages. It must reflect the customer's most recent purchase, so staleTime
 * is set to 0 — i.e., always re-fetch when the component mounts or when
 * the customerId changes.
 *
 * In practice this is a lightweight query (single row from the DB) so the
 * performance impact is negligible compared to the regulatory risk of
 * serving a cached limit.
 *
 * ── Log staleTime ────────────────────────────────────────────────────────────
 *
 * Audit logs are append-only. A 2-minute staleTime is appropriate — the logs
 * view is for managers reviewing past events, not real-time monitoring.
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '../client';
import { ENDPOINTS }  from '../endpoints';
import type {
  ComplianceLog, DailySalesReport, PurchaseLimitResult,
  ApiResponse, ApiListResponse, ApiError,
} from '@cannasaas/types';

// ── Query Key Factory ─────────────────────────────────────────────────────────

export const complianceKeys = {
  all:   ['compliance']                                      as const,
  logs:  (f?: object) => [...complianceKeys.all, 'logs',  f] as const,
  limit: (id: string) => [...complianceKeys.all, 'limit', id] as const,
  sales: (range: string) => [...complianceKeys.all, 'sales', range] as const,
  topProducts: (range: string) => [...complianceKeys.all, 'top-products', range] as const,
  revenue:     (range: string) => [...complianceKeys.all, 'revenue', range] as const,
};

// ── Filter type ───────────────────────────────────────────────────────────────

export interface ComplianceLogFilters {
  eventType?: string;
  dateFrom?:  string;
  dateTo?:    string;
  page?:      number;
  limit?:     number;
}

// ── Hooks ─────────────────────────────────────────────────────────────────────

/**
 * GET /compliance/logs — paginated audit log entries.
 *
 * Supports filtering by event type (sale, id_verification, inventory_adjustment)
 * and date range. Required: Manager+ role.
 *
 * @example
 *   const { data } = useComplianceLogs({ eventType: 'sale', limit: 50 });
 */
export function useComplianceLogs(filters: ComplianceLogFilters = {}) {
  return useQuery<ApiListResponse<ComplianceLog>, ApiError>({
    queryKey: complianceKeys.logs(filters),
    queryFn:  async () => {
      const params = new URLSearchParams();
      if (filters.eventType) params.set('eventType', filters.eventType);
      if (filters.dateFrom)  params.set('dateFrom',  filters.dateFrom);
      if (filters.dateTo)    params.set('dateTo',    filters.dateTo);
      if (filters.page)      params.set('page',  String(filters.page));
      if (filters.limit)     params.set('limit', String(filters.limit));
      const { data } = await apiClient.get<ApiListResponse<ComplianceLog>>(
        `${ENDPOINTS.compliance.logs}?${params}`,
      );
      return data;
    },
    staleTime: 2 * 60_000, // 2 minutes — append-only, doesn't need to be fresh
  });
}

/**
 * GET /compliance/purchase-limit?customerId=:id
 *
 * Returns the customer's remaining daily purchase limit for the current
 * dispensary and state. This is the most compliance-critical query in the
 * system — it must never serve stale data.
 *
 * staleTime: 0 — always re-fetch on mount.
 *
 * @example
 *   const { data: limits } = useCustomerPurchaseLimit(customer.id);
 *   // data.remaining.flowerOz, data.remaining.concentrateG
 */
export function useCustomerPurchaseLimit(customerId: string, opts?: { enabled?: boolean }) {
  return useQuery<PurchaseLimitResult, ApiError>({
    queryKey: complianceKeys.limit(customerId),
    queryFn:  async () => {
      const { data } = await apiClient.get<ApiResponse<PurchaseLimitResult>>(
        `${ENDPOINTS.compliance.purchaseLimit}?customerId=${customerId}`,
      );
      return data.data;
    },
    enabled:   (opts?.enabled ?? true) && !!customerId,
    staleTime: 0,          // Always fresh — no caching for purchase limits
    gcTime:    30_000,     // Remove from cache after 30s of non-use
  });
}

/**
 * POST /compliance/reports/daily — trigger on-demand daily sales report.
 *
 * Generates or regenerates the report for a specific date. The server
 * aggregates sales data and returns the report object.
 */
export function useGenerateDailyReport() {
  const queryClient = useQueryClient();
  return useMutation<DailySalesReport, ApiError, { date: string; dispensaryId?: string }>({
    mutationFn: async (body) => {
      const { data } = await apiClient.post<ApiResponse<DailySalesReport>>(
        ENDPOINTS.compliance.dailyReport,
        body,
      );
      return data.data;
    },
    onSuccess: () => {
      // Invalidate log queries so the new report's events appear
      queryClient.invalidateQueries({ queryKey: complianceKeys.all });
    },
  });
}

/**
 * GET /compliance/analytics/sales?range=:range — sales analytics for compliance view.
 *
 * Distinct from the general /analytics/dashboard — this returns compliance-
 * specific metrics like limit violation counts and verification rates.
 */
export function useComplianceSalesAnalytics(range = '30d') {
  return useQuery({
    queryKey: complianceKeys.sales(range),
    queryFn:  async () => {
      const { data } = await apiClient.get(`${ENDPOINTS.compliance.salesAnalytics}?range=${range}`);
      return data;
    },
    staleTime: 5 * 60_000,
  });
}

/**
 * GET /compliance/analytics/top-products?range=:range
 */
export function useComplianceTopProducts(range = '30d') {
  return useQuery({
    queryKey: complianceKeys.topProducts(range),
    queryFn:  async () => {
      const { data } = await apiClient.get(`${ENDPOINTS.compliance.topProducts}?range=${range}`);
      return data;
    },
    staleTime: 5 * 60_000,
  });
}

/**
 * GET /compliance/analytics/revenue?range=:range
 */
export function useComplianceRevenue(range = '30d') {
  return useQuery({
    queryKey: complianceKeys.revenue(range),
    queryFn:  async () => {
      const { data } = await apiClient.get(`${ENDPOINTS.compliance.revenue}?range=${range}`);
      return data;
    },
    staleTime: 5 * 60_000,
  });
}
