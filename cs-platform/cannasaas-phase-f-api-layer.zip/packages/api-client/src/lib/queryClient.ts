/**
 * @file queryClient.ts
 * @package @cannasaas/api-client
 *
 * Centralised TanStack Query (v5) QueryClient factory — Phase F specification.
 *
 * This module exports a singleton `queryClient` that is provided to all three
 * React applications (storefront, admin, staff) at their respective root
 * <QueryClientProvider> wrappers.
 *
 * ── Default Option Rationale ────────────────────────────────────────────────
 *
 * queries.staleTime: 5 min
 *   Most cannabis product listings and user-facing data do not change within a
 *   typical browsing session. 5 minutes balances freshness with reducing
 *   redundant network requests on tab switches or focus events.
 *
 * queries.gcTime: 30 min   (formerly "cacheTime" in v4)
 *   Unused cache entries are kept in memory for 30 minutes so that navigation
 *   between pages feels instant — a user browsing Products → Cart → Products
 *   gets the cached result without a spinner. 30 min is conservative enough
 *   not to exhaust browser memory.
 *
 * queries.retry: 1
 *   Retry once on network failure before surfacing an error. Cannabis
 *   dispensary staff (Order Queue, Inventory Search) need errors surfaced
 *   quickly — retrying more than once masks real problems and introduces lag.
 *
 * queries.refetchOnWindowFocus: false
 *   The staff portal is typically open on a tablet for an entire shift. Constant
 *   refetches on window-focus events would interfere with one-click order
 *   advancement and cause mid-action data refreshes. Pages that need live data
 *   use the WebSocket approach (useOrderQueue) rather than polling.
 *
 * mutations.retry: 0
 *   Mutations (create/update/delete) must never retry automatically — a failed
 *   PUT /orders/:id/status retrying silently could double-advance order state
 *   or cause duplicate Metrc compliance reports. All mutation error handling
 *   is done explicitly in the calling component.
 *
 * ── Override Pattern ────────────────────────────────────────────────────────
 *
 * Per-hook overrides are always passed as the second argument to useQuery():
 *
 *   useQuery({
 *     queryKey: cartKeys.cart(),
 *     queryFn:  fetchCart,
 *     staleTime: 30_000,           // override to 30s for cart
 *     refetchOnWindowFocus: true,  // always fresh for cart
 *   });
 *
 * ── Optimistic Updates Pattern ──────────────────────────────────────────────
 *
 * For mutations that should reflect instantly in the UI (cart, order status),
 * follow the four-step TanStack Query optimistic pattern:
 *
 *   onMutate: async (variables) => {
 *     // 1. Cancel in-flight queries so they don't overwrite our optimistic state
 *     await queryClient.cancelQueries({ queryKey: someKey });
 *
 *     // 2. Snapshot previous state for rollback
 *     const snapshot = queryClient.getQueryData(someKey);
 *
 *     // 3. Apply optimistic update directly to the cache
 *     queryClient.setQueryData(someKey, (old) => deriveOptimisticState(old, variables));
 *
 *     // 4. Return snapshot so onError can roll back
 *     return { snapshot };
 *   },
 *
 *   onError: (_err, _vars, context) => {
 *     // Roll back to the snapshot if the mutation fails
 *     queryClient.setQueryData(someKey, context?.snapshot);
 *   },
 *
 *   onSettled: () => {
 *     // Always refetch after mutation settles (success OR error)
 *     // so the cache reflects the true server state
 *     queryClient.invalidateQueries({ queryKey: someKey });
 *   },
 *
 * The `useAddToCart` hook in useCart.ts demonstrates this pattern in full.
 * The `useAdvanceOrderStatus` hook in useOrders.ts demonstrates it for
 * mutations where the optimistic state is a simple field change.
 *
 * ── DevTools ────────────────────────────────────────────────────────────────
 *
 * To enable React Query DevTools, add <ReactQueryDevtools /> inside
 * <QueryClientProvider> in development builds:
 *
 *   import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
 *   // inside render:
 *   {import.meta.env.DEV && <ReactQueryDevtools initialIsOpen={false} />}
 */

import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      /**
       * Data is considered fresh for 5 minutes.
       * Within this window, identical queryKey requests return the cached
       * result without a background refetch.
       */
      staleTime: 5 * 60 * 1000,       // 5 minutes

      /**
       * Unused cache entries are garbage-collected after 30 minutes.
       * An entry is "unused" when all subscribers have unmounted.
       */
      gcTime: 30 * 60 * 1000,         // 30 minutes

      /**
       * Retry once on transient network failure before surfacing an error.
       * Staff-facing pages need errors surfaced quickly; more retries mask them.
       */
      retry: 1,

      /**
       * Do not refetch automatically when the browser window regains focus.
       * Staff tablets stay open all day — focus-based refetches cause
       * mid-action data refreshes. Use explicit invalidation instead.
       */
      refetchOnWindowFocus: false,
    },
    mutations: {
      /**
       * Never auto-retry mutations. A double-advanced order or duplicate
       * Metrc compliance report would be a serious business problem.
       * Handle mutation errors explicitly in each mutation's onError callback.
       */
      retry: 0,
    },
  },
});
