/**
 * @file endpoints.addendum.ts
 * @package @cannasaas/api-client
 *
 * Phase F endpoint constants that extend the base ENDPOINTS object in endpoints.ts.
 *
 * These are imported by the Phase F hooks. The base endpoints.ts file from
 * scaffold-api-client.sh already contains auth, products, cart, orders, analytics.
 *
 * This addendum adds: users, compliance, dispensaries, delivery, search,
 * reviews, and AI endpoints.
 *
 * Usage in hooks:
 *   import { ENDPOINTS } from '../endpoints';
 *   // The base ENDPOINTS object is extended at runtime by the merge below.
 *
 * Alternatively, hooks import directly from this file if the base ENDPOINTS
 * was not already extended:
 *   import { ENDPOINTS_V2 } from '../endpoints.addendum';
 */

const BASE = '/v1'; // Redundant if axiosClient baseURL already includes /v1; remove if so.

export const ENDPOINTS_ADDENDUM = {

  /** User management — Admin+ */
  users: {
    list:         '/users',
    create:       '/users',
    detail:       (id: string)    => `/users/${id}`,
    update:       (id: string)    => `/users/${id}`,
    delete:       (id: string)    => `/users/${id}`,
    assignRoles:  (id: string)    => `/users/${id}/roles`,
  },

  /** Compliance */
  compliance: {
    logs:           '/compliance/logs',
    purchaseLimit:  '/compliance/purchase-limit',
    dailyReport:    '/compliance/reports/daily',
    salesAnalytics: '/compliance/analytics/sales',
    topProducts:    '/compliance/analytics/top-products',
    revenue:        '/compliance/analytics/revenue',
  },

  /** Dispensary management */
  dispensaries: {
    list:           '/dispensaries',
    create:         '/dispensaries',
    detail:         (id: string)  => `/dispensaries/${id}`,
    update:         (id: string)  => `/dispensaries/${id}`,
    delete:         (id: string)  => `/dispensaries/${id}`,
    nearby:         '/dispensaries/nearby',
    uploadLogo:     (id: string)  => `/dispensaries/${id}/branding/logo`,
    updateBranding: (id: string)  => `/dispensaries/${id}/branding`,
  },

  /** Delivery */
  delivery: {
    zones:        '/delivery/zones',
    createZone:   '/delivery/zones',
    drivers:      '/delivery/drivers',
    assign:       '/delivery/assign',
    checkAddress: '/delivery/check-address',
    tracking:     '/delivery/tracking', // WebSocket endpoint (ws://)
  },

  /** Elasticsearch search */
  search: {
    query:   '/search',
    suggest: '/search/suggest',
  },

  /** Product reviews */
  reviews: {
    list:   (productId: string) => `/reviews/${productId}`,
    create: '/reviews',
  },

  /** AI services */
  ai: {
    productDescription: '/ai/product-description',
    recommendations:    '/ai/recommendations',
    chatbot:            '/ai/chatbot',
  },

  /** Age verification */
  ageVerification: {
    uploadId: '/age-verification/upload-id',
    verify:   '/age-verification/verify',
  },

  /** Orders (additional endpoints not in base) */
  ordersExtra: {
    updateStatus: (id: string) => `/orders/${id}/status`,
    cancel:       (id: string) => `/orders/${id}/cancel`,
    refund:       (id: string) => `/orders/${id}/refund`,
  },
} as const;
