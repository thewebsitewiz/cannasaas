/**
 * @file axiosClient.ts
 * @package @cannasaas/api-client
 *
 * Upgraded Axios instance for the CannaSaas API — Phase F complete implementation.
 *
 * Replaces the simpler client.ts with:
 *   1. Token injection interceptor   — attaches Bearer JWT to every request
 *   2. Tenant context interceptor    — injects X-Organization-Id + X-Dispensary-Id
 *   3. Refresh-token interceptor     — transparent 401 recovery without logout
 *   4. Error normalisation           — converts Axios errors to typed ApiError objects
 *
 * ── Request Flow ────────────────────────────────────────────────────────────
 *
 *   Outgoing request
 *     → (req interceptor 1) attach Authorization: Bearer <accessToken>
 *     → (req interceptor 2) attach X-Organization-Id, X-Dispensary-Id
 *     → API server
 *     ← 200 → pass through
 *     ← 401 → (res interceptor) call POST /auth/refresh once, retry original request
 *     ← other error → normalise to ApiError and reject
 *
 * ── Refresh Token Strategy ──────────────────────────────────────────────────
 *
 * A single `isRefreshing` flag prevents multiple simultaneous refresh requests
 * (e.g. if 3 requests expire at the same time). Subsequent 401s while a refresh
 * is in flight are queued in `failedQueue` and resolved / rejected once the
 * new token arrives.
 *
 * If the refresh itself fails (token expired, network error, 401 from /auth/refresh),
 * all queued requests are rejected and the auth store clears state + redirects to /login.
 *
 * ── Usage ────────────────────────────────────────────────────────────────────
 *
 *   // Prefer importing via @cannasaas/api-client hooks, but if you need
 *   // the raw client:
 *   import { apiClient } from '@cannasaas/api-client';
 *   const { data } = await apiClient.get('/health');
 */

import axios, {
  type AxiosInstance,
  type AxiosRequestConfig,
  type AxiosError,
  type InternalAxiosRequestConfig,
} from 'axios';

// Stores contain auth tokens and org/dispensary context
// These are lazy-imported to avoid circular deps at module init time
let _getAuthState: (() => { accessToken: string | null; refreshToken: string | null }) | null = null;
let _setTokens:    ((access: string, refresh: string) => void) | null = null;
let _clearAuth:    (() => void) | null = null;
let _getTenantCtx: (() => { organizationId: string | null; dispensaryId: string | null }) | null = null;

/**
 * Wire the Axios client to the Zustand auth and org stores.
 * Call this once from each app's main.tsx BEFORE mounting the React tree.
 *
 * @example
 *   // in main.tsx
 *   import { wireAuthToAxios } from '@cannasaas/api-client';
 *   import { useAuthStore, useOrganizationStore } from '@cannasaas/stores';
 *
 *   wireAuthToAxios({
 *     getAuthState:  () => ({ accessToken: useAuthStore.getState().accessToken, refreshToken: useAuthStore.getState().refreshToken }),
 *     setTokens:     (a, r) => useAuthStore.getState().setTokens(a, r),
 *     clearAuth:     () => useAuthStore.getState().logout(),
 *     getTenantCtx:  () => ({ organizationId: useOrganizationStore.getState().organizationId, dispensaryId: useOrganizationStore.getState().dispensaryId }),
 *   });
 */
export function wireAuthToAxios(opts: {
  getAuthState:  () => { accessToken: string | null; refreshToken: string | null };
  setTokens:     (access: string, refresh: string) => void;
  clearAuth:     () => void;
  getTenantCtx:  () => { organizationId: string | null; dispensaryId: string | null };
}) {
  _getAuthState = opts.getAuthState;
  _setTokens    = opts.setTokens;
  _clearAuth    = opts.clearAuth;
  _getTenantCtx = opts.getTenantCtx;
}

// ── Axios instance ────────────────────────────────────────────────────────────

export const apiClient: AxiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL ?? 'https://api.cannasaas.com/v1',
  timeout: 20_000,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
});

// ── Refresh token queue ───────────────────────────────────────────────────────

type QueueItem = { resolve: (token: string) => void; reject: (err: unknown) => void };
let isRefreshing = false;
let failedQueue:  QueueItem[] = [];

function processQueue(error: unknown, token: string | null) {
  failedQueue.forEach((prom) => (error ? prom.reject(error) : prom.resolve(token!)));
  failedQueue = [];
}

// ── Request interceptors ──────────────────────────────────────────────────────

/**
 * Interceptor 1 — Attach Authorization header with current access token.
 * Does nothing if the request already has an Authorization header (e.g.
 * the refresh request itself uses the refresh token directly).
 */
apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  if (config.headers['Authorization']) return config;
  const state = _getAuthState?.();
  if (state?.accessToken) {
    config.headers['Authorization'] = `Bearer ${state.accessToken}`;
  }
  return config;
});

/**
 * Interceptor 2 — Inject multi-tenancy context headers.
 * Every API endpoint scoped to a dispensary requires these.
 * They are read from the Zustand organisation store at request time so that
 * switching dispensaries in the admin portal is reflected immediately.
 */
apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const ctx = _getTenantCtx?.();
  if (ctx?.organizationId) {
    config.headers['X-Organization-Id'] = ctx.organizationId;
  }
  if (ctx?.dispensaryId) {
    config.headers['X-Dispensary-Id'] = ctx.dispensaryId;
  }
  return config;
});

// ── Response interceptors ─────────────────────────────────────────────────────

/**
 * Interceptor — Transparent JWT refresh on 401.
 *
 * When any request returns 401:
 *   1. If a refresh is already in flight, queue this request and wait.
 *   2. Otherwise, start a refresh request with the stored refresh token.
 *   3. On refresh success: update stored tokens, retry all queued requests,
 *      then retry the original request with the new access token.
 *   4. On refresh failure: clear auth state (forces re-login) and reject all
 *      queued requests.
 *
 * The `_retry` flag on the original config prevents infinite retry loops —
 * if the retried request also returns 401 (e.g. because the new token is
 * immediately rejected), we clear auth and don't retry again.
 */
apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const original = error.config as AxiosRequestConfig & { _retry?: boolean };

    if (error.response?.status !== 401 || original._retry) {
      return Promise.reject(normaliseError(error));
    }

    if (isRefreshing) {
      // Queue this request — it will be retried once the refresh completes
      return new Promise((resolve, reject) => {
        failedQueue.push({
          resolve: (token) => {
            original.headers = { ...original.headers, Authorization: `Bearer ${token}` };
            resolve(apiClient(original));
          },
          reject,
        });
      });
    }

    original._retry = true;
    isRefreshing    = true;

    const { refreshToken } = _getAuthState?.() ?? { refreshToken: null };

    if (!refreshToken) {
      isRefreshing = false;
      _clearAuth?.();
      return Promise.reject(normaliseError(error));
    }

    try {
      const { data } = await axios.post<{ accessToken: string; refreshToken: string }>(
        `${apiClient.defaults.baseURL}/auth/refresh`,
        {},
        { headers: { Authorization: `Bearer ${refreshToken}` } },
      );

      _setTokens?.(data.accessToken, data.refreshToken);
      processQueue(null, data.accessToken);

      original.headers = {
        ...original.headers,
        Authorization: `Bearer ${data.accessToken}`,
      };
      return apiClient(original);
    } catch (refreshError) {
      processQueue(refreshError, null);
      _clearAuth?.();
      return Promise.reject(normaliseError(refreshError as AxiosError));
    } finally {
      isRefreshing = false;
    }
  },
);

// ── Error normalisation ───────────────────────────────────────────────────────

/**
 * Converts an Axios error into the typed ApiError shape defined in
 * @cannasaas/types so that all hooks receive consistent error objects.
 *
 * CannaSaas error body:
 *   { error: { code: string, message: string, details?: [...] } }
 */
export interface NormalisedApiError {
  code:     string;
  message:  string;
  status:   number;
  details?: { field: string; message: string }[];
}

function normaliseError(error: AxiosError | unknown): NormalisedApiError {
  if (!axios.isAxiosError(error)) {
    return { code: 'UNKNOWN_ERROR', message: 'An unexpected error occurred.', status: 0 };
  }

  const status = error.response?.status ?? 0;
  const body   = (error.response?.data as any)?.error;

  return {
    code:    body?.code    ?? 'API_ERROR',
    message: body?.message ?? error.message ?? 'Request failed',
    status,
    details: body?.details,
  };
}
