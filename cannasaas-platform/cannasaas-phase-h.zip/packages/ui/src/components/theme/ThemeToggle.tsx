/**
 * @file ThemeToggle.tsx
 * @package @cannasaas/ui
 *
 * Dark / light / system mode toggle button.
 *
 * ── Variants ─────────────────────────────────────────────────────────────────
 *
 * `variant="icon"`    — circular icon button, cycles Light → Dark → System
 *                       Used in the storefront nav and admin topbar.
 *
 * `variant="segmented"` — three-segment control (☀️ Light | 💻 System | 🌙 Dark)
 *                          Used in the account preferences page.
 *
 * `variant="dropdown"` — a button that opens a popover menu with all three options.
 *                         Used in compact areas (admin sidebar footer).
 *
 * ── Cycle order (icon variant) ───────────────────────────────────────────────
 *
 *   light → dark → system → light → …
 *
 * This matches the convention used by GitHub, VS Code, and most SaaS products.
 *
 * Accessibility (WCAG 2.1 AA):
 *   - role="group" + aria-label on segmented variant (1.3.1)
 *   - aria-pressed on active segment (4.1.2)
 *   - aria-label on icon button describes CURRENT state + click action (4.1.2)
 *   - Icons supplemented with visually-hidden text (1.1.1)
 *   - Keyboard: Enter/Space activates, arrow keys navigate segments (2.1.1)
 *   - Focus ring visible on all interactive elements (2.4.7)
 *   - Colour change conveyed by icon + tooltip, not colour alone (1.4.1)
 */

import { useThemeStore, type ThemeMode } from '@cannasaas/stores';

// ── Icons ────────────────────────────────────────────────────────────────────

const ICONS: Record<ThemeMode, { symbol: string; label: string }> = {
  light:  { symbol: '☀️',  label: 'Light mode' },
  dark:   { symbol: '🌙', label: 'Dark mode'  },
  system: { symbol: '💻', label: 'System mode' },
};

const CYCLE: ThemeMode[] = ['light', 'dark', 'system'];

// ── Shared button class builder ───────────────────────────────────────────────

const focusRing = 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary,154_40%_30%))] focus-visible:ring-offset-2';

// ── Icon variant ──────────────────────────────────────────────────────────────

/**
 * Circular icon button that cycles through light → dark → system on each click.
 * The aria-label describes the CURRENT state and the action of clicking.
 */
function IconToggle({ className = '' }: { className?: string }) {
  const { mode, setMode, resolvedMode } = useThemeStore();

  const handleClick = () => {
    const idx  = CYCLE.indexOf(mode);
    const next = CYCLE[(idx + 1) % CYCLE.length];
    setMode(next);
  };

  const { symbol, label } = ICONS[mode];

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label={`${label} — click to cycle theme`}
      title={label}
      className={[
        'w-9 h-9 rounded-full flex items-center justify-center',
        'bg-stone-100 dark:bg-stone-800',
        'hover:bg-stone-200 dark:hover:bg-stone-700',
        'transition-colors',
        focusRing,
        className,
      ].join(' ')}
    >
      {/* Emoji icon — aria-hidden because the aria-label carries the meaning */}
      <span aria-hidden="true" className="text-base leading-none">{symbol}</span>
    </button>
  );
}

// ── Segmented variant ─────────────────────────────────────────────────────────

/**
 * Three-segment control with Light / System / Dark options.
 * Uses role="radiogroup" + role="radio" for proper ARIA semantics.
 * Arrow keys cycle between segments.
 */
function SegmentedToggle({ className = '' }: { className?: string }) {
  const { mode, setMode } = useThemeStore();
  const segments: ThemeMode[] = ['light', 'system', 'dark'];

  const handleKeyDown = (e: React.KeyboardEvent, current: ThemeMode) => {
    const idx = segments.indexOf(current);
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
      e.preventDefault();
      setMode(segments[(idx + 1) % segments.length]);
    }
    if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
      e.preventDefault();
      setMode(segments[(idx - 1 + segments.length) % segments.length]);
    }
  };

  return (
    <div
      role="radiogroup"
      aria-label="Colour scheme preference"
      className={[
        'inline-flex rounded-xl overflow-hidden border border-stone-200 dark:border-stone-700',
        'bg-stone-50 dark:bg-stone-800',
        className,
      ].join(' ')}
    >
      {segments.map((seg) => {
        const { symbol, label } = ICONS[seg];
        const isActive = mode === seg;
        return (
          <button
            key={seg}
            type="button"
            role="radio"
            aria-checked={isActive}
            onClick={() => setMode(seg)}
            onKeyDown={(e) => handleKeyDown(e, seg)}
            className={[
              'flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold transition-all',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[hsl(var(--primary,154_40%_30%))]',
              isActive
                ? 'bg-[hsl(var(--primary,154_40%_30%))] text-white shadow-sm'
                : 'text-stone-500 hover:text-stone-800 dark:hover:text-stone-200',
            ].join(' ')}
          >
            <span aria-hidden="true">{symbol}</span>
            <span className="sr-only sm:not-sr-only capitalize">{label.split(' ')[0]}</span>
          </button>
        );
      })}
    </div>
  );
}

// ── ThemeToggle (main export with variant prop) ────────────────────────────────

export interface ThemeToggleProps {
  /**
   * Visual variant of the toggle:
   *   'icon'      — compact circular icon button (default)
   *   'segmented' — three-segment radio-style control
   */
  variant?: 'icon' | 'segmented';
  className?: string;
}

export function ThemeToggle({ variant = 'icon', className }: ThemeToggleProps) {
  if (variant === 'segmented') return <SegmentedToggle className={className} />;
  return <IconToggle className={className} />;
}
