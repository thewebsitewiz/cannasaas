/**
 * @file BrandingPreview.tsx
 * @package @cannasaas/ui
 *
 * Live branding preview card — shown in the Admin Settings > Branding tab.
 *
 * Renders a realistic mini-storefront preview using the provided (or current
 * CSS-var-derived) brand colours, fonts, and logo. Updates in real-time as
 * the admin adjusts colours in BrandingEditor — no save required to preview.
 *
 * ── What it previews ─────────────────────────────────────────────────────────
 *
 *   - Storefront navbar with logo + dispensary name
 *   - A product card with primary CTA button
 *   - A secondary/outline button
 *   - Accent chip / badge
 *   - Typography sample (heading + body text) with applied font families
 *   - Colour swatch row (primary, secondary, accent)
 *   - Dark mode variant toggle (shows how dark mode looks with current colours)
 *
 * ── Props vs CSS vars ────────────────────────────────────────────────────────
 *
 * The component accepts explicit `branding` props so it can be used to preview
 * unsaved changes (the editor passes the in-progress form values).
 * If no props are passed, it falls back to reading the current CSS vars —
 * useful for displaying the current live configuration.
 *
 * Accessibility (WCAG 2.1 AA):
 *   - role="region" aria-label on the preview frame (1.3.1)
 *   - All preview UI elements are aria-hidden (decorative demo, not interactive) (1.3.1)
 *   - Swatch buttons are fully interactive (copy) and not hidden
 *   - Colour contrast: `contrastColor()` ensures text remains readable
 */

import { useMemo } from 'react';
import { hexToHSL, hexToHslVars, contrastColor, generatePalette, getCssVar } from '@cannasaas/utils';
import { ColorSwatch } from './ColorSwatch';

// ── Types ────────────────────────────────────────────────────────────────────

export interface BrandingConfig {
  primaryColor?:   string;
  secondaryColor?: string;
  accentColor?:    string;
  fontHeading?:    string;
  fontBody?:       string;
  logoUrl?:        string;
  dispensaryName?: string;
}

export interface BrandingPreviewProps {
  /** Explicit branding config (e.g. unsaved editor values) */
  branding?: BrandingConfig;
  /** Optional extra className on the outer wrapper */
  className?: string;
}

// ── Helpers ──────────────────────────────────────────────────────────────────

/** Resolve a branding value: use prop if provided, else read from CSS var */
function resolveColor(prop?: string, cssVarName?: string): string {
  if (prop) return prop;
  const varVal = cssVarName ? getCssVar(cssVarName) : null;
  if (varVal) {
    // CSS var stores bare HSL — convert back for display (approximate)
    return `hsl(${varVal})`;
  }
  return '#2D6A4F'; // Fallback green
}

// ── Mini-preview components ───────────────────────────────────────────────────

/**
 * Mini storefront navbar — preview of how the tenant brand looks at the top of
 * the storefront. Purely decorative, aria-hidden.
 */
function PreviewNavbar({
  primary, logoUrl, name, fontHeading,
}: { primary: string; logoUrl?: string; name: string; fontHeading?: string }) {
  const textColor = contrastColor(primary);
  return (
    <div
      aria-hidden="true"
      className="flex items-center justify-between px-4 py-3 rounded-t-2xl text-xs"
      style={{ backgroundColor: primary, color: textColor, fontFamily: fontHeading }}
    >
      <div className="flex items-center gap-2">
        {logoUrl ? (
          <img src={logoUrl} alt="" className="h-5 w-auto object-contain" />
        ) : (
          <span className="text-lg">🌿</span>
        )}
        <span className="font-extrabold tracking-wide">{name}</span>
      </div>
      <div className="flex items-center gap-3 text-[10px] opacity-80">
        <span>Products</span>
        <span>Cart (2)</span>
      </div>
    </div>
  );
}

/**
 * Mini product card — shows how the primary CTA button and accent badge look.
 */
function PreviewProductCard({
  primary, secondary, accent, fontBody,
}: { primary: string; secondary: string; accent: string; fontBody?: string }) {
  const primaryText  = contrastColor(primary);
  const accentText   = contrastColor(accent);

  return (
    <div
      aria-hidden="true"
      className="flex gap-3 p-3"
      style={{ fontFamily: fontBody }}
    >
      {/* Product image placeholder */}
      <div
        className="w-16 h-16 rounded-xl flex-shrink-0 flex items-center justify-center text-2xl"
        style={{ backgroundColor: accent }}
      >
        🌱
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-1">
          <div>
            <p className="text-xs font-bold text-stone-900 truncate">Blue Dream 1/8 oz</p>
            <p className="text-[10px] text-stone-400">Sativa · 24.5% THC</p>
          </div>
          <span
            className="text-[10px] font-bold px-2 py-0.5 rounded-full flex-shrink-0"
            style={{ backgroundColor: accent, color: accentText }}
          >
            New
          </span>
        </div>
        <p className="text-[10px] text-stone-500 mt-0.5 line-clamp-1">
          Uplifting sativa with notes of berry and sweet citrus…
        </p>
        <div className="flex gap-1.5 mt-2">
          <button
            className="px-2.5 py-1 rounded-lg text-[10px] font-bold"
            style={{ backgroundColor: primary, color: primaryText }}
          >
            Add to Cart
          </button>
          <button
            className="px-2.5 py-1 rounded-lg text-[10px] font-semibold border"
            style={{ borderColor: secondary, color: secondary }}
          >
            Details
          </button>
        </div>
      </div>
    </div>
  );
}

/**
 * Typography sample — shows heading + body text with the applied font families.
 */
function PreviewTypography({
  fontHeading, fontBody, primary,
}: { fontHeading?: string; fontBody?: string; primary: string }) {
  return (
    <div aria-hidden="true" className="px-3 pb-3 border-t border-stone-100">
      <p
        className="text-sm font-extrabold text-stone-900 mt-2"
        style={{ fontFamily: fontHeading }}
      >
        {fontHeading ?? 'Inter'} heading
      </p>
      <p
        className="text-xs text-stone-500 leading-relaxed mt-0.5"
        style={{ fontFamily: fontBody }}
      >
        Body text in {fontBody ?? 'Inter'}. The quick brown fox jumps over the lazy dog.
      </p>
    </div>
  );
}

// ── BrandingPreview (main export) ─────────────────────────────────────────────

export function BrandingPreview({ branding, className }: BrandingPreviewProps) {
  // Resolve colours — either from explicit props or from current CSS vars
  const primary   = resolveColor(branding?.primaryColor,   '--primary');
  const secondary = resolveColor(branding?.secondaryColor, '--secondary');
  const accent    = resolveColor(branding?.accentColor,    '--accent');
  const name      = branding?.dispensaryName ?? 'Your Dispensary';

  // Generate shade palette for the swatch row
  const palette = useMemo(() => generatePalette(primary), [primary]);

  return (
    <section
      role="region"
      aria-label="Branding preview — decorative sample of how your brand will appear"
      className={[
        'bg-white rounded-2xl shadow-md border border-stone-200 overflow-hidden w-full max-w-sm',
        className ?? '',
      ].join(' ')}
    >
      {/* Navbar preview */}
      <PreviewNavbar
        primary={primary}
        logoUrl={branding?.logoUrl}
        name={name}
        fontHeading={branding?.fontHeading}
      />

      {/* Product card preview */}
      <PreviewProductCard
        primary={primary}
        secondary={secondary}
        accent={accent}
        fontBody={branding?.fontBody}
      />

      {/* Typography preview */}
      <PreviewTypography
        fontHeading={branding?.fontHeading}
        fontBody={branding?.fontBody}
        primary={primary}
      />

      {/* Colour swatches */}
      <div
        aria-label="Brand colours"
        className="flex justify-center gap-5 px-3 pb-4 pt-2 border-t border-stone-100"
      >
        <ColorSwatch label="Primary"   hex={primary}   size="sm" />
        <ColorSwatch label="Secondary" hex={secondary} size="sm" />
        <ColorSwatch label="Accent"    hex={accent}    size="sm" />
      </div>
    </section>
  );
}
