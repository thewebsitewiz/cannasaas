/**
 * @file ColorSwatch.tsx
 * @package @cannasaas/ui
 *
 * Colour swatch component with copy-to-clipboard functionality.
 * Used in BrandingPreview and BrandingEditor to display and interact with
 * individual brand colours.
 *
 * ── Anatomy ──────────────────────────────────────────────────────────────────
 *
 *   ┌──────────────┐
 *   │              │  ← coloured square (background = hex value)
 *   │   ✓ Copied!  │  ← copy confirmation overlay (aria-live)
 *   └──────────────┘
 *      Primary         ← colour name label
 *      #2D6A4F         ← hex value (click to copy)
 *      Aa              ← contrast text preview (white or black, WCAG checked)
 *
 * Accessibility (WCAG 2.1 AA):
 *   - button has descriptive aria-label including colour name + hex (4.1.2)
 *   - Copy confirmation: aria-live="polite" role="status" (4.1.3)
 *   - Contrast text ('Aa') calculated via contrastColor() (1.4.3)
 *   - Minimum 44×44px touch target (2.5.5)
 */

import { useState, useRef } from 'react';
import { contrastColor } from '@cannasaas/utils';

export interface ColorSwatchProps {
  /** Display label for the colour (e.g. "Primary", "Secondary") */
  label: string;
  /** 6-digit hex colour value (with or without #) */
  hex:   string;
  /** Optional size variant */
  size?: 'sm' | 'md' | 'lg';
}

export function ColorSwatch({ label, hex, size = 'md' }: ColorSwatchProps) {
  const [copied, setCopied] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout>>();

  const normalHex   = hex.startsWith('#') ? hex : `#${hex}`;
  const textColor   = contrastColor(normalHex);
  const statusId    = `swatch-status-${label.toLowerCase().replace(/\s+/g, '-')}`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(normalHex);
      setCopied(true);
      clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard API not available — fail silently
    }
  };

  const sizeMap = {
    sm: 'w-12 h-12 rounded-xl text-xs',
    md: 'w-16 h-16 rounded-2xl text-sm',
    lg: 'w-20 h-20 rounded-2xl text-base',
  };

  return (
    <div className="flex flex-col items-center gap-1.5">
      <button
        type="button"
        onClick={handleCopy}
        aria-label={`${label} colour ${normalHex}. Click to copy`}
        aria-describedby={statusId}
        className={[
          sizeMap[size],
          'relative flex items-center justify-center',
          'transition-transform hover:scale-105 active:scale-95',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-stone-400',
          'shadow-md cursor-pointer',
        ].join(' ')}
        style={{ backgroundColor: normalHex }}
      >
        {/* Contrast text preview */}
        <span
          aria-hidden="true"
          style={{ color: textColor }}
          className="font-bold select-none"
        >
          {copied ? '✓' : 'Aa'}
        </span>
      </button>

      {/* Live region for copy confirmation — polite so screen readers aren't interrupted */}
      <p
        id={statusId}
        role="status"
        aria-live="polite"
        className={[
          'text-xs font-medium transition-colors',
          copied ? 'text-green-600' : 'text-stone-400',
        ].join(' ')}
      >
        {copied ? 'Copied!' : normalHex}
      </p>

      <p className="text-xs text-stone-500 font-semibold">{label}</p>
    </div>
  );
}
