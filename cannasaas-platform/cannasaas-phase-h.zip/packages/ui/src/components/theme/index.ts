/**
 * @file index.ts
 * @package @cannasaas/ui
 *
 * Barrel export for the theme component suite.
 *
 * ── Components ───────────────────────────────────────────────────────────────
 *
 *   ThemeToggle      — Dark/light/system mode switch button (icon or segmented)
 *   ColorSwatch      — Colour tile with copy-to-clipboard
 *   BrandingPreview  — Live mini-storefront branding preview card
 *   BrandingEditor   — Full colour + font editor with live preview integration
 *
 * ── Types ────────────────────────────────────────────────────────────────────
 *
 *   BrandingConfig   — Shape of the branding configuration object
 *
 * ── Usage ────────────────────────────────────────────────────────────────────
 *
 *   // In the Admin Settings Branding tab:
 *   import { BrandingEditor, BrandingPreview, type BrandingConfig } from '@cannasaas/ui';
 *
 *   // In nav / topbar:
 *   import { ThemeToggle } from '@cannasaas/ui';
 *
 *   // ThemeProvider (wrap once at app root):
 *   import { ThemeProvider } from '@cannasaas/ui';
 */

export { ThemeToggle }        from './ThemeToggle';
export type { ThemeToggleProps } from './ThemeToggle';

export { ColorSwatch }        from './ColorSwatch';
export type { ColorSwatchProps } from './ColorSwatch';

export { BrandingPreview }    from './BrandingPreview';
export type { BrandingConfig, BrandingPreviewProps } from './BrandingPreview';

export { BrandingEditor }     from './BrandingEditor';
export type { BrandingEditorProps } from './BrandingEditor';
