/**
 * @file ThemeProvider.tsx
 * @package @cannasaas/ui
 *
 * Canonical Phase H ThemeProvider — shared across all three CannaSaas apps.
 *
 * ── What it does ─────────────────────────────────────────────────────────────
 *
 * 1. BRAND COLOUR INJECTION
 *    Reads `organization.branding.colors` and writes CSS custom properties
 *    to `document.documentElement` using `hexToHslVars()`:
 *
 *      --primary:   154 40% 29%
 *      --secondary: 150 40% 52%
 *      --accent:    145 40% 80%
 *
 *    Tailwind utilities reference these via `hsl(var(--primary))`, enabling
 *    the full opacity modifier syntax: `bg-[hsl(var(--primary)/0.1)]`.
 *
 *    This approach means zero component changes are needed when a tenant
 *    switches brand colours — every shadcn/ui component picks up new colours
 *    automatically through the Tailwind theme config.
 *
 * 2. FONT INJECTION
 *    Writes `--font-heading` and `--font-body` CSS vars, then appends a
 *    Google Fonts <link> for any font not in the system stack.
 *
 * 3. CUSTOM CSS INJECTION
 *    Injects `organization.branding.customCSS` into a `<style id="tenant-custom-css">`
 *    element in <head>. This CSS is sanitised server-side before storage.
 *
 * 4. FAVICON SWAP
 *    If `organization.branding.logo.favicon` is set, replaces the default
 *    `<link rel="icon">` with the tenant's favicon URL.
 *
 * 5. DOCUMENT TITLE
 *    Sets `document.title` to the organisation name on load.
 *    Individual pages update title with their own content (e.g. "Blue Dream | Green Leaf").
 *
 * 6. DARK/LIGHT/SYSTEM MODE
 *    Reads `themeStore.mode` and applies the `dark` class to `<html>`.
 *    In 'system' mode, subscribes to the `prefers-color-scheme` media query
 *    and calls `themeStore.applyTheme()` whenever the OS preference changes.
 *    The listener is cleaned up on unmount.
 *
 * ── Performance considerations ───────────────────────────────────────────────
 *
 * ThemeProvider uses two separate useEffects to avoid unnecessary work:
 *   Effect 1: Brand colours + fonts + custom CSS — runs when `organization` changes
 *   Effect 2: Dark/light mode — runs when `mode` changes
 *
 * Splitting them means a mode toggle (very frequent) does not re-run the full
 * branding injection (expensive DOM operations).
 *
 * ── Usage ────────────────────────────────────────────────────────────────────
 *
 *   // In each app's main.tsx or App.tsx root:
 *   import { ThemeProvider } from '@cannasaas/ui';
 *
 *   <ThemeProvider>
 *     <App />
 *   </ThemeProvider>
 *
 * ThemeProvider must be rendered:
 *   - Inside <QueryClientProvider> (it uses zustand, not TanStack)
 *   - Inside <BrowserRouter> is optional (it uses no routing)
 *   - After wireAuthToAxios() has been called
 *   - The organizationStore should be populated before ThemeProvider renders
 *     for instant brand colour application. If it's not (fresh page load),
 *     ThemeProvider will re-run when the org resolves.
 *
 * ── Accessibility ────────────────────────────────────────────────────────────
 *
 * - System mode honours `prefers-color-scheme` (WCAG 1.4.3)
 * - Contrast colours are validated via `contrastColor()` in BrandingEditor
 * - Font changes do not reduce text size below minimum (enforced by Tailwind config)
 * - Colour-blind safe: never conveys info through colour alone in generated CSS
 *
 * @see packages/utils/src/color.ts  for hexToHSL + hexToHslVars implementation
 * @see packages/stores/src/themeStore.ts  for mode management
 */

import { useEffect } from 'react';
import { useOrganizationStore } from '@cannasaas/stores';
import { useThemeStore }        from '@cannasaas/stores';
import { hexToHslVars }         from '@cannasaas/utils';

// ── Google Fonts loader ──────────────────────────────────────────────────────

/** Fonts available for tenant branding that require a Google Fonts download */
const GOOGLE_FONT_FAMILIES = new Set([
  'DM Sans', 'Plus Jakarta Sans', 'Nunito', 'Poppins',
  'Merriweather', 'Playfair Display', 'Lora', 'Raleway',
]);

/**
 * Appends a Google Fonts <link> for the given font family.
 * Idempotent — won't add a duplicate <link> if already present.
 */
function loadGoogleFont(family: string): void {
  if (!GOOGLE_FONT_FAMILIES.has(family)) return;
  const id = `gfont-${family.toLowerCase().replace(/\s+/g, '-')}`;
  if (document.getElementById(id)) return;

  const link = Object.assign(document.createElement('link'), {
    id,
    rel:  'stylesheet',
    href: `https://fonts.googleapis.com/css2?family=${encodeURIComponent(family)}:wght@400;500;600;700;800&display=swap`,
  });
  document.head.appendChild(link);
}

// ── CSS var injection ─────────────────────────────────────────────────────────

/**
 * Writes a CSS custom property to :root only if the value has changed.
 * Avoids unnecessary style recalculations on re-renders where branding hasn't changed.
 */
function setCssVar(prop: string, value: string): void {
  const root    = document.documentElement;
  const current = root.style.getPropertyValue(prop).trim();
  if (current !== value) root.style.setProperty(prop, value);
}

// ── ThemeProvider ─────────────────────────────────────────────────────────────

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const organization = useOrganizationStore((state) => state.organization);
  const mode         = useThemeStore((state) => state.mode);
  const applyTheme   = useThemeStore((state) => state.applyTheme);

  // ── Effect 1: Brand colours, fonts, custom CSS, favicon, document title ─────
  //
  // Runs when the organisation changes (tenant switch, or initial resolution).
  // Intentionally separated from the dark-mode effect for performance.

  useEffect(() => {
    if (!organization?.branding) return;

    const { colors, fonts, customCSS, logo } = organization.branding as {
      colors?:   { primary?: string; secondary?: string; accent?: string };
      fonts?:    { heading?: string; body?: string };
      customCSS?: string;
      logo?:     { url?: string; favicon?: string };
    };

    // 1. Brand colours → CSS custom properties
    if (colors) {
      if (colors.primary)   setCssVar('--primary',   hexToHslVars(colors.primary));
      if (colors.secondary) setCssVar('--secondary', hexToHslVars(colors.secondary));
      if (colors.accent)    setCssVar('--accent',    hexToHslVars(colors.accent));
    }

    // 2. Font families → CSS custom properties + Google Fonts load
    if (fonts) {
      if (fonts.heading) {
        setCssVar('--font-heading', fonts.heading);
        loadGoogleFont(fonts.heading);
      }
      if (fonts.body) {
        setCssVar('--font-body', fonts.body);
        loadGoogleFont(fonts.body);
      }
    }

    // 3. Custom CSS → injected <style> in <head>
    //    This CSS is sanitised server-side (XSS-safe) before storage.
    if (customCSS) {
      let styleEl = document.getElementById('tenant-custom-css') as HTMLStyleElement | null;
      if (!styleEl) {
        styleEl = document.createElement('style');
        styleEl.id = 'tenant-custom-css';
        document.head.appendChild(styleEl);
      }
      styleEl.textContent = customCSS;
    }

    // 4. Favicon swap
    if (logo?.favicon) {
      const link = document.querySelector<HTMLLinkElement>("link[rel~='icon']");
      if (link) {
        link.href = logo.favicon;
      } else {
        // Create a favicon link if none exists
        document.head.appendChild(
          Object.assign(document.createElement('link'), {
            rel:  'icon',
            type: 'image/x-icon',
            href: logo.favicon,
          }),
        );
      }
    }

    // 5. Document title (individual pages will append their own title after this)
    if (organization.name) {
      document.title = organization.name;
    }
  }, [organization]);

  // ── Effect 2: Dark / light / system mode ─────────────────────────────────────
  //
  // Runs when the user's mode preference changes.
  // In 'system' mode, subscribes to the OS media query for live updates.

  useEffect(() => {
    // Apply current mode immediately
    applyTheme();

    if (mode !== 'system') return;

    // System mode: listen for OS preference changes (e.g. macOS auto dark mode)
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const handleChange = (e: MediaQueryListEvent) => {
      applyTheme(e.matches ? 'dark' : 'light');
    };

    mediaQuery.addEventListener('change', handleChange);

    // Cleanup: remove listener when mode changes away from 'system' or on unmount
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [mode, applyTheme]);

  // ThemeProvider is a pure side-effect component — renders children unchanged
  return <>{children}</>;
}
