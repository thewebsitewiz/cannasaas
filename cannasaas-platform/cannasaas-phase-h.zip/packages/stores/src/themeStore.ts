/**
 * @file themeStore.ts
 * @package @cannasaas/stores
 *
 * Phase H upgrade — Theme (dark/light/system) Zustand store with:
 *   - System mode media query listener (live OS preference tracking)
 *   - `applyTheme()` helper called by ThemeProvider on every mode change
 *   - `resolvedMode` derived value (always 'light' | 'dark', never 'system')
 *
 * ── Two independent theming layers ───────────────────────────────────────────
 *
 *   Layer 1 — Per-tenant brand colours (organizationStore.resolvedBranding)
 *     Applied as CSS custom properties: --primary, --secondary, --accent
 *     Handled by ThemeProvider reading the organization store.
 *     Always active; does not change with dark/light mode.
 *
 *   Layer 2 — User's colour scheme preference (this store)
 *     Adds/removes the `dark` class on <html>.
 *     Tailwind's dark mode utilities (`dark:bg-stone-900` etc.) activate
 *     when the `dark` class is present.
 *     Persisted to localStorage; defaults to 'system'.
 *
 * ── System mode implementation ───────────────────────────────────────────────
 *
 * When mode === 'system', ThemeProvider subscribes to the
 * `prefers-color-scheme: dark` media query and updates the DOM whenever
 * the OS preference changes — even mid-session (e.g. macOS auto dark mode
 * at sunset). This is important for WCAG 1.4.3 users who rely on OS-level
 * contrast settings.
 *
 * The listener is added/removed in ThemeProvider's useEffect cleanup.
 * The store itself does not add a listener — it only exposes `setMode`.
 *
 * ── Usage ────────────────────────────────────────────────────────────────────
 *
 *   const { mode, setMode, resolvedMode } = useThemeStore();
 *
 *   setMode('dark')    // always dark
 *   setMode('light')   // always light
 *   setMode('system')  // follow OS
 *
 *   resolvedMode       // 'dark' | 'light' — use for toggle icon
 */

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

export type ThemeMode         = 'light' | 'dark' | 'system';
export type ResolvedThemeMode = 'light' | 'dark';

interface ThemeState {
  /** User's explicit choice, persisted to localStorage */
  mode: ThemeMode;

  /**
   * Resolved mode — always 'light' or 'dark', never 'system'.
   * Derived at store init time and kept in sync by applyTheme().
   * Use for rendering conditional icons (sun / moon) and CSS class decisions.
   */
  resolvedMode: ResolvedThemeMode;

  /** Update the user's preference and immediately apply it to the DOM */
  setMode: (mode: ThemeMode) => void;

  /**
   * Apply the current (or given) mode to the document.
   * Called by ThemeProvider on mount and whenever mode changes.
   * Safe to call outside React (e.g. from the media query listener).
   *
   * @param override - If provided, apply this mode instead of the stored one.
   *                   Used by the system-mode media query listener to pass
   *                   the OS preference without changing the stored preference.
   */
  applyTheme: (override?: ResolvedThemeMode) => void;
}

// ── System preference helper ──────────────────────────────────────────────────

function getSystemPreference(): ResolvedThemeMode {
  if (typeof window === 'undefined') return 'light';
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

// ── Store ─────────────────────────────────────────────────────────────────────

export const useThemeStore = create<ThemeState>()(
  persist(
    (set, get) => ({
      mode:         'system',
      resolvedMode: getSystemPreference(), // Initialise from OS before first render

      setMode: (mode) => {
        const resolved: ResolvedThemeMode =
          mode === 'system' ? getSystemPreference() : mode;
        set({ mode, resolvedMode: resolved });
        get().applyTheme(resolved);
      },

      applyTheme: (override) => {
        const { mode } = get();
        const effective: ResolvedThemeMode =
          override ?? (mode === 'system' ? getSystemPreference() : mode);
        set({ resolvedMode: effective });
        const root = document.documentElement;
        if (effective === 'dark') {
          root.classList.add('dark');
        } else {
          root.classList.remove('dark');
        }
      },
    }),
    {
      name:    'cannasaas-theme',
      storage: createJSONStorage(() => localStorage),
      // Only persist mode — resolvedMode is derived at runtime
      partialize: (s) => ({ mode: s.mode }),
      // After rehydration, re-apply the stored mode to the DOM
      onRehydrateStorage: () => (state) => {
        state?.applyTheme();
      },
    },
  ),
);
