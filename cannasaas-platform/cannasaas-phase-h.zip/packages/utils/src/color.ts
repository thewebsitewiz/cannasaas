/**
 * @file color.ts
 * @package @cannasaas/utils
 *
 * Colour conversion utilities for the CannaSaas theming system.
 *
 * ── Why HSL? ──────────────────────────────────────────────────────────────────
 *
 * Tailwind CSS (v3) uses a CSS custom property strategy where colour tokens
 * store bare HSL channel values (no `hsl()` wrapper):
 *
 *   :root { --primary: 154 40% 30%; }
 *
 * Tailwind then references them as:
 *   hsl(var(--primary))          → full opacity
 *   hsl(var(--primary) / 0.1)   → 10% opacity (Tailwind modifier syntax)
 *
 * Storing bare channels (not `hsl(...)`) enables the opacity modifier syntax.
 * If we stored `hsl(154, 40%, 30%)` the modifier could not be appended.
 *
 * ── Functions ────────────────────────────────────────────────────────────────
 *
 *   hexToHSL(hex)        → 'hsl(154, 40%, 30%)'      full CSS hsl() string
 *   hexToHslVars(hex)    → '154 40% 30%'              bare channels for CSS vars
 *   hslToHex(h, s, l)   → '#2D6A4F'                  back-convert for pickers
 *   contrastColor(hex)   → '#ffffff' | '#000000'      WCAG-compliant text colour
 *   generatePalette(hex) → { light, base, dark }      3-step shade set
 *   parseHslVars(str)    → { h, s, l }                parse stored var string
 *
 * ── WCAG contrast ────────────────────────────────────────────────────────────
 *
 * `contrastColor` returns white or black text based on the background's
 * relative luminance (WCAG 1.4.3 minimum 4.5:1 for normal text).
 * Used to ensure button label text is always readable against tenant colours.
 */

// ── hexToHSL ─────────────────────────────────────────────────────────────────

/**
 * Converts a hex colour string to a full CSS `hsl(H, S%, L%)` string.
 *
 * Use this when you need the full hsl() function value for inline styles.
 * For CSS custom properties, prefer `hexToHslVars` (returns bare channels).
 *
 * @param hex - 3 or 6 digit hex colour, with or without leading #
 * @returns Full `hsl(H, S%, L%)` string
 *
 * @example
 *   hexToHSL('#2D6A4F')  // → 'hsl(154, 40%, 29%)'
 *   hexToHSL('#52B788')  // → 'hsl(150, 40%, 52%)'
 */
export function hexToHSL(hex: string): string {
  const { h, s, l } = hexToHslComponents(hex);
  return `hsl(${h}, ${s}%, ${l}%)`;
}

/**
 * Converts a hex colour to bare HSL channel values for use in CSS custom properties.
 *
 * Returns format: 'H S% L%' (no `hsl()` wrapper, no commas).
 * This format is required for Tailwind's opacity modifier syntax to work:
 *   --primary: 154 40% 29%
 *   → hsl(var(--primary) / 0.1)  ← opacity modifier appended outside the var
 *
 * @param hex - 3 or 6 digit hex colour, with or without leading #
 * @returns Bare HSL channel string, e.g. '154 40% 29%'
 *
 * @example
 *   hexToHslVars('#2D6A4F')  // → '154 40% 29%'
 *
 * @see https://tailwindcss.com/docs/customizing-colors#using-css-variables
 */
export function hexToHslVars(hex: string): string {
  const { h, s, l } = hexToHslComponents(hex);
  return `${h} ${s}% ${l}%`;
}

// ── Internal hex → HSL converter ─────────────────────────────────────────────

interface HslComponents { h: number; s: number; l: number; }

/**
 * Core hex → HSL math. Handles 3-digit and 6-digit hex, with or without #.
 * Used internally by all public conversion functions.
 */
function hexToHslComponents(hex: string): HslComponents {
  // Normalise: strip #, expand 3-digit to 6-digit
  let h = hex.replace('#', '');
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  if (h.length !== 6) {
    console.warn(`[color.ts] Invalid hex: "${hex}", falling back to #000000`);
    return { h: 0, s: 0, l: 0 };
  }

  // Parse RGB channels (0–1 range)
  const r = parseInt(h.slice(0, 2), 16) / 255;
  const g = parseInt(h.slice(2, 4), 16) / 255;
  const b = parseInt(h.slice(4, 6), 16) / 255;

  const max  = Math.max(r, g, b);
  const min  = Math.min(r, g, b);
  const l    = (max + min) / 2;
  let s = 0;
  let hue = 0;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: hue = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: hue = ((b - r) / d + 2) / 6;               break;
      case b: hue = ((r - g) / d + 4) / 6;               break;
    }
  }

  return {
    h: Math.round(hue * 360),
    s: Math.round(s * 100),
    l: Math.round(l * 100),
  };
}

// ── hslToHex ─────────────────────────────────────────────────────────────────

/**
 * Converts HSL values back to a 6-digit hex colour string.
 *
 * Used when displaying a colour picker pre-populated from stored CSS var values.
 * The input uses the same Tailwind CSS var format (separate h, s, l integers).
 *
 * @example
 *   hslToHex(154, 40, 29) // → '#2d6a4c'
 */
export function hslToHex(h: number, s: number, l: number): string {
  const ls = l / 100;
  const ss = s / 100;
  const a  = ss * Math.min(ls, 1 - ls);

  const toHex = (n: number): string => {
    const x = ls - a * (n % 12 === 0 ? -1 : n % 12 < 4 ? n % 12 - 3 : n % 12 < 8 ? 3 - n % 12 + 4 : n % 12 - 9);
    return Math.round(255 * Math.max(0, Math.min(1, x))).toString(16).padStart(2, '0');
  };

  return `#${toHex(0)}${toHex(8)}${toHex(4)}`;
}

// ── contrastColor ─────────────────────────────────────────────────────────────

/**
 * Returns '#ffffff' or '#000000' depending on which provides better contrast
 * against the given background hex colour.
 *
 * Uses the WCAG relative luminance formula to ensure a minimum 4.5:1 contrast
 * ratio for normal text (WCAG 1.4.3 AA).
 *
 * Use this to automatically set button label and icon colours based on the
 * tenant's primary/secondary/accent colours.
 *
 * @example
 *   contrastColor('#2D6A4F')  // → '#ffffff' (dark background → white text)
 *   contrastColor('#B7E4C7')  // → '#000000' (light background → black text)
 */
export function contrastColor(hex: string): '#ffffff' | '#000000' {
  const h   = hex.replace('#', '');
  const r   = parseInt(h.slice(0, 2), 16);
  const g   = parseInt(h.slice(2, 4), 16);
  const b   = parseInt(h.slice(4, 6), 16);

  // Relative luminance (WCAG 2.1 formula)
  const toLinear = (c: number) => {
    const s = c / 255;
    return s <= 0.04045 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  };

  const luminance = 0.2126 * toLinear(r) + 0.7152 * toLinear(g) + 0.0722 * toLinear(b);

  // White contrast: (L + 0.05) / (0.0 + 0.05), Black contrast: (1 + 0.05) / (L + 0.05)
  return luminance > 0.179 ? '#000000' : '#ffffff';
}

// ── generatePalette ───────────────────────────────────────────────────────────

/**
 * Generates a 3-step shade palette (light, base, dark) from a single hex colour.
 *
 * Used by BrandingPreview to show a visual palette preview and by the
 * ThemeProvider to automatically derive light/dark mode variants.
 *
 * @example
 *   generatePalette('#2D6A4F')
 *   // → { light: '#4d8a6f', base: '#2D6A4F', dark: '#1a4a35' }
 */
export function generatePalette(hex: string): { light: string; base: string; dark: string } {
  const { h, s, l } = hexToHslComponents(hex);
  return {
    light: hslToHex(h, Math.max(0, s - 5), Math.min(100, l + 15)),
    base:  hex,
    dark:  hslToHex(h, Math.min(100, s + 5), Math.max(0, l - 15)),
  };
}

// ── parseHslVars ──────────────────────────────────────────────────────────────

/**
 * Parses a stored CSS var string back into component integers.
 *
 * @example
 *   parseHslVars('154 40% 29%') // → { h: 154, s: 40, l: 29 }
 */
export function parseHslVars(str: string): HslComponents {
  const [h, s, l] = str.trim().split(/\s+/).map((v) => parseInt(v, 10));
  return { h: h ?? 0, s: s ?? 0, l: l ?? 0 };
}

/**
 * Reads a CSS custom property from :root and parses it as an HSL string.
 *
 * @example
 *   getCssVar('--primary')  // → '154 40% 29%' (or null if not set)
 */
export function getCssVar(prop: string): string | null {
  return getComputedStyle(document.documentElement).getPropertyValue(prop).trim() || null;
}
