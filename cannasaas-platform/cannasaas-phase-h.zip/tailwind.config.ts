/**
 * @file tailwind.config.ts
 * @workspace root
 *
 * Shared Tailwind CSS v3 configuration for all CannaSaas frontend apps.
 *
 * ── CSS variable colour strategy ──────────────────────────────────────────────
 *
 * All brand colours are defined as CSS custom properties in :root and
 * referenced here using the Tailwind CSS variable pattern:
 *
 *   hsl(var(--primary))            → full opacity brand colour
 *   hsl(var(--primary) / 0.1)     → 10% opacity (opacity modifier)
 *
 * CSS vars store bare HSL channel values (no `hsl()` wrapper):
 *   --primary: 154 40% 29%
 *
 * This enables Tailwind's opacity modifier syntax AND allows ThemeProvider
 * to change colours at runtime by updating the CSS var — zero component
 * changes required for a full tenant rebrand.
 *
 * ── Dark mode ────────────────────────────────────────────────────────────────
 *
 * strategy: 'class' — the `dark` class on <html> activates dark utilities.
 * Controlled by ThemeProvider which adds/removes the class based on
 * themeStore.mode.
 *
 * ── Content paths ────────────────────────────────────────────────────────────
 *
 * Includes all three apps and the shared packages. Adjust if your directory
 * structure differs.
 *
 * ── Custom utilities ──────────────────────────────────────────────────────────
 *
 * focus-ring:     Standard keyboard focus indicator (WCAG 2.4.7)
 *   Applied manually with @apply in component CSS, or via the `focus-visible:`
 *   variant + ring utilities.
 *
 * ── shadcn/ui compatibility ───────────────────────────────────────────────────
 *
 * shadcn/ui components reference the same CSS var names (--primary, --secondary,
 * etc.) via the `hsl(var(--primary))` pattern. This config ensures Tailwind
 * generates the correct utility classes that match shadcn's expectations.
 *
 * @see https://tailwindcss.com/docs/customizing-colors#using-css-variables
 * @see https://ui.shadcn.com/docs/theming
 */

import type { Config } from 'tailwindcss';
import { fontFamily } from 'tailwindcss/defaultTheme';

const config: Config = {
  /**
   * Class-based dark mode — ThemeProvider adds/removes 'dark' on <html>.
   * Never use `media` strategy as it bypasses the user preference store.
   */
  darkMode: ['class'],

  /**
   * Content paths — scanned for class usage during the production build.
   * Includes all three apps and all shared packages.
   */
  content: [
    './apps/storefront/src/**/*.{ts,tsx}',
    './apps/admin/src/**/*.{ts,tsx}',
    './apps/staff/src/**/*.{ts,tsx}',
    './packages/ui/src/**/*.{ts,tsx}',
    './packages/utils/src/**/*.{ts,tsx}',
  ],

  theme: {
    extend: {
      /**
       * Colour tokens — all reference CSS custom properties set by ThemeProvider.
       *
       * These replace Tailwind's default colour utilities for the named tokens.
       * Components use utilities like `bg-primary`, `text-secondary`, `border-accent`.
       *
       * Opacity modifier syntax works automatically because the CSS vars store
       * bare HSL channel values:
       *   `bg-primary/10`  → `background-color: hsl(var(--primary) / 0.1)`
       */
      colors: {
        /** Main brand colour — buttons, links, active nav states */
        primary: {
          DEFAULT:    'hsl(var(--primary))',
          foreground: 'hsl(var(--primary-foreground, 0 0% 100%))',
        },
        /** Supporting colour — hover states, secondary buttons */
        secondary: {
          DEFAULT:    'hsl(var(--secondary))',
          foreground: 'hsl(var(--secondary-foreground, 0 0% 100%))',
        },
        /** Highlight colour — badges, chips, sale tags */
        accent: {
          DEFAULT:    'hsl(var(--accent))',
          foreground: 'hsl(var(--accent-foreground, 0 0% 0%))',
        },
        /**
         * Semantic tokens for shadcn/ui compatibility.
         * ThemeProvider does not set these — they fall back to CSS defaults.
         * Override in global CSS if needed.
         */
        background:   'hsl(var(--background, 0 0% 100%))',
        foreground:   'hsl(var(--foreground, 222 47% 11%))',
        card:         'hsl(var(--card, 0 0% 100%))',
        muted:        'hsl(var(--muted, 210 40% 96%))',
        'muted-foreground': 'hsl(var(--muted-foreground, 215 16% 47%))',
        border:       'hsl(var(--border, 214 32% 91%))',
        input:        'hsl(var(--input, 214 32% 91%))',
        ring:         'hsl(var(--ring, var(--primary)))',
        destructive: {
          DEFAULT:    'hsl(var(--destructive, 0 84% 60%))',
          foreground: 'hsl(var(--destructive-foreground, 0 0% 100%))',
        },
      },

      /**
       * Font families — reference CSS custom properties set by ThemeProvider.
       * Fallback chain ensures text renders even before the Google Font loads.
       */
      fontFamily: {
        sans: [
          'var(--font-body, Inter)',
          'Inter',
          ...fontFamily.sans,
        ],
        heading: [
          'var(--font-heading, Inter)',
          'Inter',
          ...fontFamily.sans,
        ],
        mono: fontFamily.mono,
      },

      /**
       * Border radius tokens — matches shadcn/ui convention.
       * Set --radius in global CSS to change the rounding scale site-wide.
       */
      borderRadius: {
        lg: 'var(--radius, 0.5rem)',
        md: 'calc(var(--radius, 0.5rem) - 2px)',
        sm: 'calc(var(--radius, 0.5rem) - 4px)',
      },

      /**
       * Keyframe animations — used by loading spinners and toast notifications.
       */
      keyframes: {
        'accordion-down': {
          from: { height: '0' },
          to:   { height: 'var(--radix-accordion-content-height)' },
        },
        'accordion-up': {
          from: { height: 'var(--radix-accordion-content-height)' },
          to:   { height: '0' },
        },
        'fade-in': {
          from: { opacity: '0', transform: 'translateY(4px)' },
          to:   { opacity: '1', transform: 'translateY(0)' },
        },
        'slide-in-right': {
          from: { opacity: '0', transform: 'translateX(8px)' },
          to:   { opacity: '1', transform: 'translateX(0)' },
        },
      },
      animation: {
        'accordion-down':  'accordion-down 0.2s ease-out',
        'accordion-up':    'accordion-up 0.2s ease-out',
        'fade-in':         'fade-in 0.15s ease-out',
        'slide-in-right':  'slide-in-right 0.15s ease-out',
      },
    },
  },

  plugins: [
    /** @tailwindcss/typography — for rich-text content areas */
    // require('@tailwindcss/typography'),
    /** @tailwindcss/forms — for default form element resets */
    // require('@tailwindcss/forms'),
    /** tailwindcss-animate — for shadcn/ui animation utilities */
    // require('tailwindcss-animate'),
  ],
};

export default config;
